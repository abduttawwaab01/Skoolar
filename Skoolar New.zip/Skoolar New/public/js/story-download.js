// Story Download Module
// Generates PDF and TXT downloads for stories
// Uses jsPDF from assets/lib

const StoryDownload = {
    /**
     * Download a story in the specified format
     * @param {string} storyId - The story ID
     * @param {string} format - 'pdf' or 'txt'
     * @param {boolean} track - Whether to track the download (default true)
     */
    async download(storyId, format = 'pdf', track = true) {
        const story = Stories.getStory(storyId);
        if (!story) {
            Toast && Toast.error('Story not found');
            return;
        }

        if (!story.downloadable) {
            Toast && Toast.error('This story is not available for download');
            return;
        }

        try {
            let blob;
            if (format === 'pdf') {
                blob = await this.generatePDF(story);
            } else if (format === 'txt') {
                blob = await this.generateTXT(story);
            } else {
                throw new Error('Unsupported format');
            }

            // Create download link
            const url = URL.createObjectURL(blob);
            const filename = this.sanitizeFilename(story.title) + '.' + format;
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            // Track download
            if (track) {
                Stories.downloadStory(storyId, Stories.getUserId());
            }

            Toast && Toast.success('Download started!');
        } catch (error) {
            console.error('Download failed:', error);
            Toast && Toast.error('Failed to generate download: ' + error.message);
        }
    },

    /**
     * Generate PDF from story content
     * @param {object} story - The story object
     * @returns {Blob} PDF blob
     */
    async generatePDF(story) {
        // Check if jsPDF is available
        if (typeof jspdf === 'undefined') {
            throw new Error('PDF library not loaded');
        }

        const { jsPDF } = jspdf;
        const doc = new jsPDF('p', 'mm', 'a5'); // A5 size for readability
        const pageWidth = doc.internal.pageSize.getWidth();
        const margin = 15;
        const maxWidth = pageWidth - margin * 2;

        // ========== COVER PAGE ==========
        doc.setFillColor(139, 92, 246); // Purple
        doc.rect(0, 0, pageWidth, 80, 'F');

        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.text(story.title, pageWidth / 2, 30, { align: 'center' });

        if (story.subtitle) {
            doc.setFontSize(14);
            doc.text(story.subtitle, pageWidth / 2, 40, { align: 'center' });
        }

        doc.setFontSize(12);
        doc.text(`By ${story.author_name}`, pageWidth / 2, 50, { align: 'center' });

        // Genre & Age badge
        const genreText = `${story.genre} • ${story.age_group.replace('_', ' ')}`;
        doc.setFontSize(10);
        doc.text(genreText, pageWidth / 2, 58, { align: 'center' });

        // Cover image if available
        if (story.cover_image && story.cover_image.startsWith('data:')) {
            try {
                const imgData = story.cover_image;
                // Add image on cover page (below title)
                doc.addImage(imgData, 'JPEG', margin, 65, 40, 40);
            } catch (e) {
                console.warn('Failed to add cover image to PDF:', e);
            }
        }

        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text('Skoolar Stories', pageWidth / 2, 77, { align: 'center' });

        // ========== CONTENT PAGES ==========
        doc.setPage(2);
        doc.setTextColor(0, 0, 0);

        // Story metadata at top
        doc.setFontSize(10);
        doc.setFontType('italic');
        doc.text(`${story.word_count} words • ${story.read_time_minutes} min read`, pageWidth / 2, 10, { align: 'center' });
        doc.setFontType('normal');

        let y = 20;
        const lineHeight = 6;
        const fontSize = 11;
        doc.setFontSize(fontSize);

        // Parse content (strip HTML tags but preserve paragraphs)
        const plainText = this.stripHtml(story.content);

        // Split into paragraphs
        const paragraphs = plainText.split(/\n\n+/).filter(p => p.trim());
        const maxLinesPerPage = Math.floor((doc.internal.pageSize.getHeight() - margin * 2) / lineHeight) - 2;

        for (let i = 0; i < paragraphs.length; i++) {
            const para = paragraphs[i].trim();
            if (!para) continue;

            // Check if we need a new page
            const lines = doc.splitTextToSize(para, maxWidth);
            const linesNeeded = lines.length;

            if (y + linesNeeded * lineHeight > doc.internal.pageSize.getHeight() - margin) {
                doc.addPage();
                y = margin;
            }

            // Render paragraph
            doc.text(lines, margin, y);
            y += linesNeeded * lineHeight + lineHeight / 2; // extra spacing between paragraphs

            // Page number
            if (y > doc.internal.pageSize.getHeight() - margin) {
                doc.setFontSize(8);
                doc.setTextColor(150);
                doc.text(`Page ${doc.internal.getCurrentPageInfo().pageNumber}`, pageWidth - margin, doc.internal.pageSize.getHeight() - 5, { align: 'right' });
                doc.setTextColor(0, 0, 0);
                doc.setFontSize(fontSize);
            }
        }

        // Footer with copyright
        const totalPages = doc.internal.getCurrentPageInfo().pageNumber;
        for (let p = 1; p <= totalPages; p++) {
            doc.setPage(p);
            doc.setFontSize(8);
            doc.setTextColor(150);
            doc.text(`Generated by Skoolar Stories • © ${new Date().getFullYear()} All rights reserved.`, margin, doc.internal.pageSize.getHeight() - 5);
        }

        return doc.output('blob');
    },

    /**
     * Generate plain TXT file from story
     * @param {object} story - The story object
     * @returns {Blob} TXT blob
     */
    async generateTXT(story) {
        const plainText = this.stripHtml(story.content);

        const txt = `
${story.title}
${story.subtitle ? `"${story.subtitle}"` : ''}

By ${story.author_name}
Genre: ${story.genre} | Age: ${story.age_group.replace('_', ' ')}
${story.word_count} words • ${story.read_time_minutes} min read

===========================================

${plainText}

===========================================
Generated by Skoolar Stories
© ${new Date().getFullYear()} All rights reserved.
`.trim();

        return new Blob([txt], { type: 'text/plain;charset=utf-8' });
    },

    /**
     * Strip HTML tags, preserve paragraphs
     * @param {string} html - HTML content
     * @returns {string} Plain text
     */
    stripHtml(html) {
        if (!html) return '';

        // Create temporary element
        const tmp = document.createElement('div');
        tmp.innerHTML = html;

        // Convert block elements to double newlines
        const blockElements = ['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'br', 'blockquote', 'ul', 'ol'];

        blockElements.forEach(tag => {
            const elements = tmp.getElementsByTagName(tag);
            for (let el of elements) {
                const br = document.createElement('br');
                if (tag !== 'br') {
                    el.appendChild(br.cloneNode());
                    el.appendChild(br.cloneNode());
                }
            }
        });

        const text = tmp.textContent || tmp.innerText || '';

        // Clean up whitespace
        return text
            .replace(/\n{3,}/g, '\n\n')
            .replace(/[ \t]+/g, ' ')
            .trim();
    },

    /**
     * Sanitize filename
     * @param {string} name - Original name
     * @returns {string} Safe filename
     */
    sanitizeFilename(name) {
        return name
            .toLowerCase()
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-')
            .substring(0, 50) || 'story';
    },

    /**
     * Download current story from reader page
     */
    async downloadCurrentStory() {
        const params = new URLSearchParams(window.location.search);
        const storySlug = params.get('story') || window.location.pathname.split('/').pop().replace('.html', '');
        const story = Stories.getStory(storySlug);

        if (!story) {
            Toast && Toast.error('Story not found');
            return;
        }

        // Check if downloadable
        if (!story.downloadable) {
            Toast && Toast.error('This story is not available for download');
            return;
        }

        // Show format choice
        const format = confirm('Download as PDF? (Cancel for TXT)') ? 'pdf' : 'txt';
        await this.download(story.id, format);
    }
};

// Auto-init
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        // Wait for Stories to be ready
        if (window.Stories) {
            StoryDownload.init();
        }
    });
} else {
    // Stories should already be loaded
    StoryDownload.init && StoryDownload.init();
}

// Make globally available
window.StoryDownload = StoryDownload;

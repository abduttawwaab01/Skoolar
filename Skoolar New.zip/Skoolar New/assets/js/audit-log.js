const AuditLog = {
    currentPage: 1,
    itemsPerPage: 50,
    syncCurrentPage: 1,

    init() {
        this.loadAuditLog(1);
    },

    loadAuditLog(page = 1) {
        this.currentPage = page;
        
        const filters = {
            dateFrom: document.getElementById('auditDateFrom')?.value || null,
            dateTo: document.getElementById('auditDateTo')?.value || null,
            action: document.getElementById('auditActionFilter')?.value || null,
            entityType: document.getElementById('auditEntityFilter')?.value || null
        };
        
        let logs = Storage.getAuditLog(filters);
        const totalItems = logs.length;
        const totalPages = Math.ceil(totalItems / this.itemsPerPage);
        const start = (page - 1) * this.itemsPerPage;
        const paginated = logs.slice(start, start + this.itemsPerPage);
        
        this.renderAuditLogTable(paginated);
        this.renderPagination(totalItems, totalPages, page, 'auditLogPagination', 'AuditLog.loadAuditLog');
    },

    renderAuditLogTable(logs) {
        const tbody = document.getElementById('auditLogTableBody');
        if (!tbody) return;
        
        if (logs.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center">
                        <div class="empty-state">
                            <i class="fas fa-history"></i>
                            <p>No audit log entries found</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }
        
        let html = '';
        logs.forEach(log => {
            const date = new Date(log.createdAt).toLocaleString();
            const user = this.getUserName(log.userId);
            const actionClass = this.getActionClass(log.action);
            const details = this.getLogDetails(log);
            
            html += `
                <tr>
                    <td>${date}</td>
                    <td>${user}</td>
                    <td><span class="badge badge-${actionClass}">${log.action}</span></td>
                    <td>${log.entityType || '-'}</td>
                    <td>${details}</td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
    },

    getUserName(userId) {
        if (!userId) return 'System';
        
        const users = Storage.getData('users') || [];
        const user = users.find(u => u.id === userId);
        if (user) return user.name;
        
        const students = Storage.getData('students') || [];
        const student = students.find(s => s.id === userId);
        if (student) return student.name;
        
        return userId.substring(0, 8);
    },

    getActionClass(action) {
        const classes = {
            'CREATE': 'success',
            'UPDATE': 'info',
            'DELETE': 'danger',
            'LOGIN': 'primary',
            'LOGOUT': 'secondary'
        };
        return classes[action] || 'default';
    },

    getLogDetails(log) {
        if (log.action === 'CREATE') {
            return `<span class="text-success">Added: ${log.entityType}</span>`;
        }
        if (log.action === 'UPDATE') {
            return `<span class="text-info">Updated: ${log.entityType}</span>`;
        }
        if (log.action === 'DELETE') {
            return `<span class="text-danger">Deleted: ${log.entityType}</span>`;
        }
        if (log.action === 'LOGIN') {
            return `<span class="text-primary">User logged in</span>`;
        }
        if (log.action === 'LOGOUT') {
            return `<span class="text-secondary">User logged out</span>`;
        }
        return log.entityType || '-';
    },

    renderPagination(totalItems, totalPages, currentPage, containerId, loadFn) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        if (totalPages <= 1) {
            container.innerHTML = '';
            return;
        }
        
        let html = `<span class="pagination-info">Showing ${((currentPage - 1) * this.itemsPerPage) + 1}-${Math.min(currentPage * this.itemsPerPage, totalItems)} of ${totalItems}</span>`;
        html += '<div class="pagination-buttons">';
        
        if (currentPage > 1) {
            html += `<button class="btn btn-sm" onclick="${loadFn}(${currentPage - 1})"><i class="fas fa-chevron-left"></i> Previous</button>`;
        }
        
        for (let i = Math.max(1, currentPage - 2); i <= Math.min(totalPages, currentPage + 2); i++) {
            html += `<button class="btn btn-sm ${i === currentPage ? 'active' : ''}" onclick="${loadFn}(${i})">${i}</button>`;
        }
        
        if (currentPage < totalPages) {
            html += `<button class="btn btn-sm" onclick="${loadFn}(${currentPage + 1})">Next <i class="fas fa-chevron-right"></i></button>`;
        }
        
        html += '</div>';
        container.innerHTML = html;
    },

    exportToCSV() {
        const filters = {
            dateFrom: document.getElementById('auditDateFrom')?.value || null,
            dateTo: document.getElementById('auditDateTo')?.value || null,
            action: document.getElementById('auditActionFilter')?.value || null,
            entityType: document.getElementById('auditEntityFilter')?.value || null
        };
        
        const logs = Storage.getAuditLog(filters);
        
        let csv = 'Date/Time,User,Action,Entity Type,Entity ID,Old Values,New Values\n';
        
        logs.forEach(log => {
            const date = new Date(log.createdAt).toISOString();
            const user = this.getUserName(log.userId).replace(/,/g, ';');
            const oldVals = log.oldValues ? JSON.stringify(log.oldValues).replace(/,/g, ';') : '';
            const newVals = log.newValues ? JSON.stringify(log.newValues).replace(/,/g, ';') : '';
            
            csv += `"${date}","${user}","${log.action}","${log.entityType || ''}","${log.entityId || ''}","${oldVals}","${newVals}"\n`;
        });
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `audit_log_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
    },

    loadSyncLog(page = 1) {
        this.syncCurrentPage = page;
        
        const filters = {
            dateFrom: document.getElementById('syncDateFrom')?.value || null,
            status: document.getElementById('syncStatusFilter')?.value || null
        };
        
        let logs = Storage.getSyncLog(filters);
        const totalItems = logs.length;
        const totalPages = Math.ceil(totalItems / this.itemsPerPage);
        const start = (page - 1) * this.itemsPerPage;
        const paginated = logs.slice(start, start + this.itemsPerPage);
        
        this.renderSyncLogTable(paginated);
        this.renderPagination(totalItems, totalPages, page, 'syncLogPagination', 'AuditLog.loadSyncLog');
    },

    renderSyncLogTable(logs) {
        const tbody = document.getElementById('syncLogTableBody');
        if (!tbody) return;
        
        if (logs.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center">
                        <div class="empty-state">
                            <i class="fas fa-sync-alt"></i>
                            <p>No sync log entries found</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }
        
        let html = '';
        logs.forEach(log => {
            const date = new Date(log.createdAt).toLocaleString();
            const statusClass = this.getSyncStatusClass(log.status);
            const direction = log.direction || 'both';
            
            html += `
                <tr>
                    <td>${date}</td>
                    <td>${log.syncType || 'manual'}</td>
                    <td><span class="badge badge-${direction === 'upload' ? 'info' : direction === 'download' ? 'primary' : 'secondary'}">${direction}</span></td>
                    <td>${log.recordsCount || 0}</td>
                    <td><span class="badge badge-${statusClass}">${log.status}</span></td>
                    <td>${log.errorMessage || '-'}</td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
    },

    getSyncStatusClass(status) {
        const classes = {
            'success': 'success',
            'partial': 'warning',
            'error': 'danger'
        };
        return classes[status] || 'default';
    },

    clearOldSyncLogs() {
        if (confirm('Are you sure you want to delete sync logs older than 90 days?')) {
            Storage.clearOldSyncLog(90);
            this.loadSyncLog(1);
            if (typeof Toast !== 'undefined') {
                Toast.success('Old sync logs cleared');
            }
        }
    }
};

window.AuditLog = AuditLog;

// batch-processor.js - Complete Version

const BatchProcessor = {
    // Queues for different data types
    queues: {
        attendance: [],
        staffAttendance: [],
        scores: [],
        students: [],
        users: [],
        testResults: [],
        homework: [],
        homework_submissions: []
    },

    // Timers for each queue
    timers: {},

    // Configuration
    config: {
        BATCH_SIZE: 50,           // Max items per batch
        BATCH_INTERVAL: 5000,      // 5 seconds (in milliseconds)
        MAX_RETRIES: 3              // Max retry attempts if save fails
    },

    // Add item to batch queue
    add(type, item) {
        if (!this.queues[type]) {
            console.warn(`Unknown queue type: ${type}`);
            return;
        }

        this.queues[type].push(item);
        console.log(`Added to ${type} queue. Queue size: ${this.queues[type].length}`);

        // Start timer if not already running
        if (!this.timers[type]) {
            this.timers[type] = setTimeout(() => {
                this.process(type);
            }, this.config.BATCH_INTERVAL);
        }

        // If queue is full, process immediately
        if (this.queues[type].length >= this.config.BATCH_SIZE) {
            clearTimeout(this.timers[type]);
            this.process(type);
        }
    },

    // Process a batch for specific type
    async process(type) {
        const queue = this.queues[type];
        if (!queue || queue.length === 0) {
            delete this.timers[type];
            return;
        }

        console.log(`🔄 Processing batch of ${queue.length} ${type} records...`);

        // Take all items from queue
        const items = [...queue];
        this.queues[type] = [];
        delete this.timers[type];

        // Try to save with Supabase
        await this.saveToSupabase(type, items);
    },

    // Save batch to Supabase
    async saveToSupabase(type, items) {
        let retries = 0;
        let success = false;

        while (!success && retries < this.config.MAX_RETRIES) {
            try {
                // Map local type to Supabase table name
                const tableMap = {
                    'attendance': 'attendance',
                    'staffAttendance': 'staff_attendance',
                    'scores': 'scores',
                    'students': 'students',
                    'users': 'users',
                    'testResults': 'test_results',
                    'homework': 'homework',
                    'homework_submissions': 'homework_submissions'
                };

                const tableName = tableMap[type];

                if (!tableName) {
                    throw new Error(`Unknown table for type: ${type}`);
                }

                // If Supabase is enabled, save there
                if (window.isSupabaseEnabled && isSupabaseEnabled()) {
                    const supabaseRes = getSupabase();
                    if (!supabaseRes) throw new Error('Supabase client not available');

                    // Prepare items for Supabase (use SupabaseSync logic if available)
                    let dataToSync = typeof SupabaseSync !== 'undefined'
                        ? items.map(item => SupabaseSync.prepareData(type, item))
                        : items;

                    // Handle special cases for unique constraints
                    let onConflict = 'id';
                    
                    // attendance has unique constraint on (student_id, date, term, year)
                    if (type === 'attendance') {
                        // For attendance, we need to handle duplicates properly
                        // Get existing records to filter out duplicates
                        if (dataToSync.length > 0) {
                            const firstItem = dataToSync[0];
                            if (firstItem.student_id && firstItem.date) {
                                // Check for existing records and update instead of insert
                                const { data: existing } = await supabaseRes
                                    .from(tableName)
                                    .select('id, student_id, date, term, year')
                                    .eq('student_id', firstItem.student_id)
                                    .eq('date', firstItem.date)
                                    .eq('term', firstItem.term || 'First')
                                    .eq('year', firstItem.year || new Date().getFullYear());
                                
                                if (existing && existing.length > 0) {
                                    // Already exists, skip this batch (attendance already marked)
                                    console.log(`⚠️ Attendance already exists for student ${firstItem.student_id} on ${firstItem.date}, skipping duplicate`);
                                    success = true;
                                    return;
                                }
                            }
                        }
                        onConflict = 'id';
                    }
                    
                    // staff_attendance has unique constraint on (staff_id, date, type)
                    if (type === 'staffAttendance') {
                        if (dataToSync.length > 0) {
                            const firstItem = dataToSync[0];
                            if (firstItem.staff_id && firstItem.date) {
                                const { data: existing } = await supabaseRes
                                    .from(tableName)
                                    .select('id, staff_id, date, type')
                                    .eq('staff_id', firstItem.staff_id)
                                    .eq('date', firstItem.date)
                                    .eq('type', firstItem.type || 'signin');
                                
                                if (existing && existing.length > 0) {
                                    console.log(`⚠️ Staff attendance already exists for ${firstItem.staff_id} on ${firstItem.date}, skipping duplicate`);
                                    success = true;
                                    return;
                                }
                            }
                        }
                        onConflict = 'staff_id,date,type';
                    }

                    // Use upsert with appropriate conflict resolution
                    const { error } = await supabaseRes
                        .from(tableName)
                        .upsert(dataToSync, { onConflict: onConflict });

                    if (error) throw error;

                    console.log(`✅ Successfully saved ${items.length} ${type} to Supabase (upsert)`);
                }
                // Fallback to localStorage
                else {
                    this.saveToLocalStorage(type, items);
                }

                success = true;

            } catch (error) {
                retries++;
                console.error(`❌ Error saving ${type} batch (attempt ${retries}):`, error);

                if (retries < this.config.MAX_RETRIES) {
                    // Wait 1 second before retrying
                    await new Promise(resolve => setTimeout(resolve, 1000));
                } else {
                    // Save to failed queue for manual review
                    this.saveToFailedQueue(type, items, error);
                }
            }
        }
    },

    // Fallback: Save to localStorage
    saveToLocalStorage(type, items) {
        const storage = Storage || window.Storage;
        if (!storage) {
            console.error('Storage not available');
            return;
        }

        // Get existing data
        const existing = storage.getData(type) || [];

        // Add new items with IDs if needed
        items.forEach(item => {
            if (!item.id) {
                item.id = storage.generateId();
            }
            if (!item.createdAt) {
                item.createdAt = new Date().toISOString();
            }
            existing.push(item);
        });

        // Save back
        storage.setData(type, existing);
        console.log(`✅ Saved ${items.length} ${type} to localStorage`);
    },

    // Save failed items for manual recovery
    saveToFailedQueue(type, items, error) {
        const failedKey = `failed_${type}_${Date.now()}`;
        const failedData = {
            type: type,
            items: items,
            error: error.message,
            timestamp: new Date().toISOString()
        };

        localStorage.setItem(failedKey, JSON.stringify(failedData));
        console.warn(`⚠️ Failed items saved to ${failedKey} for manual recovery`);

        // Show toast notification if available
        if (window.Toast) {
            Toast.error(`Failed to save ${items.length} ${type}. Check console.`);
        }
    },

    // Process all queues (call this before page unload)
    async processAll() {
        console.log('Processing all remaining queues...');
        const types = Object.keys(this.queues);

        for (const type of types) {
            if (this.queues[type].length > 0) {
                if (this.timers[type]) {
                    clearTimeout(this.timers[type]);
                }
                await this.process(type);
            }
        }
    },

    // Get queue statistics
    getStats() {
        const stats = {};
        Object.keys(this.queues).forEach(type => {
            stats[type] = {
                queueSize: this.queues[type].length,
                hasTimer: !!this.timers[type]
            };
        });
        return stats;
    }
};

// Auto-process all queues when user leaves page
window.addEventListener('beforeunload', () => {
    BatchProcessor.processAll();
});

// Make available globally
window.BatchProcessor = BatchProcessor;
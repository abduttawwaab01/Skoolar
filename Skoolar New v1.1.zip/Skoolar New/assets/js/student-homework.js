const StudentHomework = {
    loadHomework() {
        const student = this.getCurrentStudent();
        if (!student) {
            this.showError('Student not found');
            return;
        }
        
        const schoolId = this.getCurrentSchoolId();
        if (!schoolId) {
            this.showError('School not found');
            return;
        }
        
        const statusFilter = document.getElementById('homeworkStatusFilter')?.value || 'all';
        
        const homeworks = Storage.getData('homework')?.filter(h => 
            h.schoolId === schoolId && 
            h.class === student.class &&
            h.status === 'active'
        ) || [];
        
        const submissions = Storage.getStudentHomeworkSubmissions(student.id, schoolId);
        const submissionMap = {};
        submissions.forEach(s => {
            submissionMap[s.homeworkId] = s;
        });
        
        const filteredHomeworks = homeworks.filter(homework => {
            if (statusFilter === 'all') return true;
            const submission = submissionMap[homework.id];
            if (!submission) return statusFilter === 'pending';
            return submission.status === statusFilter;
        });
        
        this.renderHomeworkList(filteredHomeworks, submissionMap);
    },

    getCurrentStudent() {
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentStudent) {
            return StudentAuth.getCurrentStudent();
        }
        return null;
    },

    getCurrentSchoolId() {
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentSchoolId) {
            return StudentAuth.getCurrentSchoolId();
        }
        return null;
    },

    renderHomeworkList(homeworks, submissionMap) {
        const tbody = document.getElementById('homeworkTableBody');
        if (!tbody) return;
        
        if (homeworks.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center">
                        <div class="empty-state">
                            <i class="fas fa-tasks"></i>
                            <p>No homework assignments found</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }
        
        let html = '';
        homeworks.forEach(homework => {
            const submission = submissionMap[homework.id];
            const dueDate = new Date(homework.due_date).toLocaleDateString();
            const status = this.getStatusInfo(submission);
            const actions = this.getActionButtons(homework, submission);
            
            html += `
                <tr>
                    <td>
                        <strong>${homework.title}</strong>
                        ${homework.description ? `<br><small class="text-muted">${this.truncateText(homework.description, 100)}</small>` : ''}
                    </td>
                    <td>${homework.subject}</td>
                    <td>${dueDate}</td>
                    <td><span class="badge badge-${status.class}">${status.label}</span></td>
                    <td>${actions}</td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
    },

    getStatusInfo(submission) {
        if (!submission) {
            return { label: 'Pending', class: 'warning' };
        }
        switch (submission.status) {
            case 'submitted':
                return { label: 'Submitted', class: 'info' };
            case 'graded':
                return { label: `Graded (${submission.grade}%)`, class: 'success' };
            default:
                return { label: 'Unknown', class: 'default' };
        }
    },

    getActionButtons(homework, submission) {
        if (!submission) {
            return `<button class="btn btn-sm btn-primary" onclick="StudentHomework.showSubmitModal('${homework.id}')">Submit</button>`;
        }
        
        if (submission.status === 'submitted' || submission.status === 'graded') {
            return `<button class="btn btn-sm btn-outline" onclick="StudentHomework.viewSubmission('${homework.id}')">View</button>`;
        }
        
        return '';
    },

    truncateText(text, maxLength) {
        if (!text) return '';
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    },

    showSubmitModal(homeworkId) {
        const homework = Storage.getData('homework')?.find(h => h.id === homeworkId);
        if (!homework) {
            Toast.error('Homework not found');
            return;
        }
        
        const modalHtml = `
            <div class="modal-overlay" id="submitHomeworkModal" style="display: none;">
                <div class="modal" style="max-width: 600px;">
                    <div class="modal-header">
                        <h3 class="modal-title">Submit Homework</h3>
                        <button class="modal-close" onclick="Modal.hide('submitHomeworkModal')">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Assignment</label>
                            <p><strong>${homework.title}</strong></p>
                            <small class="text-muted">${homework.description || ''}</small>
                        </div>
                        <div class="form-group">
                            <label>Your Answer</label>
                            <textarea id="homeworkAnswer" class="form-control" rows="6" placeholder="Type your answer here..."></textarea>
                        </div>
                        <div class="form-group">
                            <label>Attachments (Images only, max 5MB each, auto-compressed)</label>
                            <input type="file" id="homeworkAttachments" class="form-control" accept="image/*" multiple>
                            <small class="text-muted">You can select multiple images. They will be compressed automatically.</small>
                            <div id="attachmentPreview" style="margin-top: 10px; display: flex; flex-wrap: wrap; gap: 10px;"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" onclick="Modal.hide('submitHomeworkModal')">Cancel</button>
                        <button class="btn btn-primary" onclick="StudentHomework.submitHomework('${homeworkId}')">Submit Assignment</button>
                    </div>
                </div>
            </div>
        `;
        
        Modal.showCustom(modalHtml);
        
        // Add file change listener for preview
        const fileInput = document.getElementById('homeworkAttachments');
        if (fileInput) {
            fileInput.addEventListener('change', function(e) {
                StudentHomework.previewAttachments(e.target.files);
            });
        }
    },
    
    previewAttachments(files) {
        const preview = document.getElementById('attachmentPreview');
        if (!preview) return;
        
        preview.innerHTML = '';
        
        Array.from(files).forEach((file, index) => {
            if (!file.type.startsWith('image/')) {
                Toast.warning(`File "${file.name}" is not an image and will be skipped`);
                return;
            }
            
            if (file.size > 5 * 1024 * 1024) {
                Toast.warning(`File "${file.name}" exceeds 5MB and will be skipped`);
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.style.width = '80px';
                img.style.height = '80px';
                img.style.objectFit = 'cover';
                img.style.borderRadius = '4px';
                img.title = file.name;
                preview.appendChild(img);
            };
            reader.readAsDataURL(file);
        });
    },
    
    async compressImage(file) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const maxSize = 800;
                
                if (width > maxSize || height > maxSize) {
                    if (width > height) {
                        height = Math.round((height * maxSize) / width);
                        width = maxSize;
                    } else {
                        width = Math.round((width * maxSize) / height);
                        height = maxSize;
                    }
                }
                
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                
                canvas.toBlob((blob) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve({
                        name: file.name,
                        type: file.type,
                        size: blob.size,
                        data: reader.result,
                        compressed: true
                    });
                    reader.onerror = reject;
                    reader.readAsDataURL(blob);
                }, 'image/jpeg', 0.7);
            };
            img.onerror = reject;
            img.src = URL.createObjectURL(file);
        });
    },

    async submitHomework(homeworkId) {
        const answerText = document.getElementById('homeworkAnswer')?.value?.trim();
        const fileInput = document.getElementById('homeworkAttachments');
        
        if (!answerText && (!fileInput || fileInput.files.length === 0)) {
            Toast.error('Please enter your answer or attach a file');
            return;
        }
        
        const student = this.getCurrentStudent();
        const schoolId = this.getCurrentSchoolId();
        
        try {
            // Process attachments with compression
            const attachments = [];
            if (fileInput && fileInput.files.length > 0) {
                Toast.info('Compressing images...');
                for (const file of fileInput.files) {
                    if (file.type.startsWith('image/')) {
                        try {
                            const compressed = await this.compressImage(file);
                            attachments.push(compressed);
                        } catch (err) {
                            console.warn('Failed to compress image:', file.name, err);
                        }
                    }
                }
            }
            
            // Use normalized method with schoolId parameter
            Storage.addHomeworkSubmission(
                homeworkId,
                student.id,
                student.name,
                schoolId,
                answerText,
                attachments
            );
            
            // Trigger data sync event for real-time updates
            window.dispatchEvent(new CustomEvent('skoolar_data_updated', { 
                detail: { key: 'homework_submissions', action: 'create' } 
            }));
            
            // Clear file input
            if (fileInput) fileInput.value = '';
            document.getElementById('attachmentPreview').innerHTML = '';
            
            Toast.success('Homework submitted successfully');
            Modal.hide('submitHomeworkModal');
            this.loadHomework();
        } catch (error) {
            Toast.error('Failed to submit homework: ' + error.message);
        }
    },

     viewSubmission(homeworkId) {
         const student = this.getCurrentStudent();
         const schoolId = this.getCurrentSchoolId();
         const submissions = Storage.getStudentHomeworkSubmissions(student.id, schoolId, homeworkId);
         const submission = submissions[0];
         
         if (!submission) {
             Toast.error('Submission not found');
             return;
         }
         
         const homework = Storage.getData('homework')?.find(h => h.id === homeworkId);
         if (!homework) return;
         
         let attachmentsHtml = '';
         if (submission.attachments && submission.attachments.length > 0) {
             attachmentsHtml = `
                 <div class="form-group">
                     <label>Attachments (${submission.attachments.length})</label>
                     <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
                         ${submission.attachments.map(att => `
                             <div style="border: 1px solid var(--gray); border-radius: 8px; padding: 8px; text-align: center; background: #fff;">
                                 <img src="${att.data}" alt="${att.name}" style="width: 120px; height: 120px; object-fit: cover; border-radius: 4px; margin-bottom: 5px;">
                                 <div style="font-size: 11px; color: var(--gray); max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${att.name}</div>
                             </div>
                         `).join('')}
                     </div>
                 </div>
             `;
         }
         
         let feedbackHtml = '';
         if (submission.grade !== null) {
             feedbackHtml = `
                 <div class="form-group">
                     <label>Grade</label>
                     <p><strong>${submission.grade}%</strong> (out of ${homework.total_marks || 100} marks)</p>
                 </div>
                 <div class="form-group">
                     <label>Feedback</label>
                     <p>${submission.feedback || 'No feedback provided'}</p>
                 </div>
                 <div class="form-group">
                     <label>Graded By</label>
                     <p>${submission.gradedBy || 'System'}</p>
                 </div>
             `;
         }
         
         const modalHtml = `
             <div class="modal-overlay" id="viewSubmissionModal" style="display: none;">
                 <div class="modal" style="max-width: 700px;">
                     <div class="modal-header">
                         <h3 class="modal-title">${homework.title}</h3>
                         <button class="modal-close" onclick="Modal.hide('viewSubmissionModal')">&times;</button>
                     </div>
                     <div class="modal-body">
                         <div class="form-group">
                             <label>Due Date</label>
                             <p>${new Date(homework.due_date).toLocaleDateString()}</p>
                         </div>
                         <div class="form-group">
                             <label>Your Answer</label>
                             <div style="background: var(--lighter); padding: 15px; border-radius: 8px; white-space: pre-wrap;">${submission.answerText}</div>
                         </div>
                         ${attachmentsHtml}
                         <div class="form-group">
                             <label>Submitted</label>
                             <p>${new Date(submission.submissionDate).toLocaleString()}</p>
                         </div>
                         ${feedbackHtml}
                     </div>
                     <div class="modal-footer">
                         <button class="btn btn-secondary" onclick="Modal.hide('viewSubmissionModal')">Close</button>
                     </div>
                 </div>
             </div>
         `;
         
         Modal.showCustom(modalHtml);
     },

    showError(message) {
        const tbody = document.getElementById('homeworkTableBody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center text-danger">
                        <p>${message}</p>
                    </td>
                </tr>
            `;
        }
    }
};

window.StudentHomework = StudentHomework;

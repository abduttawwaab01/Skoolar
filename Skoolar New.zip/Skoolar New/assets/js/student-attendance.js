const StudentAttendance = {
    loadAttendance() {
        const student = this.getCurrentStudent();
        if (!student) {
            this.showError('Student not found');
            return;
        }
        
        const schoolId = this.getCurrentSchoolId();
        const term = document.getElementById('attendanceTermSelect')?.value || 'First';
        const month = document.getElementById('attendanceMonthSelect')?.value || '';
        
        let attendance = Storage.getData('attendance')?.filter(a => 
            a.studentId === student.id && 
            a.schoolId === schoolId &&
            a.term === term
        ) || [];
        
        if (month) {
            const year = new Date().getFullYear();
            const monthStart = new Date(`${year}-${month}-01`).getTime();
            const monthEnd = new Date(`${year}-${month}-31`).getTime();
            attendance = attendance.filter(a => {
                const date = new Date(a.date).getTime();
                return date >= monthStart && date <= monthEnd;
            });
        }
        
        attendance.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        this.renderStats(attendance);
        this.renderTable(attendance);
    },

    getCurrentStudent() {
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentStudent) {
            return StudentAuth.getCurrentStudent();
        }
        return null;
    },

    getCurrentSchoolId() {
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentSchoolId) {
            return StudentAuth.getCurrentSchoolId();
        }
        return null;
    },

    renderStats(attendance) {
        const total = attendance.length;
        const present = attendance.filter(a => a.status === 'present').length;
        const absent = attendance.filter(a => a.status === 'absent').length;
        const late = attendance.filter(a => a.status === 'late').length;
        const excused = attendance.filter(a => a.status === 'excused').length;
        
        const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
        
        document.getElementById('attendanceTotal').textContent = total;
        document.getElementById('attendancePresent').textContent = present;
        document.getElementById('attendanceAbsent').textContent = absent;
        document.getElementById('attendancePercentage').textContent = percentage + '%';
        
        const percentageEl = document.getElementById('attendancePercentage');
        if (percentageEl) {
            if (percentage >= 75) {
                percentageEl.parentElement.parentElement.querySelector('.stat-icon').style.background = 'var(--success-light)';
                percentageEl.parentElement.parentElement.querySelector('.stat-icon').style.color = 'var(--success)';
            } else if (percentage >= 50) {
                percentageEl.parentElement.parentElement.querySelector('.stat-icon').style.background = 'var(--warning-light)';
                percentageEl.parentElement.parentElement.querySelector('.stat-icon').style.color = 'var(--warning)';
            } else {
                percentageEl.parentElement.parentElement.querySelector('.stat-icon').style.background = 'var(--danger-light)';
                percentageEl.parentElement.parentElement.querySelector('.stat-icon').style.color = 'var(--danger)';
            }
        }
    },

    renderTable(attendance) {
        const tbody = document.getElementById('attendanceTableBody');
        if (!tbody) return;
        
        if (attendance.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="3" class="text-center">
                        <div class="empty-state">
                            <i class="fas fa-calendar-check"></i>
                            <p>No attendance records found</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }
        
        let html = '';
        attendance.forEach(record => {
            const date = new Date(record.date).toLocaleDateString('en-US', {
                weekday: 'short',
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
            
            const statusClass = this.getStatusClass(record.status);
            const statusLabel = this.getStatusLabel(record.status);
            
            html += `
                <tr>
                    <td>${date}</td>
                    <td><span class="badge badge-${statusClass}">${statusLabel}</span></td>
                    <td>${record.remarks || '-'}</td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
    },

    getStatusClass(status) {
        const classes = {
            'present': 'success',
            'absent': 'danger',
            'late': 'warning',
            'excused': 'info'
        };
        return classes[status] || 'default';
    },

    getStatusLabel(status) {
        const labels = {
            'present': 'Present',
            'absent': 'Absent',
            'late': 'Late',
            'excused': 'Excused'
        };
        return labels[status] || status;
    },

    showError(message) {
        const tbody = document.getElementById('attendanceTableBody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="3" class="text-center text-danger">
                        <p>${message}</p>
                    </td>
                </tr>
            `;
        }
    }
};

window.StudentAttendance = StudentAttendance;

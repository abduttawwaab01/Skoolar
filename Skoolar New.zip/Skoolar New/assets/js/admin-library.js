const AdminLibrary = {
    currentTab: 'books',

    init() {
        this.loadLibrary();
    },

    showTab(tab) {
        this.currentTab = tab;
        document.querySelectorAll('#librarySection .tab-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.tab === tab) btn.classList.add('active');
        });
        this.loadLibrary();
    },

    loadLibrary() {
        const tab = this.currentTab;
        if (tab === 'books') this.renderBooks();
        else if (tab === 'checkouts') this.renderCheckouts();
        else if (tab === 'overdue') this.renderOverdue();
    },

    renderBooks() {
        const schoolId = Auth.getCurrentSchoolId();
        const books = Storage.getData('library_books')?.filter(b => b.schoolId === schoolId) || [];
        const container = document.getElementById('adminLibraryTable');
        if (!container) return;

        // Update stats
        const totalEl = document.getElementById('adminTotalBooks');
        const availEl = document.getElementById('adminAvailableBooks');
        const borrowEl = document.getElementById('adminBorrowedBooks');
        if (totalEl) totalEl.textContent = books.length;
        if (availEl) availEl.textContent = books.filter(b => b.status === 'available').length;
        if (borrowEl) borrowEl.textContent = books.filter(b => b.status === 'borrowed').length;

        if (books.length === 0) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-book-reader"></i><h3>No books</h3><p>Add books to get started</p></div>';
            return;
        }

        let html = '<div class="table-container"><table class="table"><thead><tr><th>Title</th><th>Author</th><th>ISBN</th><th>Category</th><th>Qty</th><th>Available</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        books.forEach(book => {
            html += `<tr>
                <td>${book.title}</td>
                <td>${book.author || '-'}</td>
                <td>${book.isbn || '-'}</td>
                <td>${book.category || '-'}</td>
                <td>${book.quantity}</td>
                <td>${book.available}</td>
                <td><span class="badge badge-${book.status === 'available' ? 'success' : 'warning'}">${book.status}</span></td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="AdminLibrary.deleteBook('${book.id}')"><i class="fas fa-trash"></i></button>
                </td>
            </tr>`;
        });
        html += '</tbody></table></div>';
        container.innerHTML = html;
    },

    renderCheckouts() {
        const schoolId = Auth.getCurrentSchoolId();
        const loans = Storage.getData('bookLoans')?.filter(l => l.schoolId === schoolId && l.status === 'borrowed') || [];
        const container = document.getElementById('adminLibraryTable');
        if (!container) return;

        // Update stats
        const totalBooks = Storage.getData('library_books')?.filter(b => b.schoolId === schoolId).length || 0;
        const availableBooks = Storage.getData('library_books')?.filter(b => b.schoolId === schoolId && b.status === 'available').length || 0;
        const borrowedCount = loans.length;
        const totalEl = document.getElementById('adminTotalBooks');
        const availEl = document.getElementById('adminAvailableBooks');
        const borrowEl = document.getElementById('adminBorrowedBooks');
        if (totalEl) totalEl.textContent = totalBooks;
        if (availEl) availEl.textContent = availableBooks;
        if (borrowEl) borrowEl.textContent = borrowedCount;

        if (loans.length === 0) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-book-reader"></i><h3>No active checkouts</h3><p>All books are in the library</p></div>';
            return;
        }

        let html = '<div class="table-container"><table class="table"><thead><tr><th>Student</th><th>Class</th><th>Book</th><th>Checkout Date</th><th>Due Date</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        loans.forEach(loan => {
            const student = Storage.getData('students')?.find(s => s.id === loan.studentId);
            const book = Storage.getData('library_books')?.find(b => b.id === loan.bookId);
            const dueDate = new Date(loan.dueDate).toLocaleDateString();
            const isOverdue = new Date(loan.dueDate) < new Date();
            html += `<tr style="${isOverdue ? 'background: var(--danger-light);' : ''}">
                <td>${student?.name || loan.studentName}</td>
                <td>${student?.class || '-'}</td>
                <td>${book?.title || 'Unknown Book'}</td>
                <td>${new Date(loan.checkoutDate).toLocaleDateString()}</td>
                <td>${dueDate} ${isOverdue ? '<br><small class="text-danger">Overdue!</small>' : ''}</td>
                <td><span class="badge badge-${isOverdue ? 'danger' : 'warning'}">${isOverdue ? 'Overdue' : 'Borrowed'}</span></td>
                <td>
                    <button class="btn btn-sm btn-success" onclick="AdminLibrary.returnBook('${loan.id}')">
                        <i class="fas fa-undo"></i> Return
                    </button>
                </td>
            </tr>`;
        });
        html += '</tbody></table></div>';
        container.innerHTML = html;
    },

    renderOverdue() {
        const schoolId = Auth.getCurrentSchoolId();
        const today = new Date().toISOString().split('T')[0];
        const overdueLoans = Storage.getData('bookLoans')?.filter(l => 
            l.schoolId === schoolId && l.status === 'borrowed' && l.dueDate < today
        ) || [];
        const container = document.getElementById('adminLibraryTable');
        if (!container) return;

        const totalFines = overdueLoans.reduce((sum, l) => sum + (l.fineAmount || 0), 0);
        const totalBooks = Storage.getData('library_books')?.filter(b => b.schoolId === schoolId).length || 0;
        const availableBooks = Storage.getData('library_books')?.filter(b => b.schoolId === schoolId && b.status === 'available').length || 0;
        const borrowedCount = Storage.getData('bookLoans')?.filter(l => l.schoolId === schoolId && l.status === 'borrowed').length || 0;
        const totalEl = document.getElementById('adminTotalBooks');
        const availEl = document.getElementById('adminAvailableBooks');
        const borrowEl = document.getElementById('adminBorrowedBooks');
        if (totalEl) totalEl.textContent = totalBooks;
        if (availEl) availEl.textContent = availableBooks;
        if (borrowEl) borrowEl.textContent = `${borrowedCount} (₦${totalFines.toFixed(2)})`;

        if (overdueLoans.length === 0) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-check-circle"></i><h3>No overdue books</h3><p>All books are returned on time!</p></div>';
            return;
        }

        let html = '<div class="table-container"><table class="table"><thead><tr><th>Student</th><th>Class</th><th>Book</th><th>Checkout</th><th>Due Date</th><th>Days Overdue</th><th>Fine</th><th>Actions</th></tr></thead><tbody>';
        overdueLoans.forEach(loan => {
            const student = Storage.getData('students')?.find(s => s.id === loan.studentId);
            const book = Storage.getData('library_books')?.find(b => b.id === loan.bookId);
            const dueDate = new Date(loan.dueDate);
            const todayDate = new Date();
            const daysOverdue = Math.max(0, Math.floor((todayDate - dueDate) / (1000 * 60 * 60 * 24)));
            const fine = Storage.calculateLibraryFine(dueDate, todayDate, schoolId);
            html += `<tr>
                <td>
                    <strong>${student?.name || loan.studentName}</strong>
                    <br><small class="text-muted">${student?.class || ''}</small>
                </td>
                <td>${book?.title || 'Unknown Book'}</td>
                <td>${new Date(loan.checkoutDate).toLocaleDateString()}</td>
                <td style="color: var(--danger); font-weight: 600;">${loan.dueDate}</td>
                <td><span class="badge badge-danger">${daysOverdue} day${daysOverdue !== 1 ? 's' : ''}</span></td>
                <td>₦${fine.toFixed(2)}</td>
                <td>
                    <button class="btn btn-sm btn-success" onclick="AdminLibrary.returnBook('${loan.id}')">
                        <i class="fas fa-undo"></i> Return
                    </button>
                </td>
            </tr>`;
        });
        html += '</tbody></table></div>';
        container.innerHTML = html;
    },

    returnBook(loanId) {
        Modal.confirm({
            title: 'Return Book',
            message: 'Mark this book as returned?',
            onConfirm: () => {
                try {
                    const loan = Storage.returnBook(loanId);
                    Toast.success(`Book returned. Fine: ₦${loan.fineAmount.toFixed(2)}`);
                    this.loadLibrary();
                } catch (error) {
                    Toast.error('Failed to return book: ' + error.message);
                }
            }
        });
    },

    deleteBook(bookId) {
        Modal.confirm({
            title: 'Delete Book',
            message: 'Are you sure? This cannot be undone.',
            onConfirm: () => {
                let books = Storage.getData('library_books') || [];
                books = books.filter(b => b.id !== bookId);
                Storage.setData('library_books', books);
                Toast.success('Book deleted');
                this.loadLibrary();
            }
        });
    },

    showAddBookModal() {
        const html = `
            <form id="addBookForm">
                <div class="form-group"><label class="form-label">Title *</label><input type="text" id="bookTitle" class="form-control" required></div>
                <div class="form-row">
                    <div class="form-group"><label class="form-label">Author</label><input type="text" id="bookAuthor" class="form-control"></div>
                    <div class="form-group"><label class="form-label">ISBN</label><input type="text" id="bookIsbn" class="form-control"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label class="form-label">Category</label><input type="text" id="bookCategory" class="form-control"></div>
                    <div class="form-group"><label class="form-label">Quantity</label><input type="number" id="bookQty" class="form-control" value="1" min="1"></div>
                </div>
                <div class="flex gap-2 mt-3">
                    <button type="button" class="btn btn-secondary" onclick="Modal.hide('addBookModal')">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="AdminLibrary.addBook()"><i class="fas fa-save"></i> Save</button>
                </div>
            </form>
        `;
        document.getElementById('addBookModalBody').innerHTML = html;
        Modal.show('addBookModal');
    },

    addBook() {
        const schoolId = Auth.getCurrentSchoolId();
        const book = {
            id: Storage.generateUniqueId('BK'),
            schoolId,
            title: document.getElementById('bookTitle').value,
            author: document.getElementById('bookAuthor').value,
            isbn: document.getElementById('bookIsbn').value,
            category: document.getElementById('bookCategory').value,
            quantity: parseInt(document.getElementById('bookQty').value) || 1,
            available: parseInt(document.getElementById('bookQty').value) || 1,
            status: 'available',
            created_at: new Date().toISOString()
        };
        const books = Storage.getData('library_books') || [];
        books.push(book);
        Storage.setData('library_books', books);
        Toast.success('Book added');
        Modal.hide('addBookModal');
        this.loadLibrary();
    }
};

window.AdminLibrary = AdminLibrary;

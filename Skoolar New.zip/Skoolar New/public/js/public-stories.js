// Public Stories Module
// Handles stories/novels reading platform for public pages
// Mirrors PublicContent pattern but dedicated to stories

const Stories = {
    init() {
        this.ensureDataExists();
        // Note: UI event binding is handled by StoriesPage in stories.html
    },

    ensureDataExists() {
        // Load sample stories if none exist
        const existingStories = Storage.getData('stories') || [];
        if (existingStories.length === 0) {
            const sampleStories = this.getSampleStories();
            Storage.setData('stories', sampleStories);
            console.log(`Loaded ${sampleStories.length} sample stories`);
        }
    },

    // Data filter method (returns filtered array, does NOT update UI)
    filterStories() {
        // This is a data-only filter; UI rendering is handled by StoriesPage
        // Kept for potential API compatibility but not used for UI updates
        console.log('Stories.filterStories called - use StoriesPage.filterStories() for UI');
    },

    // ==================== DATA ACCESS ====================

    getData() {
        return Storage.getData('stories') || [];
    },

    saveData(storiesArray) {
        Storage.setData('stories', storiesArray);
    },

    getInteractions() {
        return Storage.getData('storyInteractions') || [];
    },

    saveInteractions(interactions) {
        Storage.setData('storyInteractions', interactions);
    },

    getComments() {
        return Storage.getData('storyComments') || [];
    },

    saveComments(comments) {
        Storage.setData('storyComments', comments);
    },

    getSubmissions(status = null) {
        const submissions = Storage.getData('storySubmissions') || [];
        return status ? submissions.filter(s => s.status === status) : submissions;
    },

    saveSubmissions(submissions) {
        Storage.setData('storySubmissions', submissions);
    },

    // ==================== STORIES CRUD ====================

    getStories(status = 'published', options = {}) {
        const stories = this.getData();
        let filtered = stories.filter(s => status ? s.status === status : true);

        // Apply filters
        if (options.genre) {
            stories = stories.filter(s => s.genre === options.genre);
        }
        if (options.ageGroup) {
            stories = stories.filter(s => s.age_group === options.ageGroup);
        }
        if (options.featuredOnly) {
            stories = stories.filter(s => s.featured && new Date(s.featured_until) > new Date());
        }
        if (options.search) {
            const q = options.search.toLowerCase();
            stories = stories.filter(s =>
                s.title.toLowerCase().includes(q) ||
                s.description.toLowerCase().includes(q) ||
                s.author_name.toLowerCase().includes(q) ||
                (s.tags && s.tags.some(t => t.toLowerCase().includes(q)))
            );
        }

        // Sorting
        const sortField = options.sortBy || 'published_at';
        const sortOrder = options.sortOrder || 'desc';
        stories.sort((a, b) => {
            let aVal = a[sortField] || 0;
            let bVal = b[sortField] || 0;
            if (sortField === 'engagement') {
                aVal = (a.engagement?.likes || 0) + (a.engagement?.rating_sum || 0);
                bVal = (b.engagement?.likes || 0) + (b.engagement?.rating_sum || 0);
            }
            if (sortOrder === 'desc') return bVal > aVal ? 1 : -1;
            return aVal > bVal ? 1 : -1;
        });

        return filtered;
    },

    getStory(slugOrId) {
        const stories = this.getData();
        return stories.find(s =>
            s.slug === slugOrId || s.id === slugOrId
        ) || null;
    },

    getFeaturedStories(limit = 5) {
        return this.getStories('published', { featuredOnly: true }).slice(0, limit);
    },

    getPopularStories(limit = 10, days = 30) {
        const stories = this.getStories('published');
        // Sort by engagement score (likes + comments + shares weighted)
        return stories.sort((a, b) => {
            const scoreA = (a.engagement?.likes || 0) * 2 + (a.engagement?.comments || 0) * 3 + (a.engagement?.shares || 0);
            const scoreB = (b.engagement?.likes || 0) * 2 + (b.engagement?.comments || 0) * 3 + (b.engagement?.shares || 0);
            return scoreB - scoreA;
        }).slice(0, limit);
    },

    getTopRatedStories(limit = 10, minRatings = 5) {
        const stories = this.getStories('published').filter(s =>
            (s.engagement?.rating_count || 0) >= minRatings
        );
        return stories.sort((a, b) => {
            const avgA = (a.engagement?.rating_sum || 0) / (a.engagement?.rating_count || 1);
            const avgB = (b.engagement?.rating_sum || 0) / (b.engagement?.rating_count || 1);
            return avgB - avgA;
        }).slice(0, limit);
    },

    createStory(data) {
        const story = {
            id: 'STORY' + Date.now(),
            slug: this.slugify(data.title) + '-' + Date.now().toString(36),
            title: data.title,
            subtitle: data.subtitle || '',
            author_name: data.author_name,
            author_bio: data.author_bio || '',
            author_photo: data.author_photo || '',
            cover_image: data.cover_image || '',
            description: data.description,
            content: data.content,
            content_type: data.content_type || 'html',
            word_count: data.word_count || this.countWords(data.content),
            read_time_minutes: data.read_time_minutes || this.estimateReadTime(data.content),
            genre: data.genre,
            age_group: data.age_group || 'all',
            status: data.status || 'draft',
            featured: data.featured || false,
            featured_until: data.featured_until || null,
            allow_comments: data.allow_comments !== false,
            downloadable: data.downloadable || false,
            downloadable_formats: data.downloadable_formats || ['pdf', 'txt'],
            tags: data.tags || [],
            engagement: {
                views: 0,
                likes: 0,
                dislikes: 0,
                shares: 0,
                comments: 0,
                rating_sum: 0,
                rating_count: 0
            },
            submission_data: data.submission_data || null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            published_at: data.status === 'published' ? new Date().toISOString() : null,
            supabase_last_sync: null
        };

        const stories = this.getData();
        stories.push(story);
        this.saveData(stories);
        return story;
    },

    updateStory(id, updates) {
        const stories = this.getData();
        const index = stories.findIndex(s => s.id === id);
        if (index === -1) return { success: false, error: 'Story not found' };

        stories[index] = {
            ...stories[index],
            ...updates,
            updated_at: new Date().toISOString()
        };

        // If publishing now, set published_at
        if (updates.status === 'published' && !stories[index].published_at) {
            stories[index].published_at = new Date().toISOString();
        }

        this.saveData(stories);
        return { success: true, story: stories[index] };
    },

    deleteStory(id) {
        const stories = this.getData();
        const index = stories.findIndex(s => s.id === id);
        if (index === -1) return { success: false, error: 'Story not found' };

        stories.splice(index, 1);
        this.saveData(stories);

        // Also delete associated interactions and comments
        const interactions = this.getInteractions().filter(i => i.story_id !== id);
        this.saveInteractions(interactions);
        const comments = this.getComments().filter(c => c.story_id !== id);
        this.saveComments(comments);

        return { success: true };
    },

    // ==================== INTERACTIONS ====================

    trackView(storyId, userId = null) {
        const interactions = this.getInteractions();
        const story = this.getStory(storyId);
        if (!story) return;

        // Increment view count in story
        const stories = this.getData();
        const storyIndex = stories.findIndex(s => s.id === storyId);
        if (storyIndex !== -1) {
            stories[storyIndex].engagement = stories[storyIndex].engagement || {};
            stories[storyIndex].engagement.views = (stories[storyIndex].engagement.views || 0) + 1;
            this.saveData(stories);
        }

        // Track interaction for unique view (userId or IP-based)
        // For simplicity, we just increment views; unique tracking needs more logic
    },

    likeStory(storyId, userId) {
        return this.toggleInteraction(storyId, userId, 'like');
    },

    dislikeStory(storyId, userId) {
        return this.toggleInteraction(storyId, userId, 'dislike');
    },

    shareStory(storyId, userId) {
        const interactions = this.getInteractions();
        const newInteraction = {
            id: 'INT' + Date.now(),
            story_id: storyId,
            user_id: userId || 'anonymous',
            user_ip: this.getClientIP(),
            interaction_type: 'share',
            rating_value: null,
            created_at: new Date().toISOString(),
            supabase_last_sync: null
        };
        interactions.push(newInteraction);
        this.saveInteractions(interactions);
        this.updateEngagement(storyId, 'shares', 1);
        return newInteraction;
    },

    downloadStory(storyId, userId) {
        const interactions = this.getInteractions();
        const newInteraction = {
            id: 'INT' + Date.now(),
            story_id: storyId,
            user_id: userId || 'anonymous',
            user_ip: this.getClientIP(),
            interaction_type: 'download',
            rating_value: null,
            created_at: new Date().toISOString(),
            supabase_last_sync: null
        };
        interactions.push(newInteraction);
        this.saveInteractions(interactions);
        this.updateEngagement(storyId, 'download_count', 1);
        return newInteraction;
    },

    rateStory(storyId, userId, rating) {
        if (rating < 1 || rating > 5) return { success: false, error: 'Invalid rating' };

        const interactions = this.getInteractions();
        const existingIndex = interactions.findIndex(i =>
            i.story_id === storyId &&
            i.user_id === userId &&
            i.interaction_type === 'rating'
        );

        if (existingIndex >= 0) {
            // Update existing rating
            interactions[existingIndex].rating_value = rating;
            interactions[existingIndex].updated_at = new Date().toISOString();
        } else {
            // Create new rating
            const newInteraction = {
                id: 'INT' + Date.now(),
                story_id: storyId,
                user_id: userId,
                user_ip: this.getClientIP(),
                interaction_type: 'rating',
                rating_value: rating,
                created_at: new Date().toISOString(),
                supabase_last_sync: null
            };
            interactions.push(newInteraction);
        }

        this.saveInteractions(interactions);
        this.recalculateRating(storyId);
        return { success: true };
    },

    toggleInteraction(storyId, userId, type) {
        const interactions = this.getInteractions();
        const existingIndex = interactions.findIndex(i =>
            i.story_id === storyId &&
            i.user_id === userId &&
            i.interaction_type === type
        );

        if (existingIndex >= 0) {
            // Remove interaction (toggle off)
            interactions.splice(existingIndex, 1);
            this.saveInteractions(interactions);
            this.updateEngagement(storyId, type + 's', -1);
            return { success: true, action: 'removed' };
        } else {
            // Add interaction
            const newInteraction = {
                id: 'INT' + Date.now(),
                story_id: storyId,
                user_id: userId,
                user_ip: this.getClientIP(),
                interaction_type: type,
                rating_value: null,
                created_at: new Date().toISOString(),
                supabase_last_sync: null
            };
            interactions.push(newInteraction);
            this.saveInteractions(interactions);
            this.updateEngagement(storyId, type + 's', 1);
            return { success: true, action: 'added' };
        }
    },

    getUserInteractions(storyId, userId) {
        const interactions = this.getInteractions();
        return interactions.filter(i =>
            i.story_id === storyId &&
            i.user_id === userId
        );
    },

    updateEngagement(storyId, field, delta) {
        const stories = this.getData();
        const storyIndex = stories.findIndex(s => s.id === storyId);
        if (storyIndex === -1) return;

        stories[storyIndex].engagement = stories[storyIndex].engagement || {};
        stories[storyIndex].engagement[field] = (stories[storyIndex].engagement[field] || 0) + delta;
        this.saveData(stories);
    },

    recalculateRating(storyId) {
        const interactions = this.getInteractions();
        const ratings = interactions.filter(i =>
            i.story_id === storyId && i.interaction_type === 'rating'
        );

        const sum = ratings.reduce((acc, r) => acc + (r.rating_value || 0), 0);
        const count = ratings.length;

        const stories = this.getData();
        const storyIndex = stories.findIndex(s => s.id === storyId);
        if (storyIndex !== -1) {
            stories[storyIndex].engagement.rating_sum = sum;
            stories[storyIndex].engagement.rating_count = count;
            this.saveData(stories);
        }
    },

    getAverageRating(storyId) {
        const story = this.getStory(storyId);
        const sum = story?.engagement?.rating_sum || 0;
        const count = story?.engagement?.rating_count || 0;
        return count > 0 ? (sum / count).toFixed(1) : 0;
    },

    // ==================== COMMENTS ====================

    getStoryComments(storyId, includeReplies = true) {
        const comments = this.getComments();
        let storyComments = comments.filter(c => c.story_id === storyId && c.status === 'approved');

        if (includeReplies) {
            // Build tree
            const map = {};
            const roots = [];

            storyComments.forEach(c => {
                map[c.id] = { ...c, replies: [] };
                if (c.parent_id && map[c.parent_id]) {
                    map[c.parent_id].replies.push(map[c.id]);
                } else {
                    roots.push(map[c.id]);
                }
            });

            return roots.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        }

        return storyComments.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    },

    addComment(storyId, userId, userName, userEmail, content, parentId = null) {
        const comments = this.getComments();
        const newComment = {
            id: 'CMT' + Date.now(),
            story_id: storyId,
            user_id: userId || 'guest_' + Date.now(),
            user_name: userName.trim(),
            user_email: userEmail || '',
            parent_id: parentId || null,
            content: content.trim(),
            status: 'approved', // Auto-approve for now; could require moderation
            reported: false,
            likes: 0,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            supabase_last_sync: null
        };

        comments.push(newComment);
        this.saveComments(comments);

        // Update comment count
        this.updateEngagement(storyId, 'comments', 1);

        return newComment;
    },

    deleteComment(commentId, userIdIsAdmin = false) {
        const comments = this.getComments();
        const commentIndex = comments.findIndex(c => c.id === commentId);
        if (commentIndex === -1) return { success: false, error: 'Comment not found' };

        // Only admin can delete or author can delete their own
        // For simplicity, allow any delete in this version
        comments.splice(commentIndex, 1);
        this.saveComments(comments);
        return { success: true };
    },

    // ==================== SUBMISSIONS ====================

    submitStory(data) {
        const submissions = this.getSubmissions();
        const submission = {
            id: 'SUB' + Date.now(),
            story_id: null, // Not created yet
            submitter_id: data.submitter_id || 'anonymous',
            submitter_name: data.submitter_name,
            submitter_email: data.submitter_email || '',
            submitter_role: data.submitter_role || 'user',
            submitter_school_id: data.submitter_school_id || null,
            submission: {
                title: data.title,
                subtitle: data.subtitle || '',
                author_name: data.author_name,
                author_bio: data.author_bio || '',
                author_photo: data.author_photo || '',
                description: data.description,
                genre: data.genre,
                age_group: data.age_group || 'all',
                content: data.content,
                content_type: data.content_type || 'html',
                word_count: data.word_count || this.countWords(data.content),
                read_time_minutes: data.read_time_minutes || this.estimateReadTime(data.content),
                cover_image: data.cover_image || '',
                allow_comments: data.allow_comments !== false,
                downloadable: data.downloadable || false,
                downloadable_formats: data.downloadable_formats || ['pdf', 'txt'],
                tags: data.tags || []
            },
            status: 'pending_review',
            reviewer_id: null,
            reviewer_notes: '',
            reviewed_at: null,
            publish_immediately: data.publish_immediately || false,
            created_at: new Date().toISOString(),
            supabase_last_sync: null
        };

        submissions.push(submission);
        this.saveSubmissions(submissions);
        return submission;
     },

     reviewSubmission(submissionId, decision, reviewerId, notes = '') {
        const submissions = this.getSubmissions();
        const index = submissions.findIndex(s => s.id === submissionId);
        if (index === -1) return { success: false, error: 'Submission not found' };

        submissions[index].status = decision; // 'approved' or 'rejected' or 'needs_revision'
        submissions[index].reviewer_id = reviewerId;
        submissions[index].reviewer_notes = notes;
        submissions[index].reviewed_at = new Date().toISOString();

        this.saveSubmissions(submissions);

        // If approved, create the actual story
        if (decision === 'approved') {
            const sub = submissions[index];
            const storyData = {
                ...sub.submission,
                status: sub.publish_immediately ? 'published' : 'draft',
                submission_data: { submission_id: sub.id, submitted_at: sub.created_at }
            };
            const story = this.createStory(storyData);
            submissions[index].story_id = story.id;
            this.saveSubmissions(submissions);
            return { success: true, action: 'approved', story };
        }

        return { success: true, action: decision };
    },

    // ==================== UTILITIES ====================

    slugify(text) {
        return text
            .toString()
            .toLowerCase()
            .trim()
            .replace(/\s+/g, '-')
            .replace(/[^\w\-]+/g, '')
            .replace(/\-\-+/g, '-');
    },

    countWords(text) {
        // Simple word count; for HTML, strip tags first
        const cleanText = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
        return cleanText ? cleanText.split(/\s+/).length : 0;
    },

    estimateReadTime(wordCount) {
        // Average reading speed: 200 words per minute
        const minutes = Math.ceil(wordCount / 200);
        return minutes < 1 ? 1 : minutes;
    },

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    },

    timeAgo(dateString) {
        const seconds = Math.floor((new Date() - new Date(dateString)) / 1000);
        if (seconds < 60) return 'Just now';
        if (seconds < 3600) return Math.floor(seconds / 60) + 'm ago';
        if (seconds < 86400) return Math.floor(seconds / 3600) + 'h ago';
        if (seconds < 2592000) return Math.floor(seconds / 86400) + 'd ago';
        return this.formatDate(dateString);
    },

    getClientIP() {
        // In a real implementation, this would come from server
        // For localStorage-only, use random identifier per session
        let sessionId = sessionStorage.getItem('session_id');
        if (!sessionId) {
            sessionId = 'sess_' + Math.random().toString(36).substring(2, 15);
            sessionStorage.setItem('session_id', sessionId);
        }
        return sessionId;
    },

    // Get or create anonymous user ID for interactions
    getUserId() {
        let uid = localStorage.getItem('story_user_id');
        if (!uid) {
            uid = 'user_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
            localStorage.setItem('story_user_id', uid);
        }
        return uid;
    },

    // Convert file input to base64 data URL
    async fileToBase64(file) {
        return new Promise((resolve, reject) => {
            if (!file) {
                resolve('');
                return;
            }
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    },

    // Validate image file (size, type, dimensions)
    async     validateImage(file, maxSizeMB = 2, minWidth = 400, minHeight = 500) {
        if (!file) return { valid: false, error: 'No file provided' };

        // Check file type
        if (!file.type.startsWith('image/')) {
            return { valid: false, error: 'File must be an image' };
        }

        // Check file size
        const maxSize = maxSizeMB * 1024 * 1024;
        if (file.size > maxSize) {
            return { valid: false, error: `Image must be less than ${maxSizeMB}MB` };
        }

        // Check dimensions
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                const valid = img.width >= minWidth && img.height >= minHeight;
                if (!valid) {
                    resolve({ valid: false, error: `Image should be at least ${minWidth}x${minHeight}px` });
                } else {
                    resolve({ valid: true });
                }
            };
            img.onerror = () => resolve({ valid: false, error: 'Failed to load image' });
            img.src = URL.createObjectURL(file);
        });
    },

    // Get images from form and validate them
    async processFormImages(formData) {
        const coverFile = document.getElementById('coverFile').files[0];
        const authorPhotoFile = document.getElementById('authorPhotoFile').files[0];

        const results = {
            coverImage: '',
            authorPhoto: '',
            errors: []
        };

        // Process cover image
        if (coverFile) {
            const validation = await this.validateImage(coverFile, 5, 400, 500); // 5MB, 400x500 min
            if (validation.valid) {
                results.coverImage = await this.fileToBase64(coverFile);
            } else {
                results.errors.push('Cover image: ' + validation.error);
            }
        }

        // Process author photo
        if (authorPhotoFile) {
            const validation = await this.validateImage(authorPhotoFile, 2, 100, 100); // 2MB, 100x100 min
            if (validation.valid) {
                results.authorPhoto = await this.fileToBase64(authorPhotoFile);
            } else {
                results.errors.push('Author photo: ' + validation.error);
            }
        }

        return results;
    },

    getSampleStories() {
        return [
            {
                id: 'STORY001',
                slug: 'the-lost-kingdom',
                title: 'The Lost Kingdom',
                subtitle: 'A Tale of Courage and Discovery',
                author_name: 'Sarah Johnson',
                author_bio: 'Sarah is a fantasy writer from Lagos who loves weaving magical tales inspired by African folklore.',
                author_photo: 'https://i.pravatar.cc/150?img=1',
                cover_image: 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=400&h=560&fit=crop',
                description: 'An epic adventure about a young princess who must reclaim her ancestral throne from a dark sorcerer.',
                content: `<h1>Chapter 1: The Prophecy</h1><p>The sun was setting over the kingdom of Zaria, casting long shadows across the palace courtyard. Princess Amina stood at her window, staring at the horizon where the once-golden fields had turned brown and barren.</p><p>"It\'s not just a drought," her father, the King, had said earlier that morning. "The land is dying because the Crystal of Life has been stolen."</p><p>Amina touched the amulet around her neck—the last remnant of the kingdom\'s magic. She had been training for this moment her entire life, but she never imagined it would come so soon...</p>`,
                word_count: 15420,
                read_time_minutes: 77,
                genre: 'Fantasy',
                age_group: 'young_adult',
                status: 'published',
                featured: true,
                featured_until: '2026-12-31',
                allow_comments: true,
                downloadable: true,
                downloadable_formats: ['pdf', 'txt'],
                tags: ['adventure', 'magic', 'royalty', 'african folklore'],
                engagement: {
                    views: 1234,
                    likes: 56,
                    dislikes: 2,
                    shares: 12,
                    comments: 8,
                    rating_sum: 245,
                    rating_count: 50
                },
                published_at: '2026-01-15T10:00:00.000Z',
                created_at: '2026-01-10T10:00:00.000Z',
                updated_at: '2026-01-15T10:00:00.000Z'
            },
            {
                id: 'STORY002',
                slug: 'love-in-lagos',
                title: 'Love in Lagos',
                subtitle: 'A Modern Romance',
                author_name: 'Chioma Eze',
                author_bio: 'Chioma writes contemporary romance stories that capture the heart of Nigerian city life.',
                author_photo: 'https://i.pravatar.cc/150?img=2',
                cover_image: 'https://images.unsplash.com/photo-1478720568477-152d9b164e63?w=400&h=560&fit=crop',
                description: 'Two ambitious professionals navigate love, career, and family expectations in the bustling city of Lagos.',
                content: `<h1>Chapter 1: First Encounter</h1><p>The traffic on Third Mainland Bridge was at a standstill, as usual. Tunde glanced at his watch—7:45 AM. He was going to be late for his first day at the new job.</p><p>"I should\'ve taken the ferry," he muttered, tapping the steering wheel impatiently.</p><p>Just then, a yellow cab swerved dangerously in front of him, cutting off three cars. Tunde honked his horn in frustration, and the cab driver gestured rudely before zooming ahead...</p>`,
                word_count: 28500,
                read_time_minutes: 143,
                genre: 'Romance',
                age_group: 'adult',
                status: 'published',
                featured: true,
                featured_until: '2026-11-30',
                allow_comments: true,
                downloadable: true,
                downloadable_formats: ['pdf', 'txt'],
                tags: ['romance', 'contemporary', 'lagos', 'career'],
                engagement: {
                    views: 3421,
                    likes: 189,
                    dislikes: 5,
                    shares: 34,
                    comments: 24,
                    rating_sum: 890,
                    rating_count: 98
                },
                published_at: '2026-02-01T10:00:00.000Z',
                created_at: '2026-01-20T10:00:00.000Z',
                updated_at: '2026-02-01T10:00:00.000Z'
            },
            {
                id: 'STORY003',
                slug: 'mystery-of-olumo-rock',
                title: 'The Mystery of Olumo Rock',
                subtitle: 'A Thrilling Adventure',
                author_name: 'David Okafor',
                author_bio: 'David is a mystery and thriller writer known for his suspenseful plots set in historical locations.',
                author_photo: 'https://i.pravatar.cc/150?img=3',
                cover_image: 'https://images.unsplash.com/photo-1509023464722-18d996393ca8?w=400&h=560&fit=crop',
                description: 'A group of teenagers discover a hidden chamber in Olumo Rock that holds secrets from the past.',
                content: `<h1>Chapter 1: The Secret Map</h1><p>"You won\'t believe what I found in my grandfather\'s attic," Funke whispered, her eyes wide with excitement.</p><p>The three friends huddled close in the school courtyard, careful not to be overheard.</p><p>"What is it?" asked Kola, his curiosity piqued.</p><p>Funke unfolded a yellowed piece of parchment. It was a map, beautifully drawn with intricate symbols and a route that led from the base of Olumo Rock to a point marked only with a star...</p>`,
                word_count: 19800,
                read_time_minutes: 99,
                genre: 'Mystery',
                age_group: 'young_adult',
                status: 'published',
                featured: false,
                featured_until: null,
                allow_comments: true,
                downloadable: false,
                downloadable_formats: ['pdf'],
                tags: ['mystery', 'adventure', 'teen', 'nigeria'],
                engagement: {
                    views: 876,
                    likes: 34,
                    dislikes: 1,
                    shares: 8,
                    comments: 5,
                    rating_sum: 160,
                    rating_count: 17
                },
                published_at: '2026-02-10T10:00:00.000Z',
                created_at: '2026-02-05T10:00:00.000Z',
                updated_at: '2026-02-10T10:00:00.000Z'
            }
        ];
    }
};

// Auto-init
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => Stories.init());
} else {
    Stories.init();
}

// Make globally available
window.Stories = Stories;

// =====================================================
// SUPABASE SYNC MODULE
// Manual sync functionality for free tier optimization
// Auto-sync disabled to conserve Supabase free tier limits
// =====================================================

const SupabaseSync = {
    syncInProgress: false,
    lastSyncTime: null,
    SYNC_STORAGE_KEY: 'skoolar_last_sync',
    AUTO_SYNC_ENABLED: false, // Disabled by default to save free tier
    SYNC_ON_LOGIN: true,
    SYNC_ON_LOGOUT: true,

    // Initialize sync module
    async init() {
        if (this.initPromise) {
            console.log('Sync init already in progress, returning existing promise');
            return this.initPromise;
        }

        if (this.syncInProgress) {
            console.log('Sync already in progress, skipping init');
            return { success: false, message: 'Sync already in progress' };
        }

        this.initPromise = (async () => {
            this.lastSyncTime = localStorage.getItem(this.SYNC_STORAGE_KEY);
            console.log('Supabase Sync initialized');

            // Wait for Supabase to be fully initialized if enabled
            if (window.supabaseReady) {
                await window.supabaseReady;
            }

            console.log('Starting initial cloud sync sequence...');
            try {
                // Ensure all tables exist before syncing
                if (this.isReady()) {
                    console.log('Checking/creating database tables...');
                    const tableResult = await this.createTablesIfNeeded();
                    if (!tableResult.success) {
                        console.warn('Table creation check failed:', tableResult.message);
                        // Continue anyway - sync will handle missing tables gracefully
                    } else {
                        console.log('Database tables are ready');
                    }
                }

                // Initial fetch from Supabase to ensure up-to-date data on all devices
                if (this.isReady() && typeof Storage !== 'undefined' && typeof Storage.setData === 'function') {
                    // Sync schools first
                    console.log('Syncing schools...');
                    const schoolRes = await this.syncFromCloud({ schools: true });
                    if (schoolRes.success) console.log('Initial school sync completed');
                    else console.warn('Initial school sync failed', schoolRes.message);

                    // Then sync system config only (Critical for announcements/theme)
                    console.log('Syncing system config...');
                    const configRes = await this.syncFromCloud({ systemConfig: true });
                    if (configRes.success) console.log('Initial config sync completed');
                    else console.warn('Initial config sync failed', configRes.message);

                    // Always kick off background users sync (non-blocking) to ensure local fallback works
                    console.log('Starting background users sync...');
                    this.syncFromCloud({ users: true }).catch(err => console.warn('Background users sync failed:', err));

                    return { success: true };
                } else {
                    console.log('Skipping initial sync - Storage not ready or Supabase not available');
                    return { success: false, message: 'Not ready' };
                }
            } catch (err) {
                console.warn('Initial cloud sync sequence error', err);
                return { success: false, message: err.message };
            } finally {
                this.initPromise = null;
            }
        })();

        return this.initPromise;
    },

    // Check if Supabase is ready
    isReady() {
        return typeof getSupabase === 'function' && isSupabaseEnabled();
    },

    // Create tables if they don't exist
    async createTablesIfNeeded() {
        if (!this.isReady()) {
            return { success: false, message: 'Supabase not configured' };
        }

        const supabase = getSupabase();

        const tablesSQL = `
            -- Schools table
            CREATE TABLE IF NOT EXISTS schools (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                alias TEXT,
                email TEXT,
                phone TEXT,
                address TEXT,
                type TEXT DEFAULT 'primary',
                currency TEXT DEFAULT 'NGN',
                status TEXT DEFAULT 'active',
                logo TEXT,
                settings JSONB DEFAULT '{}',
                restrictions JSONB DEFAULT '{"disabled_features":[]}',
                activation_code_id TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                expires_at TIMESTAMPTZ,
                subscription_days INTEGER DEFAULT 365,
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE schools ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Users table
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                username TEXT,
                password TEXT,
                role TEXT NOT NULL CHECK (role IN ('super_admin','school_admin','teacher','accountant','director','parent','student')),
                school_id TEXT,
                status TEXT DEFAULT 'active',
                avatar TEXT,
                settings JSONB DEFAULT '{}',
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE users ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Teachers table
            CREATE TABLE IF NOT EXISTS teachers (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                user_id TEXT,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                employee_id TEXT,
                department TEXT,
                classes JSONB,
                subjects JSONB,
                qualifications JSONB,
                experience_years INTEGER,
                photo TEXT,
                status TEXT DEFAULT 'active',
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE teachers ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Students table
            CREATE TABLE IF NOT EXISTS students (
                id TEXT PRIMARY KEY,
                user_id TEXT,
                school_id TEXT,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                class TEXT,
                section TEXT,
                gender TEXT CHECK (gender IN ('male','female','other')),
                dob DATE,
                blood_group TEXT,
                address TEXT,
                guardian_name TEXT,
                guardian_phone TEXT,
                guardian_email TEXT,
                guardian_occupation TEXT,
                username TEXT,
                password TEXT,
                photo TEXT,
                status TEXT DEFAULT 'active' CHECK (status IN ('active','inactive','graduated','transferred','suspended')),
                enrollment_date TIMESTAMPTZ DEFAULT NOW(),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE students ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Attendance table
            CREATE TABLE IF NOT EXISTS attendance (
                id TEXT PRIMARY KEY,
                student_id TEXT NOT NULL,
                school_id TEXT,
                class TEXT,
                section TEXT,
                date DATE NOT NULL,
                status TEXT DEFAULT 'present',
                remarks TEXT,
                marked_by TEXT,
                marked_at TIMESTAMPTZ DEFAULT NOW(),
                term TEXT,
                year INTEGER,
                supabase_last_sync TIMESTAMPTZ,
                UNIQUE(student_id, date)
            );

            -- Staff Attendance table
            CREATE TABLE IF NOT EXISTS staff_attendance (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                staff_id TEXT NOT NULL,
                staff_name TEXT,
                date DATE NOT NULL,
                check_in TIMESTAMPTZ,
                check_out TIMESTAMPTZ,
                location_in TEXT,
                location_out TEXT,
                status TEXT DEFAULT 'present' CHECK (status IN ('present','absent','late','excused','on_leave')),
                remarks TEXT,
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE staff_attendance ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Scores table
            CREATE TABLE IF NOT EXISTS scores (
                id TEXT PRIMARY KEY,
                student_id TEXT NOT NULL,
                school_id TEXT,
                student_name TEXT,
                class TEXT,
                subject TEXT,
                term TEXT,
                year INTEGER,
                score_type TEXT CHECK (score_type IN ('Daily','Weekly','Mid-term','Exam')),
                score DECIMAL(5,2),
                max_score DECIMAL(5,2),
                entered_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE scores ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Score Sessions table
            CREATE TABLE IF NOT EXISTS score_sessions (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                teacher_id TEXT,
                class TEXT,
                subject TEXT,
                type TEXT CHECK (type IN ('Daily','Weekly','Mid-term','Exam')),
                term TEXT,
                year INTEGER,
                date DATE,
                total_students INTEGER,
                average_score DECIMAL(5,2),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE score_sessions ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Finance table
            CREATE TABLE IF NOT EXISTS finance (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                type TEXT NOT NULL CHECK (type IN ('income','expense')),
                category TEXT,
                amount DECIMAL(12,2) NOT NULL,
                description TEXT,
                payment_method TEXT CHECK (payment_method IN ('cash','bank_transfer','online','cheque','pos')),
                reference_number TEXT,
                related_student_id TEXT,
                related_class TEXT,
                term TEXT,
                year INTEGER,
                date DATE,
                created_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE finance ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Library Books table
            CREATE TABLE IF NOT EXISTS library_books (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                isbn TEXT,
                title TEXT,
                author TEXT,
                publisher TEXT,
                category TEXT,
                quantity INTEGER,
                available INTEGER,
                shelf_location TEXT,
                status TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE library_books ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Book Loans table
            CREATE TABLE IF NOT EXISTS book_loans (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                book_id TEXT NOT NULL,
                student_id TEXT NOT NULL,
                student_name TEXT,
                checkout_date DATE NOT NULL,
                due_date DATE,
                return_date DATE,
                status TEXT,
                fine_amount DECIMAL(8,2),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE book_loans ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Homework table
            CREATE TABLE IF NOT EXISTS homework (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                teacher_id TEXT,
                class TEXT,
                subject TEXT,
                title TEXT,
                description TEXT,
                due_date DATE,
                total_marks DECIMAL(5,2),
                attachments JSONB,
                term TEXT,
                year INTEGER,
                status TEXT DEFAULT 'active' CHECK (status IN ('active','closed','archived')),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE homework ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Homework Submissions table
            CREATE TABLE IF NOT EXISTS homework_submissions (
                id TEXT PRIMARY KEY,
                homework_id TEXT NOT NULL,
                student_id TEXT NOT NULL,
                student_name TEXT,
                submission_date TIMESTAMPTZ DEFAULT NOW(),
                status TEXT,
                answer_text TEXT,
                attachments JSONB,
                grade DECIMAL(5,2),
                feedback TEXT,
                graded_by TEXT,
                graded_at TIMESTAMPTZ,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE homework_submissions ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Timetable table
            CREATE TABLE IF NOT EXISTS timetable (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                class TEXT,
                section TEXT,
                day_of_week TEXT CHECK (day_of_week IN ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')),
                period_number INTEGER,
                subject TEXT,
                teacher_id TEXT,
                teacher_name TEXT,
                room TEXT,
                term TEXT,
                year INTEGER,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE timetable ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Chats table
            CREATE TABLE IF NOT EXISTS chats (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                title TEXT,
                type TEXT CHECK (type IN ('direct','group','class')),
                participants JSONB,
                last_message TEXT,
                last_message_at TIMESTAMPTZ,
                created_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE chats ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Messages table
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                chat_id TEXT NOT NULL,
                sender_id TEXT,
                sender_name TEXT,
                sender_role TEXT,
                message TEXT,
                message_type TEXT CHECK (message_type IN ('text','image','file','system')),
                attachments JSONB,
                is_read BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE messages ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Student Messages table
            CREATE TABLE IF NOT EXISTS student_messages (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                student_id TEXT NOT NULL,
                from_role TEXT DEFAULT 'student',
                from_name TEXT,
                subject TEXT,
                message TEXT,
                is_read BOOLEAN DEFAULT FALSE,
                reply JSONB,
                replied_at TIMESTAMPTZ,
                replied_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE student_messages ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Parent Messages table
            CREATE TABLE IF NOT EXISTS parent_messages (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                parent_id TEXT,
                parent_name TEXT,
                student_id TEXT NOT NULL,
                student_name TEXT,
                subject TEXT,
                message TEXT,
                is_read BOOLEAN DEFAULT FALSE,
                reply JSONB,
                replied_at TIMESTAMPTZ,
                replied_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE parent_messages ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Parent Announcements table
            CREATE TABLE IF NOT EXISTS parent_announcements (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                title TEXT DEFAULT 'Announcement',
                message TEXT NOT NULL,
                target_class TEXT,
                target_student_ids JSONB,
                created_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE parent_announcements ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Adverts table
            CREATE TABLE IF NOT EXISTS adverts (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                title TEXT,
                description TEXT,
                image_url TEXT,
                target_url TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                position TEXT CHECK (position IN ('sidebar','banner','popup','login')),
                start_date DATE,
                end_date DATE,
                impressions INTEGER DEFAULT 0,
                clicks INTEGER DEFAULT 0,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE adverts ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Activation Codes table
            CREATE TABLE IF NOT EXISTS activation_codes (
                id TEXT PRIMARY KEY,
                code TEXT UNIQUE NOT NULL,
                school_id TEXT,
                is_used BOOLEAN DEFAULT FALSE,
                is_revoked BOOLEAN DEFAULT FALSE,
                subscription_days INTEGER DEFAULT 365,
                expires_at TIMESTAMPTZ,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                used_at TIMESTAMPTZ,
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE activation_codes ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Notifications table
            CREATE TABLE IF NOT EXISTS notifications (
                id TEXT PRIMARY KEY,
                user_id TEXT,
                school_id TEXT,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                type TEXT,
                is_read BOOLEAN DEFAULT FALSE,
                link TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE notifications ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Calendar Events table
            CREATE TABLE IF NOT EXISTS calendar_events (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                title TEXT NOT NULL,
                description TEXT,
                event_date DATE,
                event_type TEXT,
                for_classes JSONB,
                created_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE calendar_events ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Tests table
            CREATE TABLE IF NOT EXISTS tests (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                teacher_id TEXT,
                title TEXT NOT NULL,
                description TEXT,
                subject TEXT,
                class TEXT,
                type TEXT CHECK (type IN ('mcq','true_false','fill_blank','essay','mixed')),
                term TEXT,
                year INTEGER,
                duration_minutes INTEGER,
                passing_percentage DECIMAL(5,2),
                randomize_questions BOOLEAN DEFAULT FALSE,
                randomize_options BOOLEAN DEFAULT FALSE,
                show_results BOOLEAN DEFAULT TRUE,
                status TEXT DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE tests ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Test Questions table
            CREATE TABLE IF NOT EXISTS test_questions (
                id TEXT PRIMARY KEY,
                test_id TEXT NOT NULL,
                question_id TEXT NOT NULL,
                question_order INTEGER,
                marks DECIMAL(5,2),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE test_questions ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Test Results table
            CREATE TABLE IF NOT EXISTS test_results (
                id TEXT PRIMARY KEY,
                test_id TEXT NOT NULL,
                student_id TEXT NOT NULL,
                school_id TEXT,
                answers JSONB,
                score DECIMAL(5,2),
                total_marks DECIMAL(5,2),
                percentage DECIMAL(5,2),
                status TEXT CHECK (status IN ('passed','failed','incomplete')),
                started_at TIMESTAMPTZ,
                submitted_at TIMESTAMPTZ,
                graded_by TEXT,
                graded_at TIMESTAMPTZ,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE test_results ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Exams table (needs to be added based on fieldMappings)
            CREATE TABLE IF NOT EXISTS exams (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                exam_type TEXT CHECK (exam_type IN ('objective','subjective','mixed')),
                title TEXT NOT NULL,
                description TEXT,
                subject TEXT,
                class TEXT,
                term TEXT,
                year INTEGER,
                start_date DATE,
                end_date DATE,
                duration_minutes INTEGER,
                status TEXT DEFAULT 'draft' CHECK (status IN ('draft','published','ongoing','completed','archived')),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE exams ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Exam Questions table
            CREATE TABLE IF NOT EXISTS exam_questions (
                id TEXT PRIMARY KEY,
                exam_id TEXT NOT NULL,
                question_text TEXT NOT NULL,
                question_type TEXT CHECK (question_type IN ('mcq','true_false','fill_blank','essay','short_answer')),
                options JSONB,
                correct_answer TEXT,
                points DECIMAL(5,2),
                explanation TEXT,
                question_order INTEGER,
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE exam_questions ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Audit Log table
            CREATE TABLE IF NOT EXISTS audit_log (
                id TEXT PRIMARY KEY,
                user_id TEXT,
                school_id TEXT,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id TEXT,
                old_values JSONB,
                new_values JSONB,
                ip_address TEXT,
                user_agent TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            -- Add supabase_last_sync if table already exists without it
            ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Sync Log table
            CREATE TABLE IF NOT EXISTS sync_log (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                sync_type TEXT,
                direction TEXT CHECK (direction IN ('upload','download','both')),
                records_count INTEGER,
                status TEXT CHECK (status IN ('success','partial','error')),
                error_message TEXT,
                duration_ms INTEGER,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            -- Add supabase_last_sync if table already exists without it
            ALTER TABLE sync_log ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Chart of Accounts table (finance subsystem)
            CREATE TABLE IF NOT EXISTS chart_of_accounts (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                code TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                type TEXT NOT NULL CHECK (type IN ('asset','liability','equity','income','expense')),
                parent_id TEXT,
                description TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE chart_of_accounts ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Budgets table
            CREATE TABLE IF NOT EXISTS budgets (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                account_id TEXT NOT NULL,
                fiscal_year INTEGER NOT NULL,
                period TEXT CHECK (period IN ('annual','term1','term2','term3','monthly')),
                allocated_amount DECIMAL(12,2) NOT NULL,
                spent_amount DECIMAL(12,2) DEFAULT 0,
                created_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE budgets ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Accounts Receivable/Payable table
            CREATE TABLE IF NOT EXISTS accounts_receivable (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                party_name TEXT NOT NULL,
                type TEXT NOT NULL CHECK (type IN ('receivable','payable')),
                amount DECIMAL(12,2) NOT NULL,
                due_date DATE,
                status TEXT DEFAULT 'pending' CHECK (status IN ('pending','partial','paid','overdue','written_off')),
                reference_number TEXT,
                description TEXT,
                created_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE accounts_receivable ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Tax Settings table
            CREATE TABLE IF NOT EXISTS tax_settings (
                id TEXT PRIMARY KEY,
                school_id TEXT UNIQUE NOT NULL,
                tax_name TEXT NOT NULL,
                percentage DECIMAL(5,2) NOT NULL,
                is_enabled BOOLEAN DEFAULT TRUE,
                applies_to TEXT CHECK (applies_to IN ('income','expense','both')),
                config JSONB DEFAULT '{}',
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE tax_settings ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Financial Attachments table
            CREATE TABLE IF NOT EXISTS financial_attachments (
                id TEXT PRIMARY KEY,
                finance_id TEXT NOT NULL,
                school_id TEXT,
                file_name TEXT NOT NULL,
                file_url TEXT NOT NULL,
                file_type TEXT,
                file_size INTEGER,
                uploaded_by TEXT,
                uploaded_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE financial_attachments ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Receipts table (for payments)
            CREATE TABLE IF NOT EXISTS receipts (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                receipt_number TEXT UNIQUE NOT NULL,
                payer_name TEXT NOT NULL,
                payer_id TEXT,
                amount DECIMAL(12,2) NOT NULL,
                payment_method TEXT,
                purpose TEXT,
                finance_ids JSONB,
                issued_by TEXT,
                issued_at TIMESTAMPTZ DEFAULT NOW(),
                printed_at TIMESTAMPTZ,
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE receipts ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Questions table (question bank)
            CREATE TABLE IF NOT EXISTS questions (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                question_text TEXT NOT NULL,
                question_type TEXT CHECK (question_type IN ('mcq','true_false','fill_blank','essay','short_answer')),
                options JSONB,
                correct_answer TEXT,
                explanation TEXT,
                difficulty TEXT CHECK (difficulty IN ('easy','medium','hard')),
                subject TEXT,
                topic TEXT,
                tags JSONB,
                created_by TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ,
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE questions ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Test Attempts table
            CREATE TABLE IF NOT EXISTS test_attempts (
                id TEXT PRIMARY KEY,
                test_id TEXT NOT NULL,
                student_id TEXT NOT NULL,
                school_id TEXT,
                started_at TIMESTAMPTZ DEFAULT NOW(),
                submitted_at TIMESTAMPTZ,
                status TEXT DEFAULT 'in_progress' CHECK (status IN ('in_progress','submitted','graded','expired')),
                ip_address TEXT,
                user_agent TEXT,
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE test_attempts ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Exam Results table (from fieldMappings)
            CREATE TABLE IF NOT EXISTS exam_results (
                id TEXT PRIMARY KEY,
                exam_id TEXT NOT NULL,
                student_id TEXT NOT NULL,
                school_id TEXT,
                score DECIMAL(5,2),
                grade TEXT,
                remarks TEXT,
                graded_by TEXT,
                graded_at TIMESTAMPTZ,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE exam_results ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Stories table (social/content)
            CREATE TABLE IF NOT EXISTS stories (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                user_id TEXT,
                type TEXT DEFAULT 'text',
                content TEXT,
                media_url TEXT,
                likes_count INTEGER DEFAULT 0,
                comments_count INTEGER DEFAULT 0,
                shares_count INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT TRUE,
                expires_at TIMESTAMPTZ,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE stories ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Story Interactions table
            CREATE TABLE IF NOT EXISTS story_interactions (
                id TEXT PRIMARY KEY,
                story_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                action TEXT CHECK (action IN ('like','share','view')),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ,
                UNIQUE(story_id, user_id, action)
            );
            ALTER TABLE story_interactions ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Story Comments table
            CREATE TABLE IF NOT EXISTS story_comments (
                id TEXT PRIMARY KEY,
                story_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                user_name TEXT,
                comment TEXT NOT NULL,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE story_comments ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Story Submissions table
            CREATE TABLE IF NOT EXISTS story_submissions (
                id TEXT PRIMARY KEY,
                school_id TEXT,
                user_id TEXT NOT NULL,
                content TEXT NOT NULL,
                media_url TEXT,
                status TEXT DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','draft')),
                reviewed_by TEXT,
                reviewed_at TIMESTAMPTZ,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE story_submissions ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- System Config table
            CREATE TABLE IF NOT EXISTS system_config (
                id TEXT PRIMARY KEY DEFAULT 'global',
                settings JSONB NOT NULL,
                announcement JSONB,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE system_config ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Blog Posts table
            CREATE TABLE IF NOT EXISTS blog_posts (
                id TEXT PRIMARY KEY,
                slug TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                excerpt TEXT,
                content TEXT NOT NULL,
                featured_image TEXT,
                category TEXT,
                tags JSONB DEFAULT '[]',
                video_url TEXT,
                audio_url TEXT,
                featured BOOLEAN DEFAULT FALSE,
                comments_enabled BOOLEAN DEFAULT TRUE,
                status TEXT DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
                views INTEGER DEFAULT 0,
                author_name TEXT,
                author_avatar TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW(),
                published_at TIMESTAMPTZ,
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE blog_posts ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Resources table
            CREATE TABLE IF NOT EXISTS resources (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                description TEXT,
                category TEXT NOT NULL CHECK (category IN ('Documents','Videos','Audio','Images','Archives','Other')),
                file_url TEXT,
                file_type TEXT,
                file_size TEXT,
                thumbnail TEXT,
                tags JSONB DEFAULT '[]',
                downloads INTEGER DEFAULT 0,
                status TEXT DEFAULT 'active' CHECK (status IN ('active','inactive','archived')),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE resources ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Pricing Plans table
            CREATE TABLE IF NOT EXISTS pricing_plans (
                id TEXT PRIMARY KEY,
                plan_name TEXT NOT NULL UNIQUE,
                price DECIMAL(10,2),
                period TEXT DEFAULT 'monthly',
                description TEXT,
                features JSONB DEFAULT '[]',
                cta_text TEXT DEFAULT 'Get Started',
                highlighted BOOLEAN DEFAULT FALSE,
                display_order INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE pricing_plans ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

            -- Static Pages table
            CREATE TABLE IF NOT EXISTS static_pages (
                page_name TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                meta_description TEXT,
                updated_at TIMESTAMPTZ DEFAULT NOW(),
                supabase_last_sync TIMESTAMPTZ
            );
            ALTER TABLE static_pages ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;
        `;

        try {
            // Simple check: query schools table to verify tables exist
            const { error: checkError } = await supabase.from('schools').select('id').limit(1);
            if (checkError) {
                return {
                    success: false,
                    message: 'Tables not found. Please run the SQL from SUPABASE-SETUP-GUIDE.md to create tables.',
                    error: checkError.message
                };
            }

            return { success: true, message: 'Tables ready' };
        } catch (error) {
            return { success: false, message: 'Error checking tables: ' + error.message };
        }
    },

    // Get sync status
    getStatus() {
        return {
            isReady: this.isReady(),
            lastSync: this.lastSyncTime,
            inProgress: this.syncInProgress
        };
    },

    // =====================================================
    // MAIN SYNC FUNCTION - Upload all data to Supabase
    // =====================================================
    async syncAllToCloud(options = {}) {
        if (this.syncInProgress) {
            return { success: false, message: 'Sync already in progress' };
        }

        if (!this.isReady()) {
            return { success: false, message: 'Supabase not configured or not enabled' };
        }

        const supabase = getSupabase();
        if (!supabase) {
            return { success: false, message: 'Supabase client not initialized' };
        }

        this.syncInProgress = true;
        const results = {
            success: true,
            schools: { uploaded: 0, errors: [] },
            users: { uploaded: 0, errors: [] },
            students: { uploaded: 0, errors: [] },
            attendance: { uploaded: 0, errors: [] },
            scores: { uploaded: 0, errors: [] },
            finance: { uploaded: 0, errors: [] },
            calendar: { uploaded: 0, errors: [] },
            systemConfig: { uploaded: 0, errors: [] },
            totalTime: 0
        };

        const startTime = Date.now();

        try {
            // Comprehensive table list: all tables (44)
            const tableList = [
                { storageKey: 'schools', tableName: 'schools', resultKey: 'schools' },
                { storageKey: 'users', tableName: 'users', resultKey: 'users' },
                { storageKey: 'students', tableName: 'students', resultKey: 'students' },
                { storageKey: 'teachers', tableName: 'teachers', resultKey: 'teachers' },
                { storageKey: 'attendance', tableName: 'attendance', resultKey: 'attendance' },
                { storageKey: 'staffAttendance', tableName: 'staff_attendance', resultKey: 'staffAttendance' },
                { storageKey: 'scores', tableName: 'scores', resultKey: 'scores' },
                { storageKey: 'finance', tableName: 'finance', resultKey: 'finance' },
                { storageKey: 'chart_of_accounts', tableName: 'chart_of_accounts', resultKey: 'chart_of_accounts' },
                { storageKey: 'budgets', tableName: 'budgets', resultKey: 'budgets' },
                { storageKey: 'accounts_receivable', tableName: 'accounts_receivable', resultKey: 'accounts_receivable' },
                { storageKey: 'tax_settings', tableName: 'tax_settings', resultKey: 'tax_settings' },
                { storageKey: 'financial_attachments', tableName: 'financial_attachments', resultKey: 'financial_attachments' },
                { storageKey: 'receipts', tableName: 'receipts', resultKey: 'receipts' },
                { storageKey: 'questions', tableName: 'questions', resultKey: 'questions' },
                { storageKey: 'tests', tableName: 'tests', resultKey: 'tests' },
                { storageKey: 'testResults', tableName: 'test_results', resultKey: 'testResults' },
                { storageKey: 'testQuestions', tableName: 'test_questions', resultKey: 'testQuestions' },
                { storageKey: 'testAttempts', tableName: 'test_attempts', resultKey: 'testAttempts' },
                { storageKey: 'exams', tableName: 'exams', resultKey: 'exams' },
                { storageKey: 'examQuestions', tableName: 'exam_questions', resultKey: 'examQuestions' },
                { storageKey: 'examResults', tableName: 'exam_results', resultKey: 'examResults' },
                { storageKey: 'examSessions', tableName: 'exam_sessions', resultKey: 'examSessions' },
                { storageKey: 'examLogs', tableName: 'exam_logs', resultKey: 'examLogs' },
                { storageKey: 'violationReports', tableName: 'violation_reports', resultKey: 'violationReports' },
                { storageKey: 'calendarEvents', tableName: 'calendar_events', resultKey: 'calendar' },
                { storageKey: 'activationCodes', tableName: 'activation_codes', resultKey: 'activationCodes' },
                { storageKey: 'chats', tableName: 'chats', resultKey: 'chats' },
                { storageKey: 'messages', tableName: 'messages', resultKey: 'messages' },
                { storageKey: 'studentMessages', tableName: 'student_messages', resultKey: 'studentMessages' },
                { storageKey: 'parentMessages', tableName: 'parent_messages', resultKey: 'parentMessages' },
                { storageKey: 'notifications', tableName: 'notifications', resultKey: 'notifications' },
                { storageKey: 'parentAnnouncements', tableName: 'parent_announcements', resultKey: 'parentAnnouncements' },
                { storageKey: 'adverts', tableName: 'adverts', resultKey: 'adverts' },
                { storageKey: 'library_books', tableName: 'library_books', resultKey: 'library_books' },
                { storageKey: 'book_loans', tableName: 'book_loans', resultKey: 'book_loans' },
                { storageKey: 'homework', tableName: 'homework', resultKey: 'homework' },
                { storageKey: 'homeworkSubmissions', tableName: 'homework_submissions', resultKey: 'homeworkSubmissions' },
                { storageKey: 'timetable', tableName: 'timetable', resultKey: 'timetable' },
                { storageKey: 'domainScores', tableName: 'domain_scores', resultKey: 'domainScores' },
                { storageKey: 'scoreSessions', tableName: 'score_sessions', resultKey: 'scoreSessions' },
                { storageKey: 'stories', tableName: 'stories', resultKey: 'stories' },
                { storageKey: 'storyInteractions', tableName: 'story_interactions', resultKey: 'storyInteractions' },
                { storageKey: 'storyComments', tableName: 'story_comments', resultKey: 'storyComments' },
                { storageKey: 'storySubmissions', tableName: 'story_submissions', resultKey: 'storySubmissions' },
                { storageKey: 'systemConfig', tableName: 'system_config', resultKey: 'systemConfig' }
                // Skipping auditLog and syncLog to reduce usage and avoid errors
                // Skipping blogPosts, resources, pricing, pages (object data, not arrays)
            ];

            // If options are provided, only sync tables explicitly set to true
            const selectiveSync = Object.keys(options).length > 0;
            for (const tbl of tableList) {
                if (selectiveSync && options[tbl.storageKey] !== true) {
                    results[tbl.resultKey] = { uploaded: 0, errors: [] };
                    continue;
                }

                // Special handling for systemConfig: it's a single object, not an array
                if (tbl.storageKey === 'systemConfig') {
                    try {
                        const settings = Storage.getSystemSettings();
                        
                        // Merge theme settings from ThemeManager if available
                        let themeSettings = {};
                        if (typeof ThemeManager !== 'undefined' && typeof ThemeManager.getGlobalTheme === 'function') {
                            try {
                                themeSettings = ThemeManager.getGlobalTheme();
                            } catch (e) {
                                console.warn('Could not get theme settings:', e);
                            }
                        }
                        
                        const mergedSettings = {
                            ...settings,
                            theme: themeSettings
                        };
                        
                        const dataToSync = {
                            id: 'global',
                            settings: mergedSettings,
                            updated_at: new Date().toISOString(),
                            supabase_last_sync: new Date().toISOString()
                        };
                        const { error } = await supabase.from(tbl.tableName).upsert(dataToSync, { onConflict: 'id' });
                        if (error) {
                            console.error(`Error syncing ${tbl.tableName}:`, error);
                            results[tbl.resultKey] = { uploaded: 0, errors: [error.message] };
                        } else {
                            results[tbl.resultKey] = { uploaded: 1, errors: [] };
                            console.log(`✓ Synced systemConfig`);
                        }
                    } catch (err) {
                        console.error(`Exception syncing ${tbl.tableName}:`, err);
                        results[tbl.resultKey] = { uploaded: 0, errors: [err.message] };
                    }
                } else {
                    // Normal table sync
                    results[tbl.resultKey] = await this.syncTable(supabase, tbl.tableName, tbl.storageKey);
                }
            }

            results.totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
            results.totalRecords = Object.values(results).filter(val => typeof val === 'object' && 'uploaded' in val).reduce((sum, tbl) => sum + (tbl.uploaded || 0), 0);
            results.lastSync = new Date().toISOString();

            // Save last sync time
            localStorage.setItem(this.SYNC_STORAGE_KEY, results.lastSync);
            this.lastSyncTime = results.lastSync;

            // Log sync to Supabase
            await this.logSync(results);

            return results;

        } catch (error) {
            console.error('Sync error:', error);
            return { success: false, message: error.message, results };
        } finally {
            this.syncInProgress = false;
        }
    },

    // Sync a single table
    async syncTable(supabase, tableName, storageKey) {
        const result = { uploaded: 0, errors: [] };

        try {
            const localData = Storage.getData(storageKey) || [];

            if (localData.length === 0) {
                return result;
            }

            // Convert storageKey (camelCase) to snake_case table name for SyncMapper
            const sqlTableName = storageKey.replace(/([A-Z])/g, '_$1').toLowerCase();

            // Prepare data for Supabase using SyncMapper for comprehensive field mapping
            let dataToSync;
            if (typeof SyncMapper !== 'undefined' && SyncMapper.transformForSQL) {
                dataToSync = localData.map(item => {
                    const sqlData = SyncMapper.transformForSQL(item, sqlTableName);
                    // Add supabase_last_sync timestamp
                    sqlData.supabase_last_sync = new Date().toISOString();
                    return sqlData;
                });
            } else {
                // Fallback to original prepareData
                dataToSync = localData.map(item => this.prepareData(storageKey, item));
            }

            // Upsert data (insert or update)
            const { data, error } = await supabase
                .from(tableName)
                .upsert(dataToSync, { onConflict: 'id' })
                .select();

            if (error) {
                console.error(`Error syncing ${tableName}:`, error);
                result.errors.push(error.message);
            } else {
                result.uploaded = dataToSync.length;
                console.log(`✓ Synced ${result.uploaded} ${tableName} records`);
            }

        } catch (error) {
            console.error(`Exception syncing ${tableName}:`, error);
            result.errors.push(error.message);
        }

        return result;
    },

    // Helper to prepare a single item for Supabase
    prepareData(storageKey, item) {
        const knownFieldsMap = {
            'schools': ['id', 'name', 'alias', 'email', 'phone', 'address', 'type', 'currency', 'status', 'settings', 'restrictions', 'activationCodeId', 'createdAt', 'expiresAt', 'subscriptionDays'],
            'users': ['id', 'name', 'email', 'phone', 'username', 'password', 'role', 'schoolId', 'status', 'avatar', 'settings', 'createdAt'],
            'students': ['id', 'userId', 'schoolId', 'name', 'email', 'phone', 'class', 'status', 'parentName', 'parentPhone', 'parentEmail', 'parentId', 'username', 'password', 'enrollmentDate'],
            'attendance': ['id', 'studentId', 'schoolId', 'class', 'date', 'status', 'term', 'year', 'markedBy', 'markedAt'],
            'scores': ['id', 'studentId', 'schoolId', 'class', 'subject', 'term', 'year', 'scoreType', 'score', 'createdAt'],
            'domainScores': ['id', 'schoolId', 'studentId', 'teacherId', 'class', 'subject', 'domain', 'score', 'remark', 'term', 'year', 'createdAt'],
            'scoreSessions': ['id', 'schoolId', 'teacherId', 'class', 'subject', 'type', 'term', 'year', 'date', 'totalStudents', 'averageScore', 'createdAt'],
            'activationCodes': ['id', 'code', 'schoolId', 'isUsed', 'isRevoked', 'subscriptionDays', 'expiresAt', 'createdAt', 'usedAt'],
            'calendarEvents': ['id', 'schoolId', 'title', 'description', 'eventDate', 'eventType', 'createdAt']
        };

        const knownFields = knownFieldsMap[storageKey] || [];
        const converted = {};

        if (storageKey === 'schools') {
            const schoolFields = knownFieldsMap['schools'];
            const settingsFields = [
                'idCardColor', 'idCardBackMessage', 'motto', 'established', 'website',
                'logoUrl', 'currentYear', 'currentTerm', 'autoAdvanceTerm', 'prefix'
            ];

            // Ensure settings exists
            converted.settings = { ...(item.settings || {}) };

            schoolFields.forEach(field => {
                if (item[field] !== undefined && field !== 'settings') {
                    const snakeKey = field.replace(/([A-Z])/g, '_$1').toLowerCase();
                    converted[snakeKey] = item[field];
                }
            });

            // Pack custom fields into settings
            settingsFields.forEach(field => {
                if (item[field] !== undefined) {
                    converted.settings[field] = item[field];
                }
            });

            return converted;
        }

        if (knownFields.length > 0) {
            knownFields.forEach(field => {
                if (item[field] !== undefined) {
                    const snakeKey = field.replace(/([A-Z])/g, '_$1').toLowerCase();
                    converted[snakeKey] = item[field];
                }
            });
        } else {
            // Fallback: convert all fields
            for (const key in item) {
                const snakeKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
                converted[snakeKey] = item[key];
            }
        }
        return converted;
    },

    // Background upload for a single item
    async uploadItem(storageKey, item) {
        // Wait for Supabase to be fully initialized if a global promise exists
        if (window.supabaseReady) {
            try {
                await window.supabaseReady;
            } catch (e) {
                console.warn('Sync waiting for supabaseReady failed:', e);
            }
        }

        if (!this.isReady()) return { success: false, reason: 'Supabase not ready' };

        const supabase = getSupabase();
        if (!supabase) return { success: false, reason: 'Supabase client not available' };

         const tableNameMap = {
             // Core data
             'schools': 'schools',
             'users': 'users',
             'students': 'students',
             'teachers': 'teachers',
             'attendance': 'attendance',
             'staffAttendance': 'staff_attendance',
             'scores': 'scores',
             'finance': 'finance',
             'chart_of_accounts': 'chart_of_accounts',
             'budgets': 'budgets',
             'accounts_receivable': 'accounts_receivable',
             'tax_settings': 'tax_settings',
             'financial_attachments': 'financial_attachments',
             'receipts': 'receipts',
             // Academic
             'questions': 'questions',
             'tests': 'tests',
             'testResults': 'test_results',
             'testQuestions': 'test_questions',
             'testAttempts': 'test_attempts',
             'exams': 'exams',
             'examQuestions': 'exam_questions',
             'examResults': 'exam_results',
             'homework': 'homework',
             'homeworkSubmissions': 'homework_submissions',
             'timetable': 'timetable',
             'domainScores': 'domain_scores',
             'scoreSessions': 'score_sessions',
             'library_books': 'library_books',
             'book_loans': 'book_loans',
             // Communication
             'chats': 'chats',
             'messages': 'messages',
             'studentMessages': 'student_messages',
             'parentMessages': 'parent_messages',
             'notifications': 'notifications',
             'parentAnnouncements': 'parent_announcements',
             'adverts': 'adverts',
             // Content
             'stories': 'stories',
             'storyInteractions': 'story_interactions',
             'storyComments': 'story_comments',
             'storySubmissions': 'story_submissions',
              // System
              'auditLog': 'audit_log',
              'syncLog': 'sync_log',
              // Global config
              'systemConfig': 'system_config',
              // Super Admin Global
              'blogPosts': 'blog_posts',
              'resources': 'resources',
              'pricing': 'pricing_plans',
              'pages': 'static_pages'
          };

        const tableName = tableNameMap[storageKey] || storageKey;
        const sqlTableName = storageKey.replace(/([A-Z])/g, '_$1').toLowerCase();

        // Use SyncMapper if available
        let dataToSync;
        if (typeof SyncMapper !== 'undefined' && SyncMapper.transformForSQL) {
            dataToSync = SyncMapper.transformForSQL(item, sqlTableName);
            dataToSync.supabase_last_sync = new Date().toISOString();
        } else {
            dataToSync = this.prepareData(storageKey, item);
        }

        try {
            const { error } = await supabase.from(tableName).upsert(dataToSync, { onConflict: 'id' });
            if (error) throw error;
            console.log(`✓ Auto-synced ${tableName} item: ${item.id}`);
            return { success: true };
        } catch (e) {
            console.warn(`Auto-upload failed for ${tableName}:`, e.message);
            return { success: false, reason: e.message };
        }
    },

    // Background delete for a single item
    async deleteItem(storageKey, id) {
        // Wait for Supabase to be fully initialized if a global promise exists
        if (window.supabaseReady) {
            try {
                await window.supabaseReady;
            } catch (e) {
                console.warn('Sync waiting for supabaseReady failed:', e);
            }
        }

        if (!this.isReady()) return { success: false, reason: 'Supabase not ready' };

        const supabase = getSupabase();
        if (!supabase) return { success: false, reason: 'Supabase client not available' };

         const tableNameMap = {
             // Core data
             'schools': 'schools',
             'users': 'users',
             'students': 'students',
             'teachers': 'teachers',
             'attendance': 'attendance',
             'staffAttendance': 'staff_attendance',
             'scores': 'scores',
             'finance': 'finance',
             'chart_of_accounts': 'chart_of_accounts',
             'budgets': 'budgets',
             'accounts_receivable': 'accounts_receivable',
             'tax_settings': 'tax_settings',
             'financial_attachments': 'financial_attachments',
             'receipts': 'receipts',
             // Academic
             'questions': 'questions',
             'tests': 'tests',
             'testResults': 'test_results',
             'testQuestions': 'test_questions',
             'testAttempts': 'test_attempts',
             'exams': 'exams',
             'examQuestions': 'exam_questions',
             'examResults': 'exam_results',
             'homework': 'homework',
             'homeworkSubmissions': 'homework_submissions',
             'timetable': 'timetable',
             'domainScores': 'domain_scores',
             'scoreSessions': 'score_sessions',
             'library_books': 'library_books',
             'book_loans': 'book_loans',
             // Communication
             'chats': 'chats',
             'messages': 'messages',
             'studentMessages': 'student_messages',
             'parentMessages': 'parent_messages',
             'notifications': 'notifications',
             'parentAnnouncements': 'parent_announcements',
             'adverts': 'adverts',
             // Content
             'stories': 'stories',
             'storyInteractions': 'story_interactions',
             'storyComments': 'story_comments',
             'storySubmissions': 'story_submissions',
              // System
              'auditLog': 'audit_log',
              'syncLog': 'sync_log',
              // Global config
              'systemConfig': 'system_config',
              // Super Admin Global
              'blogPosts': 'blog_posts',
              'resources': 'resources',
              'pricing': 'pricing_plans',
              'pages': 'static_pages'
         };

        const tableName = tableNameMap[storageKey] || storageKey;

        try {
            const { error } = await supabase.from(tableName).delete().eq('id', id);
            if (error) throw error;
            console.log(`✓ Auto-deleted ${tableName} item: ${id}`);
            return { success: true };
        } catch (e) {
            console.warn(`Auto-delete failed for ${tableName}:`, e.message);
            return { success: false, reason: e.message };
        }
    },

    // Delete all records from a table, optionally with filter
    async deleteAllRecords(table, filter = null) {
        if (!this.isReady()) {
            throw new Error('Supabase not ready');
        }
        
        const supabase = getSupabase();
        let query = supabase.from(table).select('id');
        
        if (filter) {
            const key = Object.keys(filter)[0];
            const value = Object.values(filter)[0];
            query = query.eq(key, value);
        }
        
        const { data, error } = await query;
        if (error) throw error;
        
        const ids = data.map(record => record.id);
        if (ids.length === 0) {
            return { success: true, deleted: 0 };
        }
        
        // Delete in chunks of 100 to avoid large requests
        const chunkSize = 100;
        let totalDeleted = 0;
        
        for (let i = 0; i < ids.length; i += chunkSize) {
            const chunk = ids.slice(i, i + chunkSize);
            const { error: deleteError } = await supabase.from(table).delete().in('id', chunk);
            if (deleteError) throw deleteError;
            totalDeleted += chunk.length;
        }
        
        return { success: true, deleted: totalDeleted };
    },

    // =====================================================
    // DOWNLOAD DATA FROM CLOUD
    // =====================================================
    async syncFromCloud(options = {}) {
        if (this.syncInProgress) {
            return { success: false, message: 'Sync already in progress' };
        }

        if (!this.isReady()) {
            return { success: false, message: 'Supabase not configured' };
        }

        const supabase = getSupabase();
        this.syncInProgress = true;

        const results = { success: true, downloaded: {} };

        // Convert snake_case to camelCase and handle nested structures
        const toCamelCase = (obj) => {
            if (Array.isArray(obj)) {
                return obj.map(item => toCamelCase(item));
            }
            if (obj && typeof (obj) === 'object' && !(obj instanceof Date)) {
                const newObj = {};
                for (const key in obj) {
                    // Handle snake_case to camelCase
                    const camelKey = key.replace(/_([a-z])/g, (g) => g[1].toUpperCase());
                    newObj[camelKey] = toCamelCase(obj[key]);
                }
                return newObj;
            }
            return obj;
        };

        // Check if Storage is available
        if (typeof Storage === 'undefined' || typeof Storage.setData !== 'function') {
            console.warn('Storage not ready, skipping download');
            return { success: false, message: 'Storage not ready' };
        }
        try {
            // Comprehensive table list: all tables (44)
            const tableList = [
                { storageKey: 'schools', tableName: 'schools' },
                { storageKey: 'users', tableName: 'users' },
                { storageKey: 'students', tableName: 'students' },
                { storageKey: 'teachers', tableName: 'teachers' },
                { storageKey: 'attendance', tableName: 'attendance' },
                { storageKey: 'staffAttendance', tableName: 'staff_attendance' },
                { storageKey: 'scores', tableName: 'scores' },
                { storageKey: 'finance', tableName: 'finance' },
                { storageKey: 'chart_of_accounts', tableName: 'chart_of_accounts' },
                { storageKey: 'budgets', tableName: 'budgets' },
                { storageKey: 'accounts_receivable', tableName: 'accounts_receivable' },
                { storageKey: 'tax_settings', tableName: 'tax_settings' },
                { storageKey: 'financial_attachments', tableName: 'financial_attachments' },
                { storageKey: 'receipts', tableName: 'receipts' },
                { storageKey: 'questions', tableName: 'questions' },
                { storageKey: 'tests', tableName: 'tests' },
                { storageKey: 'testResults', tableName: 'test_results' },
                { storageKey: 'testQuestions', tableName: 'test_questions' },
                { storageKey: 'testAttempts', tableName: 'test_attempts' },
                { storageKey: 'exams', tableName: 'exams' },
                { storageKey: 'examQuestions', tableName: 'exam_questions' },
                { storageKey: 'examResults', tableName: 'exam_results' },
                { storageKey: 'calendarEvents', tableName: 'calendar_events' },
                { storageKey: 'activationCodes', tableName: 'activation_codes' },
                { storageKey: 'chats', tableName: 'chats' },
                { storageKey: 'messages', tableName: 'messages' },
                { storageKey: 'studentMessages', tableName: 'student_messages' },
                { storageKey: 'parentMessages', tableName: 'parent_messages' },
                { storageKey: 'notifications', tableName: 'notifications' },
                { storageKey: 'parentAnnouncements', tableName: 'parent_announcements' },
                { storageKey: 'adverts', tableName: 'adverts' },
                { storageKey: 'library_books', tableName: 'library_books' },
                { storageKey: 'book_loans', tableName: 'book_loans' },
                { storageKey: 'homework', tableName: 'homework' },
                { storageKey: 'homeworkSubmissions', tableName: 'homework_submissions' },
                { storageKey: 'timetable', tableName: 'timetable' },
                { storageKey: 'domainScores', tableName: 'domain_scores' },
                { storageKey: 'scoreSessions', tableName: 'score_sessions' },
                { storageKey: 'stories', tableName: 'stories' },
                { storageKey: 'storyInteractions', tableName: 'story_interactions' },
                { storageKey: 'storyComments', tableName: 'story_comments' },
                { storageKey: 'storySubmissions', tableName: 'story_submissions' },
                { storageKey: 'systemConfig', tableName: 'system_config' }
                // Skipping auditLog and syncLog to reduce usage
            ];

            // Helper for standard merging
            const mergeWithLocal = (cloudData, storageKey) => {
                const localData = Storage.getData(storageKey) || [];
                const merged = [...cloudData];
                localData.forEach(localItem => {
                    if (!merged.find(cloudItem => cloudItem.id === localItem.id)) {
                        merged.push(localItem);
                    }
                });
                Storage.setData(storageKey, merged);
                results.downloaded[storageKey] = cloudData.length;
            };

            // Process each table: if options provided, only sync those explicitly true
            const selectiveSync = Object.keys(options).length > 0;
            for (const tbl of tableList) {
                if (selectiveSync && options[tbl.storageKey] !== true) continue;

                try {
                    const { data: cloudData, error } = await supabase.from(tbl.tableName).select('*');
                    if (error) {
                        console.error(`Error downloading ${tbl.tableName}:`, error);
                        results.downloaded[tbl.storageKey] = 0;
                        continue;
                    }
                    if (!cloudData || cloudData.length === 0) {
                        results.downloaded[tbl.storageKey] = 0;
                        continue;
                    }

                    const camelData = toCamelCase(cloudData);

                    if (tbl.storageKey === 'schools') {
                        // Unpack settings to top level for schools
                        const unpacked = camelData.map(s => {
                            if (s.settings && typeof s.settings === 'object') {
                                return { ...s, ...s.settings };
                            }
                            return s;
                        });
                        const localSchools = Storage.getData('schools') || [];
                        const mergedSchools = [...unpacked];
                        localSchools.forEach(ls => {
                            if (!mergedSchools.find(ms => ms.id === ls.id)) {
                                mergedSchools.push(ls);
                            }
                        });
                        Storage.setData('schools', mergedSchools);
                        results.downloaded.schools = cloudData.length;
                    } else if (tbl.storageKey === 'users') {
                        const localUsers = Storage.getData('users') || [];
                        const mergedUsers = [...camelData];
                        localUsers.forEach(lu => {
                            const cloudMatch = mergedUsers.find(mu => mu.id === lu.id || (mu.username === lu.username && mu.username));
                            if (!cloudMatch) {
                                mergedUsers.push(lu);
                            } else {
                                if (lu.password && (!cloudMatch.password || cloudMatch.password === 'null' || cloudMatch.password === '')) {
                                    cloudMatch.password = lu.password;
                                    console.log(`Preserved local password for user: ${lu.username}`);
                                }
                            }
                        });
                        Storage.setData('users', mergedUsers);
                        results.downloaded.users = cloudData.length;
                    } else if (tbl.storageKey === 'systemConfig') {
                        // Apply system settings globally - full replacement
                        const settings = camelData[0]?.settings || {};
                        const db = Storage.getDB();
                        db.systemSettings = settings;
                        Storage.saveDB(db);
                        results.downloaded.systemConfig = 1;
                        console.log('✓ Downloaded systemConfig');
                    } else {
                        mergeWithLocal(camelData, tbl.storageKey);
                    }
                } catch (err) {
                    console.error(`Exception downloading ${tbl.tableName}:`, err);
                    results.downloaded[tbl.storageKey] = 0;
                }
            }

            results.totalRecords = Object.values(results.downloaded).reduce((sum, count) => sum + (count || 0), 0);
            localStorage.setItem(this.SYNC_STORAGE_KEY, new Date().toISOString());

        } catch (error) {
            console.error('Download error:', error);
            return { success: false, message: error.message };
        } finally {
            this.syncInProgress = false;
        }

        return results;
    },

    // =====================================================
    // SYNC SPECIFIC SCHOOL
    // =====================================================
    async syncSchool(schoolId, direction = 'upload') {
        if (!this.isReady()) {
            return { success: false, message: 'Supabase not configured' };
        }

        const supabase = getSupabase();

        if (direction === 'upload') {
            // Upload school-specific data
            const results = { success: true, schoolId };

            try {
                // Get school
                const schools = Storage.getData('schools') || [];
                const school = schools.find(s => s.id === schoolId);
                if (school) {
                    await supabase.from('schools').upsert(this.prepareData('schools', { ...school, supabase_last_sync: new Date().toISOString() }));
                    results.school = 1;
                }

                // Get users for this school
                const users = (Storage.getData('users') || []).filter(u => u.schoolId === schoolId);
                if (users.length > 0) {
                    const { error } = await supabase.from('users').upsert(users.map(u => this.prepareData('users', { ...u, supabase_last_sync: new Date().toISOString() })));
                    results.users = users.length;
                }

                // Get students for this school
                const students = (Storage.getData('students') || []).filter(s => s.schoolId === schoolId);
                if (students.length > 0) {
                    const { error } = await supabase.from('students').upsert(students.map(s => this.prepareData('students', { ...s, supabase_last_sync: new Date().toISOString() })));
                    results.students = students.length;
                }

                // Get attendance for this school
                const attendance = (Storage.getData('attendance') || []).filter(a => a.schoolId === schoolId);
                if (attendance.length > 0) {
                    await supabase.from('attendance').upsert(attendance.map(a => this.prepareData('attendance', { ...a, supabase_last_sync: new Date().toISOString() })));
                    results.attendance = attendance.length;
                }

                return results;

            } catch (error) {
                return { success: false, message: error.message };
            }
        } else {
            // Download school data
            const results = { success: true, schoolId };

            try {
                const { data: school } = await supabase.from('schools').select('*').eq('id', schoolId).single();
                if (school) {
                    const localSchools = Storage.getData('schools') || [];
                    const existing = localSchools.findIndex(s => s.id === schoolId);
                    if (existing >= 0) localSchools[existing] = school;
                    else localSchools.push(school);
                    Storage.setData('schools', localSchools);
                    results.school = 1;
                }

                return results;
            } catch (error) {
                return { success: false, message: error.message };
            }
        }
    },

    // =====================================================
    // SYNC ATTENDANCE (Most important for QR scanning)
    // =====================================================
    async syncAttendance() {
        if (!this.isReady()) {
            return { success: false, message: 'Supabase not configured' };
        }

        const supabase = getSupabase();
        const attendance = Storage.getData('attendance') || [];

        if (attendance.length === 0) {
            return { success: true, message: 'No attendance to sync', count: 0 };
        }

        try {
            const { data, error } = await supabase
                .from('attendance')
                .upsert(attendance.map(a => ({
                    ...a,
                    supabase_last_sync: new Date().toISOString()
                })), { onConflict: 'id' });

            if (error) throw error;

            return { success: true, count: attendance.length };

        } catch (error) {
            console.error('Attendance sync error:', error);
            return { success: false, message: error.message };
        }
    },

    // =====================================================
    // LOG SYNC HISTORY
    // =====================================================
    async logSync(results) {
        if (!this.isReady()) return;

        const supabase = getSupabase();

        try {
            // Try to log sync - but don't fail if it doesn't work
            const logData = {
                id: (typeof Storage !== 'undefined' && Storage.generateId) ? Storage.generateId() : 'log-' + Date.now(),
                sync_type: 'full',
                direction: 'upload',
                records_count: (results.schools?.uploaded || 0) +
                    (results.users?.uploaded || 0) +
                    (results.students?.uploaded || 0) +
                    (results.attendance?.uploaded || 0) +
                    (results.scores?.uploaded || 0) +
                    (results.finance?.uploaded || 0),
                status: results.success ? 'success' : 'error',
                error_message: results.success ? null : (results.message || 'Partial failure')
            };

            // Only add school_id if we have one globally
            if (typeof Auth !== 'undefined' && Auth.getSchoolId && Auth.getSchoolId()) {
                logData.school_id = Auth.getSchoolId();
            }

            await supabase.from('sync_log').insert(logData);
        } catch (e) {
            console.warn('Could not log sync:', e.message);
        }
    },

    // =====================================================
    // GET SYNC LOG FROM CLOUD
    // =====================================================
    async getSyncHistory() {
        if (!this.isReady()) return [];

        const supabase = getSupabase();

        try {
            const { data } = await supabase
                .from('sync_log')
                .select('*')
                .order('created_at', { ascending: false })
                .limit(20);
            return data || [];
        } catch (e) {
            console.warn('Could not get sync history:', e);
            return [];
        }
    },

    // =====================================================
    // CLEAR OLD DATA (Free tier optimization)
    // =====================================================
    async pruneOldData(options = {}) {
        const results = { deleted: 0 };

        try {
            // Prune old attendance (older than 6 months)
            if (options.pruneAttendance) {
                const attendance = Storage.getData('attendance') || [];
                const cutoffDate = new Date();
                cutoffDate.setMonth(cutoffDate.getMonth() - 6);

                const oldAttendance = attendance.filter(a => new Date(a.date) < cutoffDate);
                const newAttendance = attendance.filter(a => new Date(a.date) >= cutoffDate);

                if (oldAttendance.length > 0) {
                    Storage.setData('attendance', newAttendance);
                    results.deleted += oldAttendance.length;
                    results.attendanceDeleted = oldAttendance.length;
                }
            }

            // Prune old test results
            if (options.pruneTestResults) {
                const results2 = Storage.getData('testResults') || [];
                const cutoffDate = new Date();
                cutoffDate.setFullYear(cutoffDate.getFullYear() - 2);

                const oldResults = results2.filter(r => new Date(r.created_at) < cutoffDate);
                const newResults = results2.filter(r => new Date(r.created_at) >= cutoffDate);

                if (oldResults.length > 0) {
                    Storage.setData('testResults', newResults);
                    results.deleted += oldResults.length;
                    results.testResultsDeleted = oldResults.length;
                }
            }

            return { success: true, ...results };

        } catch (error) {
            return { success: false, message: error.message };
        }
    },

    // =====================================================
    // CHECK FREE TIER USAGE
    // =====================================================
    async checkUsage() {
        if (!this.isReady()) {
            return { success: false, message: 'Supabase not configured' };
        }

        const supabase = getSupabase();

        try {
            // Get row counts for all 43 tables (approximate)
            const counts = {};

            const tables = [
                'schools', 'users', 'students', 'teachers', 'attendance', 'staff_attendance',
                'scores', 'score_sessions', 'finance', 'chart_of_accounts', 'budgets',
                'accounts_receivable', 'tax_settings', 'financial_attachments', 'receipts',
                'questions', 'tests', 'test_results', 'test_questions', 'test_attempts',
                'exams', 'exam_questions', 'exam_results', 'calendar_events', 'activation_codes',
                'chats', 'messages', 'student_messages', 'parent_messages', 'notifications',
                'parent_announcements', 'adverts', 'library_books', 'book_loans', 'homework',
                'homework_submissions', 'timetable', 'stories', 'story_interactions',
                'story_comments', 'story_submissions', 'audit_log', 'sync_log', 'system_config'
            ];

            for (const table of tables) {
                const { count } = await supabase
                    .from(table)
                    .select('*', { count: 'exact', head: true });
                counts[table] = count || 0;
            }

            return {
                success: true,
                counts,
                totalRecords: Object.values(counts).reduce((a, b) => a + b, 0),
                recommendation: this.getRecommendation(counts)
            };

        } catch (error) {
            return { success: false, message: error.message };
        }
    },

    getRecommendation(counts) {
        const total = Object.values(counts).reduce((a, b) => a + b, 0);

        if (total < 10000) {
            return '✓ Well within free tier limits';
        } else if (total < 50000) {
            return '⚠ Approaching free tier limits. Consider pruning old data.';
        } else {
            return '❌ Approaching limits. Urgent: prune old attendance/test results.';
        }
    },

    // =====================================================
    // AUTO-SYNC ATTENDANCE ON QR SCAN
    // =====================================================
    async autoSyncAttendance() {
        // This can be called after QR scan marks attendance
        // Only syncs attendance (smallest data)
        if (this.isReady() && !this.syncInProgress) {
            return await this.syncAttendance();
        }
        return { success: false, message: 'Skipped - sync in progress or not ready' };
    },

    // =====================================================
    // BACKGROUND AUTO-REFRESH
    // DISABLED BY DEFAULT - Use manual sync to conserve Supabase free tier
    // Free tier: 50,000 rows/month - auto-sync every 30s would use ~86,400/day!
    // =====================================================
    refreshInterval: null,

    startAutoRefresh(intervalMs = 30000) { 
        if (!this.AUTO_SYNC_ENABLED) {
            console.log('Auto-sync is disabled to conserve Supabase free tier. Use manual sync instead.');
            return;
        }
        
        if (this.refreshInterval) {
            console.log('Auto-refresh already active');
            return;
        }

        console.log(`Starting auto-refresh every ${intervalMs / 1000}s`);
        this.refreshInterval = setInterval(async () => {
            if (this.syncInProgress) return;

            console.log('Background auto-sync triggered...');
            try {
                await this.syncFromCloud({
                    schools: true,
                    users: true,
                    students: true,
                    attendance: true,
                    scores: true,
                    finance: true
                });
            } catch (error) {
                console.error('Background sync failed:', error);
            }
        }, intervalMs);
    },

    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
            console.log('Auto-refresh stopped');
        }
    },

    // =====================================================
    // MANUAL SYNC - Primary method for free tier
    // =====================================================
    async manualSync() {
        if (this.syncInProgress) {
            return { success: false, message: 'Sync already in progress' };
        }
        
        console.log('Starting manual sync...');
        this.syncInProgress = true;
        
        try {
            const results = {
                uploaded: 0,
                downloaded: 0,
                errors: []
            };

            // Sync to cloud first
            const uploadResults = await this.syncAllToCloud();
            
            if (uploadResults.success) {
                results.uploaded = uploadResults.totalRecords || 0;
            } else if (uploadResults.message) {
                results.errors.push(uploadResults.message);
            }

            // Then sync from cloud
            const downloadResults = await this.syncFromCloud();
            
            if (downloadResults.success) {
                results.downloaded = downloadResults.totalRecords || 0;
            } else if (downloadResults.message) {
                results.errors.push(downloadResults.message);
            }

            // Update last sync time
            this.lastSyncTime = new Date().toISOString();
            localStorage.setItem(this.SYNC_STORAGE_KEY, this.lastSyncTime);

            // Log sync (disabled to reduce usage and avoid RLS errors)
            // await this.logSync('manual', 'both', results.uploaded + results.downloaded, results.errors.length === 0 ? 'success' : 'partial');

            console.log('Manual sync completed:', results);
            return { 
                success: true, 
                message: `Synced ${results.uploaded} up, ${results.downloaded} down`,
                details: results
            };

        } catch (error) {
            console.error('Manual sync failed:', error);
            // await this.logSync('manual', 'both', 0, 'error', error.message); // disabled to reduce usage
            return { success: false, message: error.message };
        } finally {
            this.syncInProgress = false;
        }
    },

    // =====================================================
    // SYNC ON LOGIN - Lightweight, role-based
    // =====================================================
    async syncOnLogin(options = { systemConfig: true }) {
        if (!this.SYNC_ON_LOGIN || !this.isReady()) {
            return { success: false, message: 'Sync on login disabled or not ready' };
        }

        console.log('Syncing on login with options:', options);
        try {
            const result = await this.syncFromCloud(options);
            
            if (result.success) {
                this.lastSyncTime = new Date().toISOString();
                localStorage.setItem(this.SYNC_STORAGE_KEY, this.lastSyncTime);
            }
            
            return result;
        } catch (error) {
            console.warn('Login sync failed:', error);
            return { success: false, message: error.message };
        }
    },

    // =====================================================
    // SYNC ON LOGOUT - Save data before leaving
    // =====================================================
    async syncOnLogout() {
        if (!this.SYNC_ON_LOGOUT || !this.isReady()) {
            return { success: false, message: 'Sync on logout disabled or not ready' };
        }

        console.log('Syncing on logout...');
        try {
            const result = await this.syncAllToCloud({
                schools: true,
                users: true,
                students: true,
                attendance: true,
                scores: true,
                finance: true,
                systemConfig: true
            });
            
            return result;
        } catch (error) {
            console.warn('Logout sync failed:', error);
            return { success: false, message: error.message };
        }
    },

    // =====================================================
    // GET SYNC STATUS
    // =====================================================
    getSyncStatus() {
        return {
            lastSyncTime: this.lastSyncTime,
            isEnabled: this.AUTO_SYNC_ENABLED,
            isInProgress: this.syncInProgress,
            syncOnLogin: this.SYNC_ON_LOGIN,
            syncOnLogout: this.SYNC_ON_LOGOUT
        };
    },

    // Enable or disable auto-sync
    setAutoSync(enabled) {
        this.AUTO_SYNC_ENABLED = enabled;
        if (enabled) {
            this.startAutoRefresh();
        } else {
            this.stopAutoRefresh();
        }
    },

    // =====================================================
    // UPLOAD AUDIT LOG - Missing function implementation
    // =====================================================
    async uploadAuditLog(logs) {
        if (!this.isReady()) return { success: false, reason: 'Supabase not ready' };
        const supabase = getSupabase();
        if (!supabase) return { success: false, reason: 'Supabase client not available' };

        const tableName = 'audit_log';
        try {
            // Transform logs using SyncMapper
            const transformedLogs = logs.map(log => {
                const mapped = {};
                // Map fields according to sync-mapper for audit_log
                if (log.userId) mapped.user_id = log.userId;
                if (log.schoolId) mapped.school_id = log.schoolId;
                if (log.action) mapped.action = log.action;
                if (log.entityType) mapped.entity_type = log.entityType;
                if (log.entityId) mapped.entity_id = log.entityId;
                if (log.description) mapped.description = log.description;
                if (log.metadata) mapped.metadata = log.metadata;
                if (log.timestamp) mapped.timestamp = log.timestamp;
                if (log.ip) mapped.ip = log.ip;
                if (log.userAgent) mapped.user_agent = log.userAgent;
                mapped.created_at = new Date().toISOString();
                return mapped;
            });

            const { data, error } = await supabase.from(tableName).insert(transformedLogs).select();
            if (error) throw error;
            console.log(`✓ Uploaded ${data.length} audit log(s)`);
            return { success: true };
        } catch (e) {
            console.warn('Audit log upload failed:', e.message);
            return { success: false, reason: e.message };
        }
    },

    // =====================================================
    // UPLOAD SYNC LOG - Missing function implementation
    // =====================================================
    async uploadSyncLog(logs) {
        if (!this.isReady()) return { success: false, reason: 'Supabase not ready' };
        const supabase = getSupabase();
        if (!supabase) return { success: false, reason: 'Supabase client not available' };

        const tableName = 'sync_log';
        try {
            // Transform logs using sync-mapper pattern
            const transformedLogs = logs.map(log => {
                const mapped = {};
                if (log.schoolId) mapped.school_id = log.schoolId;
                if (log.userId) mapped.user_id = log.userId;
                if (log.type) mapped.type = log.type;
                if (log.direction) mapped.direction = log.direction;
                if (log.storageKey) mapped.storage_key = log.storageKey;
                if (log.recordCount) mapped.record_count = log.recordCount;
                if (log.status) mapped.status = log.status;
                if (log.error) mapped.error = log.error;
                if (log.durationMs) mapped.duration_ms = log.durationMs;
                mapped.created_at = new Date().toISOString();
                return mapped;
            });

            const { data, error } = await supabase.from(tableName).insert(transformedLogs).select();
            if (error) throw error;
            console.log(`✓ Uploaded ${data.length} sync log(s)`);
            return { success: true };
        } catch (e) {
            console.warn('Sync log upload failed:', e.message);
            return { success: false, reason: e.message };
        }
    }
};

// Export to window
window.SupabaseSync = SupabaseSync;

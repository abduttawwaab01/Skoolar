// Parent Homework Viewing Feature
// Adds homework viewing capabilities for parents

(function() {
    // Ensure ParentDashboard is available
    if (typeof ParentDashboard === 'undefined') {
        console.warn('ParentDashboard not found, homework features will not be installed');
        return;
    }

    // Extend ParentDashboard with homework methods
    ParentDashboard.loadHomework = function() {
        const container = document.getElementById('homeworkContent');
        if (!container) return;

        if (!this.currentChild) {
            container.innerHTML = '<p class="text-muted">Select a child to view homework</p>';
            return;
        }

        const statusFilter = document.getElementById('homeworkStatusFilter') ? document.getElementById('homeworkStatusFilter').value : 'all';

        // Get all active homework for this class
        const homeworks = Storage.getData('homework')?.filter(h =>
            h.schoolId === this.schoolId &&
            h.class === this.currentChild.class &&
            h.status === 'active'
        ) || [];

        // Get student's submissions
        const submissions = Storage.getStudentHomeworkSubmissions(this.currentChild.id, this.schoolId);
        const submissionMap = {};
        submissions.forEach(s => {
            submissionMap[s.homeworkId] = s;
        });

        // Filter homeworks based on status filter
        const filteredHomeworks = homeworks.filter(homework => {
            if (statusFilter === 'all') return true;
            const submission = submissionMap[homework.id];
            if (!submission) return statusFilter === 'pending';
            return submission.status === statusFilter;
        });

        // Render
        this.renderHomeworkList(filteredHomeworks, submissionMap);
        this.updateHomeworkStats(homeworks, submissionMap);
    };

    ParentDashboard.updateHomeworkStats = function(homeworks, submissionMap) {
        const total = homeworks.length;
        const pending = homeworks.filter(h => !submissionMap[h.id]).length;
        const submitted = homeworks.filter(h => submissionMap[h.id] && submissionMap[h.id].status === 'submitted').length;
        const graded = homeworks.filter(h => submissionMap[h.id] && submissionMap[h.id].status === 'graded').length;

        const totalEl = document.getElementById('homeworkTotalCount');
        const pendingEl = document.getElementById('homeworkPendingCount');
        const submittedEl = document.getElementById('homeworkSubmittedCount');
        const gradedEl = document.getElementById('homeworkGradedCount');

        if (totalEl) totalEl.textContent = total;
        if (pendingEl) pendingEl.textContent = pending;
        if (submittedEl) submittedEl.textContent = submitted;
        if (gradedEl) gradedEl.textContent = graded;
    };

    ParentDashboard.renderHomeworkList = function(homeworks, submissionMap) {
        const container = document.getElementById('homeworkContent');
        if (!container) return;

        if (homeworks.length === 0) {
            container.innerHTML = '<p class="text-muted">No homework assignments found</p>';
            return;
        }

        let html = `
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Assignment</th>
                            <th>Subject</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Grade</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        homeworks.forEach(homework => {
            const submission = submissionMap[homework.id];
            const dueDate = new Date(homework.due_date).toLocaleDateString();
            let statusBadge = '';
            let gradeText = '-';

            if (submission) {
                if (submission.status === 'graded') {
                    statusBadge = `<span class="badge badge-success">Graded (${submission.grade}%)</span>`;
                    gradeText = `${submission.grade}%`;
                } else if (submission.status === 'submitted') {
                    statusBadge = `<span class="badge badge-info">Submitted</span>`;
                    gradeText = '-';
                }
            } else {
                statusBadge = `<span class="badge badge-warning">Pending</span>`;
                gradeText = '-';
            }

            const actionBtn = submission ?
                `<button class="btn btn-sm btn-outline" onclick="ParentDashboard.viewHomeworkDetails('${homework.id}', '${submission.id}')">View</button>` :
                '<span class="text-muted">-</span>';

            const truncatedDesc = this.truncateText ? this.truncateText(homework.description || '', 80) : (homework.description ? homework.description.substring(0, 80) + (homework.description.length > 80 ? '...' : '') : '');

            html += `
                <tr>
                    <td>
                        <strong>${homework.title}</strong>
                        ${homework.description ? `<br><small class="text-muted">${truncatedDesc}</small>` : ''}
                    </td>
                    <td>${homework.subject}</td>
                    <td>${dueDate}</td>
                    <td>${statusBadge}</td>
                    <td>${gradeText}</td>
                    <td>${actionBtn}</td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        container.innerHTML = html;
    };

    ParentDashboard.getHomeworkStatusBadge = function(status, grade) {
        if (status === 'graded') {
            return `<span class="badge badge-success">Graded (${grade}%)</span>`;
        } else if (status === 'submitted') {
            return `<span class="badge badge-info">Submitted</span>`;
        } else {
            return `<span class="badge badge-warning">Pending</span>`;
        }
    };

    ParentDashboard.viewHomeworkDetails = function(homeworkId, submissionId) {
        if (!this.currentChild) {
            Toast.error('No child selected');
            return;
        }

        // Get submission
        const submissions = Storage.getStudentHomeworkSubmissions(this.currentChild.id, this.schoolId, homeworkId);
        const submission = submissions.find(s => s.id === submissionId);
        if (!submission) {
            Toast.error('Submission not found');
            return;
        }

        // Get homework details
        const homework = Storage.getData('homework')?.find(h => h.id === homeworkId);
        if (!homework) {
            Toast.error('Homework not found');
            return;
        }

        const totalMarks = homework.total_marks || 100;
        const dueDate = new Date(homework.due_date).toLocaleDateString();
        const submissionDate = new Date(submission.submissionDate).toLocaleString();

        let gradeHtml = '';
        if (submission.status === 'graded' && submission.grade !== null) {
            const percentage = Math.round((submission.grade / totalMarks) * 100);
            gradeHtml = `
                <div class="card" style="background: var(--lighter); margin-top: 15px; padding: 15px; border-radius: 8px;">
                    <h5><i class="fas fa-check-circle" style="color: var(--success);"></i> Graded</h5>
                    <p><strong>Score:</strong> ${submission.grade} / ${totalMarks} (${percentage}%)</p>
                    ${submission.feedback ? `<p><strong>Feedback:</strong></p><div style="background: #fff; padding: 10px; border-radius: 4px; margin-top: 5px;">${submission.feedback}</div>` : ''}
                    <p><small>Graded by: ${submission.gradedBy || 'System'} on ${new Date(submission.gradedAt).toLocaleString()}</small></p>
                </div>
            `;
        } else {
            gradeHtml = `
                <div class="alert alert-info">
                    <i class="fas fa-clock"></i> This homework is pending grading.
                </div>
            `;
        }

         const modalBody = `
             <div class="form-group">
                 <label><strong>Assignment:</strong></label>
                 <p>${homework.title}</p>
             </div>
             <div class="form-group">
                 <label><strong>Subject:</strong></label>
                 <p>${homework.subject}</p>
             </div>
             <div class="form-group">
                 <label><strong>Due Date:</strong></label>
                 <p>${dueDate}</p>
             </div>
             <div class="form-group">
                 <label><strong>Description:</strong></label>
                 <p>${homework.description || 'No description provided'}</p>
             </div>
             <hr style="margin: 15px 0; border: none; border-top: 1px solid var(--gray);">
             <div class="form-group">
                 <label><strong>Your Submission:</strong></label>
                 <div style="background: var(--lighter); padding: 15px; border-radius: 8px; white-space: pre-wrap; margin-top: 5px; min-height: 50px;">
                     ${submission.answerText || '<em class="text-muted">No text provided</em>'}
                 </div>
                 <small class="text-muted">Submitted on: ${submissionDate}</small>
             </div>
             ${submission.attachments && submission.attachments.length > 0 ? `
                 <div class="form-group">
                     <label><strong>Attachments (${submission.attachments.length}):</strong></label>
                     <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
                         ${submission.attachments.map(att => `
                             <div style="border: 1px solid var(--gray); border-radius: 8px; padding: 8px; text-align: center; background: #fff;">
                                 <img src="${att.data}" alt="${att.name}" style="width: 120px; height: 120px; object-fit: cover; border-radius: 4px; margin-bottom: 5px;">
                                 <div style="font-size: 11px; color: var(--gray); max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${att.name}">${att.name}</div>
                             </div>
                         `).join('')}
                     </div>
                 </div>
             ` : ''}
             ${gradeHtml}
         `;

        document.getElementById('homeworkModalTitle').textContent = homework.title;
        document.getElementById('homeworkModalBody').innerHTML = modalBody;
        Modal.show('viewHomeworkModal');
    };

    // Add truncateText method if not already present
    if (typeof ParentDashboard.truncateText !== 'function') {
        ParentDashboard.truncateText = function(text, maxLength) {
            if (!text) return '';
            if (text.length <= maxLength) return text;
            return text.substring(0, maxLength) + '...';
        };
    }

    // Add loadProfile method for parent profile section
    ParentDashboard.loadProfile = function() {
        const user = Auth.getCurrentUser();
        const school = Auth.getSchool();
        
        // Populate user info
        const nameEl = document.getElementById('profileName');
        const emailEl = document.getElementById('profileEmail');
        const phoneEl = document.getElementById('profilePhone');
        
        if (nameEl) nameEl.textContent = user.name;
        if (emailEl) emailEl.textContent = user.email || 'N/A';
        if (phoneEl) phoneEl.textContent = user.phone || 'N/A';
        
        // Load children
        const childrenContainer = document.getElementById('profileChildrenList');
        if (!childrenContainer) return;
        
        const students = Storage.getStudents(this.schoolId);
        const children = students.filter(s => 
            s.parentId === user.id || 
            s.parentPhone === user.phone || 
            s.parentEmail === user.email
        );
        
        if (children.length === 0) {
            childrenContainer.innerHTML = '<p class="text-muted">No children linked to your account</p>';
            return;
        }
        
        let html = '<div class="stats-grid">';
        children.forEach(child => {
            html += `
                <div class="stat-card">
                    <div class="stat-icon primary">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">${child.name}</div>
                        <div class="stat-value">${child.class}</div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        childrenContainer.innerHTML = html;
    };

    console.log('Parent homework feature loaded');
})();

const AdminTimetable = {
    init() {
        this.populateClassFilter();
        this.populateTeacherSelect();
    },
    
    getSchoolId() {
        if (typeof Auth !== 'undefined' && Auth.getCurrentSchoolId) {
            return Auth.getCurrentSchoolId();
        }
        return null;
    },
    
    populateClassFilter() {
        const schoolId = this.getSchoolId();
        if (!schoolId) return;
        
        const classes = Storage.getSchoolClasses(schoolId) || [];
        const select = document.getElementById('timetableClassFilter');
        const modalSelect = document.getElementById('timetableClass');
        
        const options = ['<option value="">All Classes</option>'];
        classes.forEach(cls => {
            const option = `<option value="${cls}">${cls}</option>`;
            options.push(option);
        });
        
        if (select) select.innerHTML = options.join('');
        if (modalSelect) modalSelect.innerHTML = options.join('');
    },
    
    populateTeacherSelect() {
        const schoolId = this.getSchoolId();
        if (!schoolId) return;
        
        const teachers = Storage.getUsers(schoolId).filter(u => u.role === 'teacher');
        const select = document.getElementById('timetableTeacher');
        if (!select) return;
        
        let html = '<option value="">Select Teacher</option>';
        teachers.forEach(t => {
            html += `<option value="${t.id}">${t.name}</option>`;
        });
        select.innerHTML = html;
    },
    
    async loadTimetable() {
        const schoolId = this.getSchoolId();
        if (!schoolId) return;
        
        // Sync from cloud first to get latest timetable
        if (typeof SupabaseSync !== 'undefined' && typeof SupabaseSync.isReady === 'function' && SupabaseSync.isReady()) {
            try {
                await SupabaseSync.syncFromCloud({ timetable: true });
            } catch (e) {
                console.warn('Failed to sync timetable from cloud:', e);
            }
        }
        
        let timetable = Storage.getTimetable(schoolId) || [];
        
        const classFilter = document.getElementById('timetableClassFilter')?.value;
        const dayFilter = document.getElementById('timetableDayFilter')?.value;
        
        if (classFilter) {
            timetable = timetable.filter(t => t.class === classFilter);
        }
        if (dayFilter) {
            timetable = timetable.filter(t => t.dayOfWeek === dayFilter);
        }
        
        this.renderTable(timetable);
    },
    
    renderTable(timetable) {
        const tbody = document.getElementById('timetableTableBody');
        if (!tbody) return;
        
        if (timetable.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No timetable entries found</td></tr>';
            return;
        }
        
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        const sorted = [...timetable].sort((a, b) => {
            const dayA = days.indexOf(a.dayOfWeek);
            const dayB = days.indexOf(b.dayOfWeek);
            if (dayA !== dayB) return dayA - dayB;
            return (a.periodNumber || 0) - (b.periodNumber || 0);
        });
        
        tbody.innerHTML = sorted.map(entry => `
            <tr>
                <td>${entry.dayOfWeek || '-'}</td>
                <td>${entry.periodNumber || '-'}</td>
                <td>${entry.class || ''}${entry.section ? ' ' + entry.section : ''}</td>
                <td>${entry.subject || ''}</td>
                <td>${entry.teacherName || '-'}</td>
                <td>${entry.room || '-'}</td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="AdminTimetable.deleteEntry('${entry.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    },
    
    showAddTimetableModal() {
        this.populateClassFilter();
        this.populateTeacherSelect();
        
        document.getElementById('timetableClass').value = '';
        document.getElementById('timetableSectionInput').value = '';
        document.getElementById('timetableDay').value = 'Monday';
        document.getElementById('timetablePeriod').value = '';
        document.getElementById('timetableSubject').value = '';
        document.getElementById('timetableTeacher').value = '';
        document.getElementById('timetableRoom').value = '';
        document.getElementById('timetableTerm').value = 'First';
        document.getElementById('timetableYear').value = new Date().getFullYear();
        
        Modal.show('addTimetableModal');
    },
    
    hideAddTimetableModal() {
        Modal.hide('addTimetableModal');
    },
    
    saveTimetable() {
        const schoolId = this.getSchoolId();
        if (!schoolId) {
            alert('School not found');
            return;
        }
        
        const classVal = document.getElementById('timetableClass').value;
        const section = document.getElementById('timetableSectionInput').value;
        const day = document.getElementById('timetableDay').value;
        const period = parseInt(document.getElementById('timetablePeriod').value);
        const subject = document.getElementById('timetableSubject').value;
        const teacherId = document.getElementById('timetableTeacher').value;
        const room = document.getElementById('timetableRoom').value;
        const term = document.getElementById('timetableTerm').value;
        const year = parseInt(document.getElementById('timetableYear').value);
        
        if (!classVal || !period || !subject) {
            alert('Please fill in required fields (Class, Period, Subject)');
            return;
        }
        
        let teacherName = '';
        if (teacherId) {
            const teachers = Storage.getUsers(schoolId).filter(u => u.id === teacherId);
            teacherName = teachers.length > 0 ? teachers[0].name : '';
        }
        
        const entry = {
            id: 'tt_' + Date.now(),
            schoolId: schoolId,
            class: classVal,
            section: section || null,
            dayOfWeek: day,
            periodNumber: period,
            subject: subject,
            teacherId: teacherId || null,
            teacherName: teacherName,
            room: room || null,
            term: term,
            year: year,
            createdAt: new Date().toISOString()
        };
        
        Storage.addTimetableEntry(entry);
        
        // Trigger immediate sync to cloud
        if (typeof SupabaseSync !== 'undefined' && typeof SupabaseSync.isReady === 'function' && SupabaseSync.isReady()) {
            SupabaseSync.syncAllToCloud().catch(e => console.warn('Timetable sync failed:', e));
        }
        
        if (typeof Toast !== 'undefined') {
            Toast.success('Timetable entry added successfully');
        } else {
            alert('Timetable entry added successfully');
        }
        
        this.hideAddTimetableModal();
        this.loadTimetable();
    },
    
    deleteEntry(id) {
        if (!confirm('Are you sure you want to delete this timetable entry?')) return;
        
        Storage.deleteTimetableEntry(id);
        
        // Trigger immediate sync to cloud
        if (typeof SupabaseSync !== 'undefined' && typeof SupabaseSync.isReady === 'function' && SupabaseSync.isReady()) {
            SupabaseSync.syncAllToCloud().catch(e => console.warn('Timetable sync failed:', e));
        }
        
        if (typeof Toast !== 'undefined') {
            Toast.success('Timetable entry deleted');
        } else {
            alert('Timetable entry deleted');
        }
        
        this.loadTimetable();
    }
};

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('timetableSection')) {
        if (typeof AdminTimetable !== 'undefined') {
            AdminTimetable.init();
            AdminTimetable.loadTimetable();
        }
    }
});

-- ============================================
-- FIX: Add missing columns to notifications table
-- ============================================
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

-- ============================================
-- FIX: Add missing columns to parent_announcements table  
-- ============================================
ALTER TABLE parent_announcements ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

-- ============================================
-- FIX: Add missing columns to student_messages table
-- ============================================
ALTER TABLE student_messages ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

-- ============================================
-- FIX: Add missing columns to parent_messages table
-- ============================================
ALTER TABLE parent_messages ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

-- ============================================
-- FIX: Ensure all required columns exist in users table
-- ============================================
ALTER TABLE users ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

-- ============================================
-- FIX: Ensure all required columns exist in students table
-- ============================================
ALTER TABLE students ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

-- ============================================
-- FIX: Ensure activation_codes table has supabase_last_sync
-- ============================================
ALTER TABLE activation_codes ADD COLUMN IF NOT EXISTS supabase_last_sync TIMESTAMPTZ;

-- ============================================
-- FIX: Timetable unique constraint issue
-- ============================================

-- First, let's find the exact constraint name
-- Drop the problematic unique constraint if it exists
ALTER TABLE timetable DROP CONSTRAINT IF EXISTS timetable_id_class_day_of_week_period_number_term_ye_key;
ALTER TABLE timetable DROP CONSTRAINT IF EXISTS timetable_class_day_key;
ALTER TABLE timetable DROP CONSTRAINT IF EXISTS timetable_unique_entry;

-- Add a simple unique constraint on just the id (if needed for RLS)
-- Or remove unique constraint entirely to allow upserts
-- The app uses ID-based upsert, so we don't need composite unique constraints

-- ============================================
-- FIX: RLS Policies for proper sync
-- ============================================

-- Ensure schools table has proper RLS policy
ALTER TABLE schools ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "schools_all_access" ON schools;
CREATE POLICY "schools_all_access" ON schools FOR ALL USING (true) WITH CHECK (true);

-- Ensure users table has proper RLS policy
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "users_all_access" ON users;
CREATE POLICY "users_all_access" ON users FOR ALL USING (true) WITH CHECK (true);

-- Ensure activation_codes table has proper RLS policy
ALTER TABLE activation_codes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "activation_codes_all_access" ON activation_codes;
CREATE POLICY "activation_codes_all_access" ON activation_codes FOR ALL USING (true) WITH CHECK (true);

-- Ensure students table has proper RLS policy
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "students_all_access" ON students;
CREATE POLICY "students_all_access" ON students FOR ALL USING (true) WITH CHECK (true);

-- Ensure finance table has proper RLS policy
ALTER TABLE finance ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "finance_all_access" ON finance;
CREATE POLICY "finance_all_access" ON finance FOR ALL USING (true) WITH CHECK (true);

-- Ensure timetable table has proper RLS policy
ALTER TABLE timetable ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "timetable_all_access" ON timetable;
CREATE POLICY "timetable_all_access" ON timetable FOR ALL USING (true) WITH CHECK (true);

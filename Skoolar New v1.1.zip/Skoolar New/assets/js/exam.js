const Exam = {
    currentTest: null,
    questions: [],
    currentQuestionIndex: 0,
    answers: {},
    flaggedQuestions: [],
    timerInterval: null,
    timeRemaining: 0,
    violationCount: 0,
    violations: [],
    isSubmitting: false,
    autoSaveInterval: null,
    antiCheatSetupDone: false,
    devtoolsCheckInterval: null,
    extensionCheckInterval: null,
    
    // Fisher-Yates shuffle algorithm
    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    },
    
    init(test, questions) {
        this.currentTest = test;
        // Deep clone questions to avoid mutating original test data
        this.questions = JSON.parse(JSON.stringify(questions));
        
        // Shuffle question order for each student
        this.shuffleArray(this.questions);
        
        // Shuffle MCQ options and adjust correctAnswer
        this.questions.forEach(q => {
            if (q.type === 'mcq' && Array.isArray(q.options)) {
                // Save the text of the originally correct option
                const originalCorrect = q.options.find(opt => opt.letter === q.correctAnswer);
                const correctText = originalCorrect ? originalCorrect.text : null;
                // Shuffle options
                this.shuffleArray(q.options);
                // Reassign letters A, B, C, D...
                q.options.forEach((opt, idx) => {
                    opt.letter = String.fromCharCode(65 + idx); // A=65, B=66...
                });
                // Find the option with the original correct text and update correctAnswer
                if (correctText) {
                    const newCorrect = q.options.find(opt => opt.text === correctText);
                    if (newCorrect) {
                        q.correctAnswer = newCorrect.letter;
                    }
                }
            }
        });
        
        this.currentQuestionIndex = 0;
        this.answers = {};
        this.flaggedQuestions = [];
        this.violationCount = 0;
        this.violations = [];
        this.examStartTime = new Date();
        this.isPaused = false;
        this.lastViolationTime = 0;
        this.violationCooldown = 500; // ms - cooldown between counted violations

        // Set time remaining
        this.timeRemaining = (test.duration || 30) * 60;
        
        // Update exam header
        document.getElementById('examTitle').textContent = test.title;
        document.getElementById('examInfo').textContent = test.subject + ' | ' + test.class;
        
        // Show calculator button in exam header
        const calcBtn = document.getElementById('examCalculatorBtn');
        if (calcBtn) calcBtn.style.display = 'inline-flex';
        
        // Show warning modal if anti-cheat is enabled
        if (test.antiCheatEnabled) {
            this.showAntiCheatWarning(test);
        }
        
        // Render question navigation
        this.renderQuestionNav();
        
        // Render first question
        this.renderQuestion();
        
        // Start timer
        this.startTimer();
        
        // Anti-cheat: detect tab switching
        this.setupAntiCheat();
        
        // Prevent browser navigation
        this.preventNavigation();
    },
    
    showAntiCheatWarning(test) {
        const warningHtml = `
            <div id="antiCheatWarning" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.9);z-index:99999;display:flex;align-items:center;justify-content:center;">
                <div style="background:white;padding:30px;border-radius:12px;max-width:500px;text-align:center;">
                    <div style="font-size:48px;color:#dc2626;margin-bottom:15px;"><i class="fas fa-shield-alt"></i></div>
                    <h2 style="color:#dc2626;margin-bottom:15px;">Exam Security Notice</h2>
                    <p style="color:#64748b;margin-bottom:20px;">This exam has security measures enabled. Please read carefully:</p>
                    <ul style="text-align:left;margin-bottom:20px;padding-left:20px;">
                        ${test.preventTabSwitch ? '<li>Switching to another tab/window will be recorded</li>' : ''}
                        ${test.preventCopyPaste ? '<li>Copy/paste is disabled</li>' : ''}
                        ${test.requireFullscreen ? '<li>Fullscreen mode is required</li>' : ''}
                        ${test.preventRightClick ? '<li>Right-click is disabled</li>' : ''}
                    </ul>
                    <div style="background:#fef3c7;padding:15px;border-radius:8px;margin-bottom:20px;text-align:left;">
                        <strong><i class="fas fa-exclamation-triangle"></i> Warning:</strong>
                        <p style="margin:5px 0 0;font-size:13px;">3 or more violations will auto-submit your exam!</p>
                    </div>
                    <button onclick="Exam.startExam()" class="btn btn-success" style="padding:12px 30px;font-size:16px;">
                        <i class="fas fa-play"></i> I Understand, Start Exam
                    </button>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', warningHtml);
    },
    
    startExam() {
        const warning = document.getElementById('antiCheatWarning');
        if (warning) warning.remove();
        
        // Activate copy protection
        document.body.classList.add('exam-mode');
        
        // Request fullscreen if required
        if (this.currentTest.requireFullscreen) {
            document.documentElement.requestFullscreen().catch(() => {
                Toast.warning('Fullscreen required for this exam');
            });
        }
        
        // Capture initial data
        this.captureExamData();
    },
    
    captureExamData() {
        const user = Auth.getCurrentUser();
        this.examData = {
            testId: this.currentTest.id,
            studentId: user?.id || 'unknown',
            startTime: this.examStartTime.toISOString(),
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            screenResolution: `${screen.width}x${screen.height}`,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            language: navigator.language
        };
    },
    
    preventNavigation() {
        // Prevent back button
        history.pushState(null, null, location.href);
        window.onpopstate = () => {
            if (this.currentTest) {
                history.pushState(null, null, location.href);
                this.recordViolation('navigation', 'Student attempted to navigate away');
            }
        };
        
        // Prevent refresh
        window.onbeforeunload = (e) => {
            if (this.currentTest) {
                e.preventDefault();
                e.returnValue = '';
                this.recordViolation('refresh', 'Student attempted to refresh page');
            }
        };
    },
    
    generateIntegrityHash() {
        const data = {
            testId: this.currentTest?.id,
            studentId: StudentAuth.getCurrentStudent()?.id,
            startTime: this.examStartTime?.toISOString(),
            answers: this.answers,
            questions: this.questions.map(q => q.id)
        };
        const str = JSON.stringify(data);
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return 'INT-' + Math.abs(hash).toString(36).toUpperCase();
    },
    
    setupAntiCheat() {
        // Prevent multiple initializations
        if (this.antiCheatSetupDone) return;
        
        // Tab switching detection
        document.addEventListener('visibilitychange', () => {
            if (this.currentTest?.preventTabSwitch && document.hidden && this.currentTest) {
                this.recordViolation('tab_switch', 'Student switched to another tab/window');
            }
        });
        
        // Window blur detection
        window.addEventListener('blur', () => {
            if (this.currentTest?.preventTabSwitch && this.currentTest) {
                this.recordViolation('blur', 'Student clicked outside the exam window');
            }
        });
        
        // Mouse leaving detection
        document.addEventListener('mouseleave', (e) => {
            if (this.currentTest?.preventTabSwitch && e.clientY < 0) {
                this.recordViolation('mouse_leave', 'Student mouse left the exam area');
            }
        });
        
        // Prevent right-click
        document.addEventListener('contextmenu', (e) => {
            if (this.currentTest?.preventRightClick && this.currentTest) {
                e.preventDefault();
                this.recordViolation('right_click', 'Student attempted right-click');
            }
        });
        
        // Detect copy/paste attempts
        if (this.currentTest?.preventCopyPaste) {
            document.addEventListener('copy', (e) => {
                if (this.currentTest) {
                    e.preventDefault();
                    this.recordViolation('copy', 'Student attempted to copy text');
                }
            });
            
            document.addEventListener('cut', (e) => {
                if (this.currentTest) {
                    e.preventDefault();
                    this.recordViolation('cut', 'Student attempted to cut text');
                }
            });
            
            document.addEventListener('paste', (e) => {
                if (this.currentTest) {
                    e.preventDefault();
                    this.recordViolation('paste', 'Student attempted to paste text');
                }
            });
        }
        
        // Keyboard shortcuts prevention
        document.addEventListener('keydown', (e) => {
            if (!this.currentTest) return;
            
            // Block Alt+Tab, Alt+F4, Ctrl+W, Ctrl+Tab, F5
            if (e.altKey || e.ctrlKey || e.key === 'F5') {
                const blocked = ['Tab', 'F4', 'w', 'W', 'n', 'N', 't', 'T', 'r', 'R', 'F5'];
                if (blocked.includes(e.key) || e.altKey) {
                    e.preventDefault();
                    this.recordViolation('keyboard_shortcut', 'Student attempted keyboard shortcut: ' + e.key);
                }
            }
        });
        
        // Console detection - detect developer tools usage
        let consoleOpen = false;
        const checkConsole = () => {
            if (!this.currentTest) return;
            if (window.console && window.console.open) {
                consoleOpen = true;
                this.recordViolation('console_open', 'Student opened browser console');
            }
        };
        this.devtoolsCheckInterval = setInterval(checkConsole, 2000);
        
        // Detect PrintScreen key for screenshot attempts
        document.addEventListener('keydown', (e) => {
            if (!this.currentTest) return;
            if (e.key === 'PrintScreen' || e.keyCode === 44) {
                e.preventDefault();
                this.recordViolation('screenshot', 'Screenshot attempt (PrintScreen key)');
            }
        });
        
        // Network status monitoring
        window.addEventListener('online', () => {
            if (this.currentTest) {
                Toast.success('Connection restored');
            }
        });
        
        window.addEventListener('offline', () => {
            if (this.currentTest) {
                Toast.error('Connection lost! Exam will auto-submit when time expires.');
                this.recordViolation('offline', 'Student went offline during exam');
            }
        });
        
        // Screenshot detection (clipboard)
        document.addEventListener('paste', (e) => {
            if (this.currentTest && e.clipboardData) {
                const items = e.clipboardData.items;
                for (let i = 0; i < items.length; i++) {
                    if (items[i].type.indexOf('image') !== -1) {
                        this.recordViolation('screenshot', 'Student attempted to paste screenshot');
                        break;
                    }
                }
            }
        });
        
        // Fullscreen exit detection
        document.addEventListener('fullscreenchange', () => {
            if (this.currentTest?.requireFullscreen && !document.fullscreenElement) {
                this.recordViolation('fullscreen_exit', 'Student exited fullscreen mode');
            }
        });
        
        // Enable additional anti-cheat detection
        this.setupDevToolsDetection();
        this.setupExtensionDetection();
        this.antiCheatSetupDone = true;
    },
    
    // DevTools detection: block shortcuts and detect open DevTools
    setupDevToolsDetection() {
        // Block common DevTools shortcuts
        document.addEventListener('keydown', (e) => {
            if (!this.currentTest) return;
            // F12
            if (e.key === 'F12') {
                e.preventDefault();
                this.recordViolation('devtools_shortcut', 'Attempted to open DevTools (F12)');
                return;
            }
            // Ctrl+Shift+I or Ctrl+Shift+J (Windows/Linux)
            if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J')) {
                e.preventDefault();
                this.recordViolation('devtools_shortcut', 'Attempted to open DevTools (Ctrl+Shift+' + e.key + ')');
                return;
            }
            // Cmd+Option+I (Mac)
            if (e.metaKey && e.altKey && e.key === 'I') {
                e.preventDefault();
                this.recordViolation('devtools_shortcut', 'Attempted to open DevTools (Cmd+Option+I)');
            }
        });

        // Detect DevTools open by window size discrepancy
        let devtoolsOpen = false;
        this.devtoolsCheckInterval = setInterval(() => {
            if (!this.currentTest) return;
            try {
                const widthDiff = window.outerWidth - window.innerWidth;
                const heightDiff = window.outerHeight - window.innerHeight;
                // Threshold: if difference > 100px, DevTools likely open
                const isOpen = widthDiff > 100 || heightDiff > 100;
                if (isOpen && !devtoolsOpen) {
                    devtoolsOpen = true;
                    this.recordViolation('devtools_open', 'Developer Tools detected (window size anomaly)');
                } else if (!isOpen && devtoolsOpen) {
                    devtoolsOpen = false;
                }
            } catch (err) {
                // Ignore errors (e.g., cross-origin restrictions)
            }
        }, 1000);
    },

    // Detect browser extensions and userscripts
    setupExtensionDetection() {
        const checkExtensions = () => {
            if (!this.currentTest) return;
            try {
                // Userscript managers (Tampermonkey, Greasemonkey, Violentmonkey)
                if (typeof GM_info !== 'undefined' || typeof GM_xmlhttpRequest !== 'undefined' || typeof GM_setValue !== 'undefined') {
                    this.recordViolation('extension_userscript', 'Userscript manager detected');
                }
                // Chrome extension API exposed in page context
                if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
                    this.recordViolation('extension_chrome', 'Chrome extension detected');
                }
                // Firefox WebExtension API
                if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.id) {
                    this.recordViolation('extension_firefox', 'Firefox extension detected');
                }
                // Look for extension-injected DOM elements
                const extElements = document.querySelectorAll('link[href*="chrome-extension://"], script[src*="chrome-extension://"], iframe[src*="chrome-extension://"]');
                if (extElements.length > 0) {
                    this.recordViolation('extension_content', 'Extension content detected (DOM elements)');
                }
            } catch (e) {
                // Ignore any cross-origin errors
            }
        };

        // Run immediately
        checkExtensions();
        // Check periodically (every 5 seconds)
        this.extensionCheckInterval = setInterval(checkExtensions, 5000);
    },
    
    recordViolation(type, description) {
        const now = Date.now();
        const isDuplicate = this.lastViolationTime && (now - this.lastViolationTime) < this.violationCooldown;
        this.lastViolationTime = now;

        const violation = {
            type: type,
            description: description,
            timestamp: new Date().toISOString(),
            questionAtViolation: this.currentQuestionIndex + 1,
            totalQuestions: this.questions.length,
            answeredCount: Object.keys(this.answers).length
        };

        this.violations.push(violation);

        // Always log to storage (for audit trail)
        this.logViolation(violation);

        // If duplicate within cooldown, ignore for counting
        if (isDuplicate) {
            return;
        }

        this.violationCount++;

        // Update violation warning in header
        const violationEl = document.getElementById('violationWarning');
        const violationCountEl = document.getElementById('violationCount');
        if (violationEl && violationCountEl) {
            violationEl.style.display = 'block';
            violationCountEl.textContent = this.violationCount;
            if (this.violationCount === 1) {
                violationEl.style.color = 'var(--warning)';
            } else if (this.violationCount === 2) {
                violationEl.style.color = 'var(--danger)';
            }
        }

        if (this.violationCount === 1) {
            Toast.warning('⚠️ Warning 1/3: ' + description);
        } else if (this.violationCount === 2) {
            Toast.error('⚠️ Warning 2/3: ' + description + '. Your exam will be submitted on next violation!');
            // Force review - show all questions
            this.currentQuestionIndex = 0;
            this.renderQuestion();
        } else if (this.violationCount >= 3) {
            Toast.error('🚨 Exam Auto-Submitted due to multiple violations!');
            this.autoSubmitWithViolationReport();
            return;
        }
    },
    
    logViolation(violation) {
        const examLogs = Storage.getData('examLogs') || [];
        examLogs.push({
            studentId: StudentAuth.getCurrentUser().id,
            testId: this.currentTest.id,
            ...violation,
            violationNumber: this.violationCount
        });
        Storage.setData('examLogs', examLogs);
    },
    
    autoSubmitWithViolationReport() {
        const violationReport = {
            id: Storage.generateId(),
            testId: this.currentTest.id,
            studentId: StudentAuth.getCurrentUser().id,
            schoolId: this.currentTest.schoolId,
            testTitle: this.currentTest.title,
            subject: this.currentTest.subject,
            className: this.currentTest.class,
            violations: this.violations,
            violationCount: this.violationCount,
            autoSubmitted: true,
            submittedAt: new Date().toISOString(),
            answeredQuestions: Object.keys(this.answers).length,
            totalQuestions: this.questions.length,
            status: 'auto_submitted'
        };

        const violationReports = Storage.getData('violationReports') || [];
        violationReports.push(violationReport);
        Storage.setData('violationReports', violationReports);

        this.submitExam(true);
    },
    
    startTimer() {
        this.updateTimerDisplay();
        
        this.timerInterval = setInterval(() => {
            this.timeRemaining--;
            this.updateTimerDisplay();
            
            if (this.timeRemaining <= 0) {
                this.submitExam();
            } else if (this.timeRemaining <= 300) {
                document.getElementById('examTimer').classList.add('warning');
            }
        }, 1000);
        
        // Auto-save answers every 30 seconds
        this.autoSaveInterval = setInterval(() => {
            this.autoSaveAnswers();
        }, 30000);
    },
    
    autoSaveAnswers() {
        if (!this.currentTest || Object.keys(this.answers).length === 0) return;

        const examSessions = Storage.getData('examSessions') || [];
        const studentId = StudentAuth.getCurrentUser().id;

        const sessionIndex = examSessions.findIndex(s =>
            s.testId === this.currentTest.id &&
            s.studentId === studentId
        );

        const sessionData = {
            testId: this.currentTest.id,
            studentId: studentId,
            answers: this.answers,
            flaggedQuestions: this.flaggedQuestions,
            currentQuestionIndex: this.currentQuestionIndex,
            lastSaved: new Date().toISOString()
        };

        if (sessionIndex >= 0) {
            examSessions[sessionIndex] = sessionData;
        } else {
            examSessions.push(sessionData);
        }

        Storage.setData('examSessions', examSessions);
    },
    
    loadSavedAnswers() {
        if (!this.currentTest) return null;

        const examSessions = Storage.getData('examSessions') || [];
        const studentId = StudentAuth.getCurrentUser().id;

        return examSessions.find(s =>
            s.testId === this.currentTest.id &&
            s.studentId === studentId
        );
    },
    
    updateTimerDisplay() {
        const minutes = Math.floor(this.timeRemaining / 60);
        const seconds = this.timeRemaining % 60;
        document.getElementById('timerDisplay').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    },
    
    renderQuestionNav() {
        let html = '';
        this.questions.forEach((q, index) => {
            let classes = 'question-nav-btn';
            if (index === this.currentQuestionIndex) classes += ' current';
            else if (this.answers[q.id] !== undefined) classes += ' answered';
            else if (this.flaggedQuestions.includes(q.id)) classes += ' flagged';
            
            html += `<button class="${classes}" onclick="Exam.goToQuestion(${index})">${index + 1}</button>`;
        });
        document.getElementById('questionNav').innerHTML = html;
    },
    
    renderQuestion() {
        const question = this.questions[this.currentQuestionIndex];
        const container = document.getElementById('questionContainer');
        
        let html = `
            <div style="margin-bottom: 20px;">
                <span style="color: var(--gray);">Question ${this.currentQuestionIndex + 1} of ${this.questions.length}</span>
                <span class="test-type-badge ${question.difficulty}" style="margin-left: 10px;">${question.difficulty}</span>
            </div>
            <h3 style="margin-bottom: 20px;">${question.question}</h3>
        `;
        
        // Render based on question type
        if (question.type === 'mcq') {
            question.options.forEach((opt, idx) => {
                const letter = String.fromCharCode(65 + idx);
                const isSelected = this.answers[question.id] === letter;
                html += `
                    <button class="option-btn ${isSelected ? 'selected' : ''}" onclick="Exam.selectOption('${letter}')">
                        <strong>${letter}.</strong> ${opt.text}
                    </button>
                `;
            });
        } else if (question.type === 'tf') {
            const isTrue = this.answers[question.id] === 'True';
            const isFalse = this.answers[question.id] === 'False';
            html += `
                <button class="option-btn ${isTrue ? 'selected' : ''}" onclick="Exam.selectOption('True')">
                    <i class="fas fa-check-circle"></i> True
                </button>
                <button class="option-btn ${isFalse ? 'selected' : ''}" onclick="Exam.selectOption('False')">
                    <i class="fas fa-times-circle"></i> False
                </button>
            `;
        } else if (question.type === 'fillblank') {
            html += `
                <div class="form-group">
                    <input type="text" class="form-control" id="fillBlankAnswer" 
                           placeholder="Type your answer here"
                           value="${this.answers[question.id] || ''}"
                           onchange="Exam.selectOption(this.value)">
                </div>
            `;
        } else if (question.type === 'essay') {
            html += `
                <div class="form-group">
                    <textarea class="form-control" id="essayAnswer" rows="8"
                           placeholder="Type your answer here"
                           onchange="Exam.selectOption(this.value)">${this.answers[question.id] || ''}</textarea>
                    <small class="text-muted">Word count: <span id="wordCount">0</span></small>
                </div>
                <script>
                    document.getElementById('essayAnswer').addEventListener('input', function() {
                        const words = this.value.trim().split(/\\s+/).filter(w => w).length;
                        document.getElementById('wordCount').textContent = words;
                    });
                </script>
            `;
        }
        
        container.innerHTML = html;
        
        // Update nav buttons
        document.getElementById('prevQuestionBtn').style.display = this.currentQuestionIndex === 0 ? 'none' : 'inline-block';
        document.getElementById('nextQuestionBtn').style.display = 
            this.currentQuestionIndex === this.questions.length - 1 ? 'none' : 'inline-block';
    },
    
    selectOption(answer) {
        const question = this.questions[this.currentQuestionIndex];
        this.answers[question.id] = answer;
        this.renderQuestion();
        this.renderQuestionNav();
    },
    
    goToQuestion(index) {
        if (index >= 0 && index < this.questions.length) {
            this.currentQuestionIndex = index;
            this.renderQuestion();
            this.renderQuestionNav();
        }
    },
    
    prevQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.goToQuestion(this.currentQuestionIndex - 1);
        }
    },
    
    nextQuestion() {
        if (this.currentQuestionIndex < this.questions.length - 1) {
            this.goToQuestion(this.currentQuestionIndex + 1);
        }
    },
    
    flagQuestion() {
        const question = this.questions[this.currentQuestionIndex];
        const index = this.flaggedQuestions.indexOf(question.id);
        
        if (index === -1) {
            this.flaggedQuestions.push(question.id);
            Toast.info('Question flagged for review');
        } else {
            this.flaggedQuestions.splice(index, 1);
            Toast.info('Question unflagged');
        }
        
        this.renderQuestionNav();
    },
    
    submitExam(isAutoSubmit = false) {
        // Prevent duplicate submissions
        if (this.isSubmitting) {
            return;
        }
        
        clearInterval(this.timerInterval);
        
        if (isAutoSubmit) {
            // Auto-submit without confirmation
            this.isSubmitting = true;
            this.gradeExam();
            return;
        }
        
        this.isSubmitting = true;
        
        Modal.confirm({
            title: 'Submit Test',
            message: 'Are you sure you want to submit? You cannot change your answers after submission.',
            onConfirm: () => {
                this.gradeExam();
            }
        });
        
        // Reset flag after a delay if user cancels
        setTimeout(() => {
            this.isSubmitting = false;
        }, 1000);
    },
    
    gradeExam() {
        let correct = 0;
        let wrong = 0;
        let unanswered = 0;
        let totalMarks = 0;
        let obtainedMarks = 0;
        
        const gradedAnswers = this.questions.map(question => {
            const studentAnswer = this.answers[question.id];
            let isCorrect = false;
            let marksObtained = 0;
            const correctAnswer = question.correctAnswer || '';
            
            totalMarks += question.marks || 1;
            
            if (studentAnswer === undefined || studentAnswer === '') {
                unanswered++;
                marksObtained = 0;
            } else {
                // Check correct answer
                if (question.type === 'mcq' || question.type === 'tf') {
                    if (studentAnswer === correctAnswer) {
                        isCorrect = true;
                        correct++;
                        marksObtained = question.marks || 1;
                    } else {
                        wrong++;
                        marksObtained = 0;
                    }
                } else if (question.type === 'fillblank') {
                    // Auto-grade fill in the blank (case-insensitive)
                    if (studentAnswer.toLowerCase().trim() === correctAnswer.toLowerCase().trim()) {
                        isCorrect = true;
                        correct++;
                        marksObtained = question.marks || 1;
                    } else {
                        wrong++;
                        marksObtained = 0;
                    }
                } else {
                    // Essay - mark as pending manual grading
                    isCorrect = null;
                    marksObtained = 0;
                }
            }
            
            obtainedMarks += marksObtained;
            
            return {
                questionId: question.id,
                studentAnswer: studentAnswer || '',
                correctAnswer: correctAnswer,
                isCorrect: isCorrect,
                marks: marksObtained
            };
        });
        
            const percentage = totalMarks > 0 ? (obtainedMarks / totalMarks) * 100 : 0;
        
        // Generate exam integrity hash
        const integrityHash = this.generateIntegrityHash();
        
        // Calculate actual time spent
        const timeSpent = Math.floor((new Date() - this.examStartTime) / 1000);
        
        // Save result
        const student = StudentAuth.getCurrentStudent();
        const result = {
            id: Storage.generateId(),
            studentId: student.id,
            schoolId: StudentAuth.getCurrentSchoolId(),
            testId: this.currentTest.id,
            testTitle: this.currentTest.title,
            subject: this.currentTest.subject,
            class: this.currentTest.class,
            testType: this.currentTest.testType,
            recordToReportCard: this.currentTest.recordToReportCard || false,
            totalMarks: totalMarks,
            obtainedMarks: obtainedMarks,
            percentage: percentage,
            answers: gradedAnswers,
            completedAt: new Date().toISOString(),
            status: 'auto-graded',
            violationCount: this.violationCount,
            violations: this.violations,
            autoSubmitted: this.violationCount >= 3,
            // Security fields
            integrityHash: integrityHash,
            timeSpentSeconds: timeSpent,
            examData: this.examData
        };
        
        Storage.addItem('testResults', result);
        
        // Clear saved exam session after submission
        this.clearSavedSession();
        
        // Show results
        this.showResults(percentage, correct, wrong, unanswered, obtainedMarks, totalMarks);
    },
    
    clearSavedSession() {
        if (!this.currentTest) return;

        const examSessions = Storage.getData('examSessions') || [];
        const studentId = StudentAuth.getCurrentUser().id;

        const filteredSessions = examSessions.filter(s =>
            !(s.testId === this.currentTest.id && s.studentId === studentId)
        );

        Storage.setData('examSessions', filteredSessions);
    },
    
    showResults(percentage, correct, wrong, unanswered, obtained, total) {
        // Deactivate copy protection
        document.body.classList.remove('exam-mode');
        // Clear detection intervals
        if (this.devtoolsCheckInterval) clearInterval(this.devtoolsCheckInterval);
        if (this.extensionCheckInterval) clearInterval(this.extensionCheckInterval);
        
        // Hide exam, show result
        document.getElementById('examSection').style.display = 'none';
        document.getElementById('examResultSection').style.display = 'block';
        
        // Update result display
        const scoreEl = document.getElementById('resultScore');
        scoreEl.textContent = Math.round(percentage) + '%';
        
        let scoreClass = 'poor';
        if (percentage >= 90) scoreClass = 'excellent';
        else if (percentage >= 70) scoreClass = 'good';
        else if (percentage >= 50) scoreClass = 'average';
        
        scoreEl.className = 'result-score ' + scoreClass;
        
        let message = 'Keep practicing!';
        if (percentage >= 90) message = 'Excellent!';
        else if (percentage >= 70) message = 'Good job!';
        else if (percentage >= 50) message = 'Not bad!';
        
        document.getElementById('resultMessage').textContent = message;
        document.getElementById('resultDetails').textContent = `Score: ${obtained}/${total} marks`;
        
        document.getElementById('correctCount').textContent = correct;
        document.getElementById('wrongCount').textContent = wrong;
        document.getElementById('unansweredCount').textContent = unanswered;
        
        Toast.success('Test submitted successfully!');
    },

    toggleAnswers() {
        const section = document.getElementById('examAnswersSection');
        if (!section) return;

        if (section.style.display === 'none') {
            // Load answers
            const student = StudentAuth.getCurrentStudent();
            if (!student) {
                Toast.error('Student not authenticated');
                return;
            }

            const results = Storage.getTestResults(student.schoolId).filter(r => r.studentId === student.id && r.testId === this.currentTest.id);
            const latestResult = results[0];
            if (!latestResult) {
                Toast.error('Result not found');
                return;
            }

            const answers = latestResult.answers || [];
            const questions = this.questions;

            let html = '';
            answers.forEach((ans, idx) => {
                const q = questions.find(q => q.id === ans.questionId);
                if (!q) return;
                const isCorrect = ans.isCorrect;
                const icon = isCorrect ? '<i class="fas fa-check" style="color: #10b981;"></i>' : '<i class="fas fa-times" style="color: #ef4444;"></i>';
                const statusText = isCorrect ? 'Correct' : 'Incorrect';

                html += `
                    <div style="padding: 15px; border-bottom: 1px solid #eee; display: flex; align-items: flex-start; gap: 12px; background: ${isCorrect ? 'rgba(16, 185, 129, 0.05)' : 'rgba(239, 68, 68, 0.05)'}; border-radius: 8px; margin-bottom: 8px;">
                        <div style="font-weight: 600; width: 30px; text-align: center;">${idx + 1}.</div>
                        <div style="flex: 1;">
                            <div style="font-weight: 500; margin-bottom: 8px;">${q.question}</div>
                            ${q.type === 'mcq' ? 
                                `<div style="margin: 8px 0; padding: 8px; background: #f8fafc; border-radius: 4px;">
                                    Your answer: <strong>${ans.studentAnswer || 'None'}</strong> 
                                    &nbsp;|&nbsp; Correct: <strong>${ans.correctAnswer}</strong>
                                </div>` : 
                                `<div style="margin: 8px 0; padding: 8px; background: #f8fafc; border-radius: 4px;">
                                    Your answer: <em>${ans.studentAnswer || 'No answer provided'}</em>
                                </div>`
                            }
                            <div style="display: flex; align-items: center; gap: 6px;">
                                ${icon}
                                <span style="font-weight: 500; color: ${isCorrect ? '#10b981' : '#ef4444'};">${statusText}</span>
                            </div>
                        </div>
                    </div>
                `;
            });

            document.getElementById('answersList').innerHTML = html;
            section.style.display = 'block';
        } else {
            section.style.display = 'none';
        }
    }
};

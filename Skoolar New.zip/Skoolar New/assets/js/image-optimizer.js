// image-optimizer.js - Complete Version

const ImageOptimizer = {
    // Configuration
    config: {
        maxWidth: 300,           // Max width in pixels
        maxHeight: 300,          // Max height in pixels
        quality: 0.7,            // JPEG quality (0.7 = 70%)
        maxSizeKB: 50,           // Target max size in KB
        supportedFormats: ['image/jpeg', 'image/png', 'image/jpg', 'image/webp']
    },
    
    /**
     * Compress an image file
     * @param {File} file - The image file from input
     * @returns {Promise} - Returns compressed file info
     */
    async compress(file) {
        // Validate file type
        if (!this.config.supportedFormats.includes(file.type)) {
            throw new Error(`Unsupported format. Please use: ${this.config.supportedFormats.join(', ')}`);
        }
        
        // Check if already small enough
        if (file.size < this.config.maxSizeKB * 1024) {
            console.log('File already small enough, skipping compression');
            return {
                blob: file,
                dataUrl: await this.fileToDataUrl(file),
                size: file.size,
                width: null,
                height: null,
                skipped: true
            };
        }
        
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                const img = new Image();
                img.src = e.target.result;
                
                img.onload = () => {
                    try {
                        const result = this.resizeImage(img, file.type);
                        resolve(result);
                    } catch (error) {
                        reject(error);
                    }
                };
                
                img.onerror = () => {
                    reject(new Error('Failed to load image'));
                };
            };
            
            reader.onerror = () => {
                reject(new Error('Failed to read file'));
            };
            
            reader.readAsDataURL(file);
        });
    },
    
    /**
     * Resize image using canvas
     * @param {Image} img - The image element
     * @param {string} originalType - Original file type
     * @returns {Object} - Compressed image info
     */
    resizeImage(img, originalType) {
        // Calculate new dimensions
        let width = img.width;
        let height = img.height;
        
        if (width > height) {
            if (width > this.config.maxWidth) {
                height = Math.round(height * (this.config.maxWidth / width));
                width = this.config.maxWidth;
            }
        } else {
            if (height > this.config.maxHeight) {
                width = Math.round(width * (this.config.maxHeight / height));
                height = this.config.maxHeight;
            }
        }
        
        // Create canvas and draw resized image
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        // Convert to blob with compression
        const outputType = originalType === 'image/png' ? 'image/png' : 'image/jpeg';
        
        return new Promise((resolve) => {
            canvas.toBlob((blob) => {
                // Convert blob to data URL for preview
                const reader = new FileReader();
                reader.onload = (e) => {
                    resolve({
                        blob: blob,
                        dataUrl: e.target.result,
                        size: blob.size,
                        width: width,
                        height: height,
                        format: outputType
                    });
                };
                reader.readAsDataURL(blob);
            }, outputType, this.config.quality);
        });
    },
    
    /**
     * Convert file to data URL (for preview)
     * @param {File} file 
     * @returns {Promise}
     */
    fileToDataUrl(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    },
    
     /**
      * Upload compressed image to Supabase Storage (backward compatible wrapper)
      * @param {Blob} compressedBlob - The compressed image blob
      * @param {string} entityId - Entity identifier (student ID, staff ID, etc.)
      * @param {string} [subfolder='student-photos'] - Subfolder (for backward compatibility)
      * @returns {Promise<string>} - Returns public URL
      */
     async uploadToStorage(compressedBlob, entityId, subfolder = 'student-photos') {
         // Generate file path using entity ID
         const timestamp = Date.now();
         const filePath = `${subfolder}/${entityId}-${timestamp}.jpg`;
         return this.uploadToStorageByPath(compressedBlob, filePath);
     },
    
    /**
     * Convert blob to data URL (fallback)
     * @param {Blob} blob 
     * @returns {Promise}
     */
     blobToDataUrl(blob) {
         return new Promise((resolve, reject) => {
             const reader = new FileReader();
             reader.onload = (e) => resolve(e.target.result);
             reader.onerror = reject;
             reader.readAsDataURL(blob);
         });
     },
     
     /**
      * Internal: Upload blob to Supabase Storage using explicit path
      * @param {Blob} blob 
      * @param {string} filePath - Full storage path
      * @returns {Promise<string>}
      */
     async uploadToStorageByPath(blob, filePath) {
         // Check if Supabase is enabled
         if (!window.isSupabaseEnabled || !isSupabaseEnabled()) {
             console.log('Supabase not enabled, returning data URL');
             return await this.blobToDataUrl(blob);
         }
         
         try {
             const supabase = getSupabase() || window.supabaseClient;
             if (!supabase) {
                 throw new Error('Supabase not initialized');
             }
             
             // Upload to Supabase Storage
             const { data, error } = await supabase.storage
                 .from('school-files')
                 .upload(filePath, blob, {
                     contentType: 'image/jpeg',
                     upsert: true
                 });
             
             if (error) throw error;
             
             // Get public URL
             const { data: { publicUrl } } = supabase.storage
                 .from('school-files')
                 .getPublicUrl(filePath);
             
             console.log('✅ Image uploaded successfully:', publicUrl);
             return publicUrl;
             
         } catch (error) {
             console.error('❌ Failed to upload to Supabase:', error);
             Toast.warning('Cloud upload failed, storing locally');
             return await this.blobToDataUrl(blob);
         }
     },
    
    /**
     * Create a thumbnail version (even smaller)
     * @param {Blob} compressedBlob 
     * @returns {Promise}
     */
    async createThumbnail(compressedBlob) {
        const url = URL.createObjectURL(compressedBlob);
        const img = new Image();
        
        return new Promise((resolve, reject) => {
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                
                // Thumbnail size (50x50)
                canvas.width = 50;
                canvas.height = 50;
                
                ctx.drawImage(img, 0, 0, 50, 50);
                
                canvas.toBlob((thumbBlob) => {
                    resolve(thumbBlob);
                }, 'image/jpeg', 0.5);
            };
            
            img.onerror = reject;
            img.src = url;
        });
    },
    
    /**
     * Get storage statistics
     * @returns {Object}
     */
    getStats() {
        // Count images in localStorage (approximate)
        let totalSize = 0;
        let imageCount = 0;
        
        try {
            const students = Storage.getData('students') || [];
            students.forEach(student => {
                if (student.passportUrl && student.passportUrl.startsWith('data:image')) {
                    imageCount++;
                    // Approximate size (base64 is ~1.37x binary size)
                    const size = Math.round(student.passportUrl.length * 0.75);
                    totalSize += size;
                }
            });
            
            return {
                imageCount,
                totalSizeBytes: totalSize,
                totalSizeKB: Math.round(totalSize / 1024),
                totalSizeMB: (totalSize / (1024 * 1024)).toFixed(2)
            };
        } catch (error) {
            console.error('Error getting stats:', error);
            return { imageCount: 0, totalSizeKB: 0 };
        }
    },
    
    /**
     * Get storage path for different entity types
     * @param {string} entityType - student, staff, school-logo, user-avatar
     * @param {string} entityId - Unique identifier
     * @param {string} originalFilename - Original filename for extension
     * @returns {string} - Storage path
     */
    getStoragePath(entityType, entityId, originalFilename = 'image.jpg') {
        const timestamp = Date.now();
        const ext = originalFilename.split('.').pop().toLowerCase();
        const allowedExts = ['jpg', 'jpeg', 'png', 'webp'];
        const safeExt = allowedExts.includes(ext) ? ext : 'jpg';
        
        const paths = {
            'student': `student-photos/${entityId}-${timestamp}.${safeExt}`,
            'staff': `staff-photos/${entityId}-${timestamp}.${safeExt}`,
            'school-logo': `school-logos/${entityId}-${timestamp}.${safeExt}`,
            'user-avatar': `user-avatars/${entityId}-${timestamp}.${safeExt}`
        };
        
        return paths[entityType] || `misc/${entityType}/${entityId}-${timestamp}.${safeExt}`;
    },
    
    /**
     * Upload compressed image for any entity type (unified API)
     * @param {File} file - The image file from input
     * @param {string} entityType - student, staff, school-logo, user-avatar
     * @param {string} entityId - Entity identifier (student ID, staff ID, etc.)
     * @returns {Promise<string>} - Image URL (cloud or data URL fallback)
     */
    async uploadForEntity(file, entityType, entityId) {
        // Validate file type
        if (!file.type.startsWith('image/')) {
            throw new Error('Only image files are allowed');
        }
        
        // Compress the image
        const compressed = await this.compress(file);
        
        // Get storage path
        const filePath = this.getStoragePath(entityType, entityId, file.name);
        
        // Upload to cloud with fallback
        const url = await this.uploadToStorageByPath(compressed.blob, filePath);
        
        return {
            url: url,
            compressedSize: compressed.size,
            originalSize: file.size,
            width: compressed.width,
            height: compressed.height
        };
    },
    
    /**
     * Upload compressed image to Supabase Storage by explicit path
     * @param {Blob} blob - The compressed image blob
     * @param {string} filePath - Full storage path (e.g., 'student-photos/123.jpg')
     * @returns {Promise<string>} - Public URL
     */
    async uploadToStorageByPath(blob, filePath) {
        // Check if Supabase is enabled
        if (!window.isSupabaseEnabled || !isSupabaseEnabled()) {
            console.log('Supabase not enabled, returning data URL');
            return await this.blobToDataUrl(blob);
        }
        
        try {
            const supabase = getSupabase() || window.supabaseClient;
            if (!supabase) {
                throw new Error('Supabase not initialized');
            }
            
            // Upload to Supabase Storage
            const { data, error } = await supabase.storage
                .from('school-files')
                .upload(filePath, blob, {
                    contentType: 'image/jpeg',
                    upsert: true
                });
            
            if (error) throw error;
            
            // Get public URL
            const { data: { publicUrl } } = supabase.storage
                .from('school-files')
                .getPublicUrl(filePath);
            
            console.log('✅ Image uploaded successfully:', publicUrl);
            return publicUrl;
            
        } catch (error) {
            console.error('❌ Failed to upload to Supabase:', error);
            Toast.warning('Cloud upload failed, storing locally');
            return await this.blobToDataUrl(blob);
        }
    }
};

// Make globally available
window.ImageOptimizer = ImageOptimizer;
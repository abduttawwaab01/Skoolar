// Admin Stories Management Module
// Separate module for Super Admin to manage stories/novels
// DO NOT interfere with existing SuperAdmin code

// Use global Modal from core.js (with overflow handling)
// Use global Toast from core.js (with proper UI)

const AdminStories = {
    init() {
        console.log('AdminStories module initialized');
        // Initialize Stories module if available
        if (typeof Stories !== 'undefined' && typeof Stories.init === 'function') {
            Stories.init();
        }
        this.waitForSuperAdmin();
    },

    waitForSuperAdmin(maxAttempts = 50) {
        let attempts = 0;
        const check = () => {
            if (window.SuperAdmin && typeof SuperAdmin.showSection === 'function') {
                console.log('SuperAdmin found, hooking Stories navigation');
                this.hookSuperAdmin();
                this.checkInitialSection();
            } else if (attempts < maxAttempts) {
                attempts++;
                setTimeout(check, 100);
            } else {
                console.warn('SuperAdmin not found after ' + maxAttempts + ' attempts. Stories module may not work.');
            }
        };
        check();
    },

    hookSuperAdmin() {
        // Save reference to original method
        const originalShowSection = SuperAdmin.showSection;
        
        // Override to intercept 'stories' section
        SuperAdmin.showSection = function(section) {
            // Call original
            originalShowSection.apply(this, arguments);
            
            // If stories section, render our dashboard
            if (section === 'stories') {
                AdminStories.showSection();
            }
        };
        
        // Also handle school admin sections if needed
        if (SuperAdmin.showSchoolSection) {
            const originalShowSchoolSection = SuperAdmin.showSchoolSection;
            SuperAdmin.showSchoolSection = function(section) {
                originalShowSchoolSection.apply(this, arguments);
                // Stories management within school context could be added here
            };
        }
    },

    checkInitialSection() {
        // If storiesSection is already visible (e.g., direct navigation), initialize
        const storiesSection = document.getElementById('storiesSection');
        if (storiesSection && storiesSection.style.display !== 'none') {
            setTimeout(() => this.showSection(), 100);
        }
    },

    bindEvents() {
        // Additional event bindings
    },

    // Show stories management section
    showSection() {
        this.renderDashboard();
        this.loadStoriesList();
        this.loadSubmissionsList();
    },

    // Render the main stories management dashboard
    renderDashboard() {
        const container = document.getElementById('storiesSection');
        if (!container) return;

        container.innerHTML = `
            <div class="page-header">
                <div>
                    <h1 class="page-title">Stories Management</h1>
                    <p class="page-subtitle">Manage stories, novels, and review submissions</p>
                </div>
                <div class="flex gap-2">
                    <button class="btn btn-outline" onclick="AdminStories.openAddModal()">
                        <i class="fas fa-plus"></i> Add Story
                    </button>
                    <button class="btn btn-outline" onclick="AdminStories.openReviewModal()">
                        <i class="fas fa-eye"></i> Review Submissions
                    </button>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-grid mb-4">
                <div class="stat-card">
                    <div class="stat-icon primary">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Total Stories</div>
                        <div class="stat-value" id="statsTotalStories">0</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon success">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Published</div>
                        <div class="stat-value" id="statsPublished">0</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon warning">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Pending Review</div>
                        <div class="stat-value" id="statsPending">0</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon info">
                        <i class="fas fa-eye"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">Total Views</div>
                        <div class="stat-value" id="statsViews">0</div>
                    </div>
                </div>
            </div>

            <!-- Main Content Tabs -->
            <div class="card">
                <div class="card-header">
                    <div class="tabs" id="storiesTabs">
                        <button class="tab-btn active" data-tab="stories-list" onclick="AdminStories.switchTab('stories-list')">
                            <i class="fas fa-list"></i> All Stories
                        </button>
                        <button class="tab-btn" data-tab="submissions" onclick="AdminStories.switchTab('submissions')">
                            <i class="fas fa-inbox"></i> Submissions
                            <span class="badge" id="pendingSubmissionsBadge" style="display: none;">0</span>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Stories List Tab -->
                    <div id="stories-list" class="tab-content active">
                        <div class="filters-bar mb-3">
                            <div class="flex gap-2" style="flex-wrap: wrap;">
                                <select id="storiesStatusFilter" class="form-control" style="width: auto;" onchange="AdminStories.filterStories()">
                                    <option value="">All Status</option>
                                    <option value="published">Published</option>
                                    <option value="draft">Draft</option>
                                    <option value="pending_review">Pending</option>
                                    <option value="archived">Archived</option>
                                </select>
                                <select id="storiesGenreFilter" class="form-control" style="width: auto;" onchange="AdminStories.filterStories()">
                                    <option value="">All Genres</option>
                                </select>
                                <input type="text" id="storiesSearchInput" class="form-control" style="width: 200px;" placeholder="Search stories..." onkeyup="AdminStories.filterStories()">
                            </div>
                            <div class="mt-2">
                                <button class="btn btn-sm btn-outline" onclick="AdminStories.bulkDelete()" id="bulkDeleteBtn" style="display: none;">
                                    <i class="fas fa-trash"></i> Delete Selected
                                </button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" id="selectAllStories" onchange="AdminStories.toggleSelectAll()"></th>
                                        <th>Cover</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Genre</th>
                                        <th>Status</th>
                                        <th>Views</th>
                                        <th>Rating</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="storiesTableBody">
                                    <tr>
                                        <td colspan="9" style="text-align: center;">Loading stories...</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="pagination" id="storiesPagination" style="display: none;"></div>
                    </div>

                    <!-- Submissions Tab -->
                    <div id="submissions" class="tab-content" style="display: none;">
                        <div class="filters-bar mb-3">
                            <div class="flex gap-2">
                                <select id="submissionsStatusFilter" class="form-control" style="width: auto;" onchange="AdminStories.filterSubmissions()">
                                    <option value="pending_review">Pending</option>
                                    <option value="approved">Approved</option>
                                    <option value="rejected">Rejected</option>
                                    <option value="">All</option>
                                </select>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Genre</th>
                                        <th>Submitted</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="submissionsTableBody">
                                    <tr>
                                        <td colspan="7" style="text-align: center;">Loading submissions...</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.populateGenreFilter();
    },

    // Load stories into table
    loadStoriesList() {
        const stories = Stories.getStories(null, {}); // Get all stories regardless of status
        const statusFilter = document.getElementById('storiesStatusFilter')?.value;
        const genreFilter = document.getElementById('storiesGenreFilter')?.value;
        const searchFilter = document.getElementById('storiesSearchInput')?.value.toLowerCase();

        let filtered = stories;

        if (statusFilter) {
            filtered = filtered.filter(s => s.status === statusFilter);
        }
        if (genreFilter) {
            filtered = filtered.filter(s => s.genre === genreFilter);
        }
        if (searchFilter) {
            filtered = filtered.filter(s =>
                s.title.toLowerCase().includes(searchFilter) ||
                s.author_name.toLowerCase().includes(searchFilter)
            );
        }

        this.renderStoriesTable(filtered);
        this.updateStats();
    },

    renderStoriesTable(stories) {
        const tbody = document.getElementById('storiesTableBody');
        if (!tbody) return;

        if (stories.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" style="text-align: center; padding: 2rem;">No stories found</td></tr>';
            return;
        }

        tbody.innerHTML = stories.map(story => {
            const avgRating = Stories.getAverageRating(story.id);
            const statusColors = {
                published: 'success',
                draft: 'secondary',
                pending_review: 'warning',
                archived: 'danger',
                rejected: 'danger'
            };
            const statusClass = statusColors[story.status] || 'secondary';

            return `
                <tr data-story-id="${story.id}">
                    <td><input type="checkbox" class="story-select" value="${story.id}"></td>
                    <td>
                        <img src="${story.cover_image || 'https://via.placeholder.com/60x80'}" 
                             alt="Cover" style="width: 40px; height: 53px; object-fit: cover; border-radius: 4px;"
                             onerror="this.src='https://via.placeholder.com/40x53?text=No+Cover'">
                    </td>
                    <td>
                        <strong>${this.escapeHtml(story.title)}</strong>
                        ${story.featured ? '<span class="tag-pill" style="background: gold; color: black; font-size: 0.7rem; margin-left: 0.5rem;">★</span>' : ''}
                        <br><small style="color: var(--gray-500);">${story.word_count} words</small>
                    </td>
                    <td>${this.escapeHtml(story.author_name)}</td>
                    <td>${this.escapeHtml(story.genre)}</td>
                    <td><span class="badge bg-${statusClass}">${story.status.replace('_', ' ')}</span></td>
                    <td>${story.engagement?.views || 0}</td>
                    <td>${avgRating} ★</td>
                    <td>
                        <button class="btn btn-sm btn-outline" onclick="AdminStories.viewStory('${story.id}')" title="View">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline" onclick="AdminStories.editStory('${story.id}')" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        ${story.status !== 'published' ? 
                            `<button class="btn btn-sm btn-primary" onclick="AdminStories.approveStory('${story.id}')" title="Publish">
                                <i class="fas fa-check"></i>
                            </button>` : ''
                        }
                        <button class="btn btn-sm btn-danger" onclick="AdminStories.deleteStory('${story.id}')" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');

        this.bindTableEvents();
    },

    bindTableEvents() {
        const tbody = document.getElementById('storiesTableBody');
        if (!tbody) return;

        // Checkbox toggle
        const checkboxes = tbody.querySelectorAll('.story-select');
        const selectAll = document.getElementById('selectAllStories');
        const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');

        const updateBulkButton = () => {
            const checkedCount = tbody.querySelectorAll('.story-select:checked').length;
            bulkDeleteBtn.style.display = checkedCount > 0 ? 'inline-flex' : 'none';
        };

        checkboxes.forEach(cb => cb.addEventListener('change', updateBulkButton));
        if (selectAll) selectAll.addEventListener('change', updateBulkButton);

        updateBulkButton();
    },

    toggleSelectAll() {
        const selectAll = document.getElementById('selectAllStories');
        const checkboxes = document.querySelectorAll('#storiesTableBody .story-select');
        checkboxes.forEach(cb => cb.checked = selectAll.checked);
        this.bulkDeleteBtnUpdate();
    },

    bulkDeleteBtnUpdate() {
        const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
        if (!bulkDeleteBtn) return;
        const checkedCount = document.querySelectorAll('#storiesTableBody .story-select:checked').length;
        bulkDeleteBtn.style.display = checkedCount > 0 ? 'inline-flex' : 'none';
    },

    bulkDelete() {
        if (!confirm('Are you sure you want to delete selected stories?')) return;

        const selected = Array.from(document.querySelectorAll('#storiesTableBody .story-select:checked'))
            .map(cb => cb.value);

        selected.forEach(id => {
            Stories.deleteStory(id);
        });

        this.loadStoriesList();
        Toast && Toast.success('Deleted ' + selected.length + ' stories');
    },

    populateGenreFilter() {
        const allStories = Stories.getStories(null, {});
        const genres = [...new Set(allStories.map(s => s.genre))].sort();
        const select = document.getElementById('storiesGenreFilter');
        if (select) {
            select.innerHTML = '<option value="">All Genres</option>' +
                genres.map(g => `<option value="${g}">${g}</option>`).join('');
        }
    },

    updateStats() {
        const stories = Stories.getStories(null, {});
        const total = stories.length;
        const published = stories.filter(s => s.status === 'published').length;
        const pending = stories.filter(s => s.status === 'pending_review').length;
        const totalViews = stories.reduce((sum, s) => sum + (s.engagement?.views || 0), 0);

        const totalEl = document.getElementById('statsTotalStories');
        const publishedEl = document.getElementById('statsPublished');
        const pendingEl = document.getElementById('statsPending');
        const viewsEl = document.getElementById('statsViews');

        if (totalEl) totalEl.textContent = total;
        if (publishedEl) publishedEl.textContent = published;
        if (pendingEl) pendingEl.textContent = pending;
        if (viewsEl) viewsEl.textContent = totalViews.toLocaleString();
    },

    // Tabs
    switchTab(tabName) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = content.id === tabName ? 'block' : 'none';
        });

        if (tabName === 'submissions') {
            this.loadSubmissionsList();
        }
    },

    filterStories() {
        this.loadStoriesList();
    },

    // Story CRUD
    openAddModal() {
        this.openStoryModal();
    },

    editStory(storyId) {
        const story = Stories.getStory(storyId);
        if (!story) {
            Toast && Toast.error('Story not found');
            return;
        }
        this.openStoryModal(story);
    },

    openStoryModal(story = null) {
        const isEdit = !!story;
        const modalId = isEdit ? 'editStoryModal' : 'addStoryModal';

        const modalHTML = `
            <div class="modal-overlay" id="${modalId}">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3>${isEdit ? 'Edit Story' : 'Add New Story'}</h3>
                            <button class="modal-close" onclick="Modal.hide('${modalId}')">&times;</button>
                        </div>
                        <div class="modal-body">
                            <form id="${isEdit ? 'editStoryForm' : 'addStoryForm'}">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Title *</label>
                                        <input type="text" name="title" class="form-control" value="${this.escapeHtml(story?.title || '')}" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Subtitle</label>
                                        <input type="text" name="subtitle" class="form-control" value="${this.escapeHtml(story?.subtitle || '')}">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Genre *</label>
                                        <select name="genre" class="form-control" required>
                                            <option value="">Select...</option>
                                            <option value="Fantasy" ${story?.genre === 'Fantasy' ? 'selected' : ''}>Fantasy</option>
                                            <option value="Romance" ${story?.genre === 'Romance' ? 'selected' : ''}>Romance</option>
                                            <option value="Mystery" ${story?.genre === 'Mystery' ? 'selected' : ''}>Mystery</option>
                                            <option value="Thriller" ${story?.genre === 'Thriller' ? 'selected' : ''}>Thriller</option>
                                            <option value="Science Fiction" ${story?.genre === 'Science Fiction' ? 'selected' : ''}>Sci-Fi</option>
                                            <option value="Horror" ${story?.genre === 'Horror' ? 'selected' : ''}>Horror</option>
                                            <option value="Historical Fiction" ${story?.genre === 'Historical Fiction' ? 'selected' : ''}>Historical</option>
                                            <option value="Young Adult" ${story?.genre === 'Young Adult' ? 'selected' : ''}>Young Adult</option>
                                            <option value="Children" ${story?.genre === 'Children' ? 'selected' : ''}>Children</option>
                                            <option value="Literary Fiction" ${story?.genre === 'Literary Fiction' ? 'selected' : ''}>Literary</option>
                                            <option value="Nonfiction" ${story?.genre === 'Nonfiction' ? 'selected' : ''}>Nonfiction</option>
                                            <option value="Other" ${story?.genre === 'Other' ? 'selected' : ''}>Other</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Age Group *</label>
                                        <select name="age_group" class="form-control" required>
                                            <option value="all" ${story?.age_group === 'all' ? 'selected' : ''}>All Ages</option>
                                            <option value="children" ${story?.age_group === 'children' ? 'selected' : ''}>Children (0-12)</option>
                                            <option value="young_adult" ${story?.age_group === 'young_adult' ? 'selected' : ''}>Young Adult (13-18)</option>
                                            <option value="adult" ${story?.age_group === 'adult' ? 'selected' : ''}>Adult (18+)</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Description *</label>
                                    <textarea name="description" class="form-control" rows="3" required>${this.escapeHtml(story?.description || '')}</textarea>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Author Name *</label>
                                        <input type="text" name="author_name" class="form-control" value="${this.escapeHtml(story?.author_name || '')}" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Author Bio</label>
                                        <textarea name="author_bio" class="form-control" rows="2">${this.escapeHtml(story?.author_bio || '')}</textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Cover Image</label>
                                    ${story?.cover_image ? `
                                        <div style="margin-bottom: 1rem;">
                                            <img src="${story.cover_image}" style="max-width: 120px; border-radius: 8px;">
                                            <p><small>Current cover image</small></p>
                                        </div>
                                    ` : ''}
                                    <div class="file-upload-wrapper">
                                        <input type="file" name="cover_image_file" accept="image/*" data-current="${story?.cover_image || ''}">
                                        <div class="file-upload-icon"><i class="fas fa-image"></i></div>
                                        <div class="file-upload-text">Click to upload cover image</div>
                                        <div class="file-preview" style="display: none;">
                                            <img style="max-width: 120px; max-height: 160px;">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Story Content (HTML or plain text) *</label>
                                    <textarea name="content" class="form-control" rows="12" required>${this.escapeHtml(story?.content || '')}</textarea>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Word Count</label>
                                        <input type="number" name="word_count" class="form-control" value="${story?.word_count || 0}" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Read Time (min)</label>
                                        <input type="number" name="read_time_minutes" class="form-control" value="${story?.read_time_minutes || 1}">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Status *</label>
                                        <select name="status" class="form-control" required>
                                            <option value="draft" ${story?.status === 'draft' ? 'selected' : ''}>Draft</option>
                                            <option value="published" ${story?.status === 'published' ? 'selected' : ''}>Published</option>
                                            <option value="archived" ${story?.status === 'archived' ? 'selected' : ''}>Archived</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Featured?</label>
                                        <div class="checkbox-group">
                                            <input type="checkbox" name="featured" ${story?.featured ? 'checked' : ''}>
                                            <span>Featured story</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Allow Comments?</label>
                                        <div class="checkbox-group">
                                            <input type="checkbox" name="allow_comments" ${story?.allow_comments !== false ? 'checked' : ''}>
                                            <span>Enable comments</span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Downloadable?</label>
                                        <div class="checkbox-group">
                                            <input type="checkbox" name="downloadable" ${story?.downloadable ? 'checked' : ''}>
                                            <span>Allow PDF/TXT download</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Tags (comma separated)</label>
                                    <input type="text" name="tags" class="form-control" value="${(story?.tags || []).join(', ')}">
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-outline" onclick="Modal.hide('${modalId}')">Cancel</button>
                            <button class="btn btn-primary" onclick="AdminStories.saveStory('${story?.id || ''}')">
                                <i class="fas fa-save"></i> ${isEdit ? 'Update' : 'Create'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Create modal if doesn't exist, or replace existing
        const existingModal = document.getElementById(modalId);
        if (existingModal) {
            existingModal.remove();
        }

        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = modalHTML;
        const modalElement = tempDiv.firstElementChild;
        if (!modalElement) {
            Toast.error('Failed to create modal');
            return;
        }
        document.body.appendChild(modalElement);

        // Bind events for this modal
        this.bindModalEvents(modalId, isEdit);

        // Show the modal (this was missing - causing the button to do nothing)
        Modal.show(modalId);
    },

    bindModalEvents(modalId, isEdit) {
        const modal = document.getElementById(modalId);
        if (!modal) return;

        // Close on overlay click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) Modal.hide(modalId);
        });

        // Close on escape
        const escapeHandler = (e) => {
            if (e.key === 'Escape') Modal.hide(modalId);
        };
        document.addEventListener('keydown', escapeHandler);

        // File upload preview
        const fileInput = modal.querySelector('input[type="file"]');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                        const preview = fileInput.nextElementSibling.nextElementSibling;
                        const img = preview.querySelector('img');
                        img.src = evt.target.result;
                        preview.style.display = 'block';
                    };
                    reader.readAsDataURL(file);
                }
            });
        }

        // Word count on content change
        const contentInput = modal.querySelector('textarea[name="content"]');
        if (contentInput) {
            const updateWordCount = () => {
                const count = Stories.countWords(contentInput.value);
                const wordCountField = modal.querySelector('input[name="word_count"]');
                if (wordCountField) {
                    wordCountField.value = count;
                }
            };
            contentInput.addEventListener('input', updateWordCount);
        }

        // Save escape key
        const saveBtn = modal.querySelector('.modal-footer .btn-primary');
        if (saveBtn) {
            saveBtn.addEventListener('keydown', escapeHandler);
        }
    },

    async saveStory(storyId) {
        const modal = document.getElementById(storyId ? 'editStoryModal' : 'addStoryModal');
        if (!modal) return;

        const form = modal.querySelector('form');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const formData = new FormData(form);
        const data = {
            title: formData.get('title'),
            subtitle: formData.get('subtitle'),
            genre: formData.get('genre'),
            age_group: formData.get('age_group'),
            description: formData.get('description'),
            author_name: formData.get('author_name'),
            author_bio: formData.get('author_bio'),
            status: formData.get('status'),
            featured: formData.get('featured') === 'on',
            allow_comments: formData.get('allow_comments') === 'on',
            downloadable: formData.get('downloadable') === 'on',
            word_count: parseInt(formData.get('word_count')) || 0,
            read_time_minutes: parseInt(formData.get('read_time_minutes')) || 1,
            tags: formData.get('tags').split(',').map(t => t.trim()).filter(t => t)
        };

        // Handle cover image file
        const coverFileInput = form.querySelector('input[name="cover_image_file"]');
        if (coverFileInput && coverFileInput.files[0]) {
            try {
                data.cover_image = await Stories.fileToBase64(coverFileInput.files[0]);
            } catch (error) {
                Toast && Toast.error('Failed to process image');
                return;
            }
        } else if (storyId) {
            // Keep existing cover
            const existingStory = Stories.getStory(storyId);
            data.cover_image = existingStory.cover_image;
        }

        // Content
        const contentInput = form.querySelector('textarea[name="content"]');
        data.content = contentInput.value;
        data.content_type = 'html';

        if (storyId) {
            // Update existing
            const result = Stories.updateStory(storyId, data);
            if (result.success) {
                Toast && Toast.success('Story updated successfully');
                Modal.hide('editStoryModal');
                this.loadStoriesList();
            } else {
                Toast && Toast.error(result.error || 'Failed to update story');
            }
        } else {
            // Create new
            data.status = data.status || 'draft';
            const story = Stories.createStory(data);
            if (story) {
                Toast && Toast.success('Story created successfully');
                Modal.hide('addStoryModal');
                this.loadStoriesList();
            } else {
                Toast && Toast.error('Failed to create story');
            }
        }
    },

    viewStory(storyId) {
        const story = Stories.getStory(storyId);
        if (!story) return;
        window.open(`../story.html?story=${story.slug}`, '_blank');
    },

    async approveStory(storyId) {
        if (!confirm('Publish this story?')) return;

        const result = Stories.updateStory(storyId, { status: 'published' });
        if (result.success) {
            Toast && Toast.success('Story published!');
            this.loadStoriesList();
        } else {
            Toast && Toast.error('Failed to publish story');
        }
    },

    async deleteStory(storyId) {
        if (!confirm('Delete this story permanently? This cannot be undone.')) return;

        const result = Stories.deleteStory(storyId);
        if (result.success) {
            Toast && Toast.success('Story deleted');
            this.loadStoriesList();
        } else {
            Toast && Toast.error(result.error);
        }
    },

    // Submissions Management
    loadSubmissionsList() {
        const submissions = Stories.getSubmissions();
        const statusFilter = document.getElementById('submissionsStatusFilter')?.value;

        let filtered = submissions;
        if (statusFilter) {
            filtered = submissions.filter(s => s.status === statusFilter);
        } else {
            filtered = submissions.filter(s => s.status === 'pending_review');
        }

        // Sort by date desc
        filtered.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        this.renderSubmissionsTable(filtered);
        this.updatePendingBadge();
    },

    renderSubmissionsTable(submissions) {
        const tbody = document.getElementById('submissionsTableBody');
        if (!tbody) return;

        if (submissions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 2rem;">No submissions found</td></tr>';
            return;
        }

        tbody.innerHTML = submissions.map(sub => {
            const statusColors = {
                pending_review: 'warning',
                approved: 'success',
                rejected: 'danger',
                needs_revision: 'info'
            };
            const statusClass = statusColors[sub.status] || 'secondary';
            const date = new Date(sub.created_at).toLocaleDateString();

            return `
                <tr>
                    <td>${sub.id}</td>
                    <td>${this.escapeHtml(sub.submission.title)}</td>
                    <td>${this.escapeHtml(sub.submitter_name)}</td>
                    <td>${this.escapeHtml(sub.submission.genre)}</td>
                    <td>${date}</td>
                    <td><span class="badge bg-${statusClass}">${sub.status.replace('_', ' ')}</span></td>
                    <td>
                        <button class="btn btn-sm btn-outline" onclick="AdminStories.viewSubmission('${sub.id}')" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${sub.status === 'pending_review' ? `
                            <button class="btn btn-sm btn-success" onclick="AdminStories.approveSubmission('${sub.id}')" title="Approve">
                                <i class="fas fa-check"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="AdminStories.rejectSubmission('${sub.id}')" title="Reject">
                                <i class="fas fa-times"></i>
                            </button>
                        ` : ''}
                    </td>
                </tr>
            `;
        }).join('');
    },

    updatePendingBadge() {
        const pending = Stories.getSubmissions('pending_review').length;
        const badge = document.getElementById('pendingSubmissionsBadge');
        if (badge) {
            badge.textContent = pending;
            badge.style.display = pending > 0 ? 'inline' : 'none';
        }
    },

    viewSubmission(submissionId) {
        const submissions = Stories.getSubmissions();
        const sub = submissions.find(s => s.id === submissionId);
        if (!sub) return;

        const modalHTML = `
            <div class="modal-overlay" id="viewSubmissionModal">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3>Submission: ${this.escapeHtml(sub.submission.title)}</h3>
                            <button class="modal-close" onclick="Modal.hide('viewSubmissionModal')">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="form-row">
                                <div><strong>ID:</strong> ${sub.id}</div>
                                <div><strong>Submitted:</strong> ${new Date(sub.created_at).toLocaleDateString()}</div>
                            </div>
                            <hr>
                            <h4>Story Details</h4>
                            <p><strong>Title:</strong> ${this.escapeHtml(sub.submission.title)}</p>
                            ${sub.submission.subtitle ? `<p><strong>Subtitle:</strong> ${this.escapeHtml(sub.submission.subtitle)}</p>` : ''}
                            <p><strong>Author:</strong> ${this.escapeHtml(sub.submission.author_name)}</p>
                            <p><strong>Genre:</strong> ${this.escapeHtml(sub.submission.genre)}</p>
                            <p><strong>Age Group:</strong> ${sub.submission.age_group}</p>
                            <p><strong>Word Count:</strong> ${sub.submission.word_count}</p>
                            <p><strong>Description:</strong> ${this.escapeHtml(sub.submission.description)}</p>
                            ${sub.submission.author_bio ? `<p><strong>Author Bio:</strong> ${this.escapeHtml(sub.submission.author_bio)}</p>` : ''}
                            <h5 style="margin-top: 1.5rem;">Content Preview (first 2000 chars)</h5>
                            <div style="background: var(--gray-100); padding: 1rem; border-radius: 8px; max-height: 300px; overflow-y: auto; font-family: Georgia, serif;">
                                ${this.escapeHtml(sub.submission.content.substring(0, 2000))}${sub.submission.content.length > 2000 ? '<p><em>... truncated</em></p>' : ''}
                            </div>
                            ${sub.reviewer_notes ? `<p><strong>Reviewer Notes:</strong> ${this.escapeHtml(sub.reviewer_notes)}</p>` : ''}
                        </div>
                        <div class="modal-footer">
                            ${sub.status === 'pending_review' ? `
                                <button class="btn btn-danger" onclick="AdminStories.rejectSubmission('${sub.id}'); Modal.hide('viewSubmissionModal');">
                                    <i class="fas fa-times"></i> Reject
                                </button>
                                <button class="btn btn-success" onclick="AdminStories.approveSubmission('${sub.id}'); Modal.hide('viewSubmissionModal');">
                                    <i class="fas fa-check"></i> Approve & Publish
                                </button>
                            ` : ''}
                            <button class="btn btn-outline" onclick="Modal.hide('viewSubmissionModal')">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        const existing = document.getElementById('viewSubmissionModal');
        if (existing) existing.remove();

        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = modalHTML;
        const modalElement = tempDiv.firstElementChild;
        if (!modalElement) {
            Toast.error('Failed to create modal');
            return;
        }
        document.body.appendChild(modalElement);

        // Show the modal
        Modal.show('viewSubmissionModal');
    },

    approveSubmission(submissionId) {
        if (!confirm('Approve this submission and create story?')) return;

        const result = Stories.reviewSubmission(submissionId, 'approved', 'admin', '');
        if (result.success) {
            Toast && Toast.success('Submission approved! Story created.');
            this.loadSubmissionsList();
            this.loadStoriesList(); // Refresh stories list too
        } else {
            Toast && Toast.error(result.error || 'Failed to approve submission');
        }
    },

    rejectSubmission(submissionId) {
        const reason = prompt('Reason for rejection (optional):');
        const result = Stories.reviewSubmission(submissionId, 'rejected', 'admin', reason || '');
        if (result.success) {
            Toast && Toast.success('Submission rejected');
            this.loadSubmissionsList();
        } else {
            Toast && Toast.error(result.error || 'Failed to reject submission');
        }
    },

    openReviewModal() {
        this.switchTab('submissions');
    },

    filterSubmissions() {
        this.loadSubmissionsList();
    },

    // Utilities
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text || '';
        return div.innerHTML;
    }
};

// Auto-init when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => AdminStories.init());
} else {
    AdminStories.init();
}

// Make globally available
window.AdminStories = AdminStories;

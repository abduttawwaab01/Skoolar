const Calculator = {
    isOpen: false,
    isMinimized: false,
    mode: 'basic',
    isDragging: false,
    dragOffset: { x: 0, y: 0 },
    position: { x: null, y: null },

    init() {
        this.createModal();
        this.loadPosition();
        this.setupKeyboardSupport();
    },

    createModal() {
        if (document.getElementById('calculatorModal')) return;

        const html = `
            <div id="calculatorModal" class="calculator-modal" style="display: none; position: fixed; z-index: 10000; left: auto; top: auto; bottom: 20px; right: 20px;">
                <div class="calculator-container" id="calcContainer">
                    <div class="calculator-header" id="calcHeader">
                        <span class="calculator-title"><i class="fas fa-calculator"></i> Skoolar Calc</span>
                        <div class="calculator-controls">
                            <button class="calc-control-btn" onclick="Calculator.toggleMinimize()" title="Minimize/Maximize">
                                <i class="fas fa-minus" id="calcMinimizeIcon"></i>
                            </button>
                            <button class="calc-control-btn" onclick="Calculator.toggleMode()" title="Toggle Basic/Scientific">
                                <span id="calcModeLabel">Basic</span>
                            </button>
                            <button class="calc-control-btn calc-close" onclick="Calculator.close()" title="Close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div id="calcBody">
                        <div class="calculator-display">
                            <input type="text" id="calcDisplay" class="calc-display-input" placeholder="0" spellcheck="false">
                        </div>
                        <div class="calculator-buttons" id="calcButtons">
                        </div>
                    </div>
                </div>
            </div>
        `;

        const div = document.createElement('div');
        div.innerHTML = html;
        document.body.appendChild(div);
        this.renderButtons();
        this.setupDrag();
    },

    setupDrag() {
        const header = document.getElementById('calcHeader');
        const modal = document.getElementById('calculatorModal');
        if (!header || !modal) return;

        let active = false;
        let currentX;
        let currentY;
        let initialX;
        let initialY;
        let xOffset = 0;
        let yOffset = 0;

        // Initialize offset if position exists
        const savedPos = JSON.parse(localStorage.getItem('calculatorPosition') || '{}');
        if (savedPos.left && savedPos.top) {
            // We'll set these directly in loadPosition instead of relative offsets
        }

        const dragStart = (e) => {
            if (e.target.closest('.calculator-controls')) return;

            if (e.type === "touchstart") {
                initialX = e.touches[0].clientX - xOffset;
                initialY = e.touches[0].clientY - yOffset;
            } else {
                initialX = e.clientX - xOffset;
                initialY = e.clientY - yOffset;
            }

            if (e.target === header || header.contains(e.target)) {
                active = true;
                modal.classList.add('dragging');
            }
        };

        const dragEnd = () => {
            initialX = currentX;
            initialY = currentY;
            active = false;
            modal.classList.remove('dragging');
            this.savePosition();
        };

        const drag = (e) => {
            if (!active) return;
            e.preventDefault();

            if (e.type === "touchmove") {
                currentX = e.touches[0].clientX - initialX;
                currentY = e.touches[0].clientY - initialY;
            } else {
                currentX = e.clientX - initialX;
                currentY = e.clientY - initialY;
            }

            xOffset = currentX;
            yOffset = currentY;

            setTranslate(currentX, currentY, modal);
        };

        function setTranslate(xPos, yPos, el) {
            // Constrain to viewport
            const rect = el.getBoundingClientRect();
            const maxX = window.innerWidth - rect.width;
            const maxY = window.innerHeight - rect.height;

            // Note: Since we use right/bottom positioning by default, 
            // the transform is relative to that. This gets tricky.
            // Let's force absolute positioning for dragging once it starts.
            if (el.style.right === '20px') {
                const currentRect = el.getBoundingClientRect();
                el.style.right = 'auto';
                el.style.bottom = 'auto';
                el.style.left = currentRect.left + 'px';
                el.style.top = currentRect.top + 'px';
                xOffset = 0;
                yOffset = 0;
                initialX = (e.type === "touchstart" ? e.touches[0].clientX : e.clientX);
                initialY = (e.type === "touchstart" ? e.touches[0].clientY : e.clientY);
                return;
            }

            el.style.transform = `translate3d(${xPos}px, ${yPos}px, 0)`;
        }

        header.addEventListener("mousedown", dragStart, false);
        document.addEventListener("mouseup", dragEnd, false);
        document.addEventListener("mousemove", drag, false);

        header.addEventListener("touchstart", dragStart, false);
        document.addEventListener("touchend", dragEnd, false);
        document.addEventListener("touchmove", drag, false);
    },

    savePosition() {
        const modal = document.getElementById('calculatorModal');
        if (modal) {
            const rect = modal.getBoundingClientRect();
            const pos = {
                left: rect.left + 'px',
                top: rect.top + 'px',
                transform: modal.style.transform
            };
            localStorage.setItem('calculatorPosition', JSON.stringify(pos));
        }
    },

    loadPosition() {
        const modal = document.getElementById('calculatorModal');
        if (!modal) return;

        const pos = JSON.parse(localStorage.getItem('calculatorPosition') || '{}');
        if (pos.left && pos.top) {
            modal.style.left = pos.left;
            modal.style.top = pos.top;
            modal.style.right = 'auto';
            modal.style.bottom = 'auto';
            if (pos.transform) modal.style.transform = pos.transform;
        } else {
            modal.style.right = '20px';
            modal.style.bottom = '20px';
            modal.style.left = 'auto';
            modal.style.top = 'auto';
            modal.style.transform = 'none';
        }
    },

    renderButtons() {
        const container = document.getElementById('calcButtons');
        if (!container) return;

        if (this.mode === 'basic') {
            container.innerHTML = `
                <div class="calc-row">
                    <button class="calc-btn calc-clear" onclick="Calculator.clear()">AC</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.backspace()">⌫</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('%')">%</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('/')">÷</button>
                </div>
                <div class="calc-row">
                    <button class="calc-btn" onclick="Calculator.append('7')">7</button>
                    <button class="calc-btn" onclick="Calculator.append('8')">8</button>
                    <button class="calc-btn" onclick="Calculator.append('9')">9</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('*')">×</button>
                </div>
                <div class="calc-row">
                    <button class="calc-btn" onclick="Calculator.append('4')">4</button>
                    <button class="calc-btn" onclick="Calculator.append('5')">5</button>
                    <button class="calc-btn" onclick="Calculator.append('6')">6</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('-')">−</button>
                </div>
                <div class="calc-row">
                    <button class="calc-btn" onclick="Calculator.append('1')">1</button>
                    <button class="calc-btn" onclick="Calculator.append('2')">2</button>
                    <button class="calc-btn" onclick="Calculator.append('3')">3</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('+')">+</button>
                </div>
                <div class="calc-row">
                    <button class="calc-btn calc-zero" onclick="Calculator.append('0')">0</button>
                    <button class="calc-btn" onclick="Calculator.append('.')">.</button>
                    <button class="calc-btn calc-equals" onclick="Calculator.calculate()">=</button>
                </div>
            `;
        } else {
            container.innerHTML = `
                <div class="calc-row sci-row">
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.sin(')">sin</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.cos(')">cos</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.tan(')">tan</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.PI')">π</button>
                </div>
                <div class="calc-row sci-row">
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.sqrt(')">√</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.log10(')">log</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.log(')">ln</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.E')">e</button>
                </div>
                <div class="calc-row sci-row">
                    <button class="calc-btn calc-sci" onclick="Calculator.append('**2')">x²</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append('**')">xʸ</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append('(')">(</button>
                    <button class="calc-btn calc-sci" onclick="Calculator.append(')')">)</button>
                </div>
                <div class="calc-row">
                    <button class="calc-btn calc-clear" onclick="Calculator.clear()">AC</button>
                    <button class="calc-btn" onclick="Calculator.append('7')">7</button>
                    <button class="calc-btn" onclick="Calculator.append('8')">8</button>
                    <button class="calc-btn" onclick="Calculator.append('9')">9</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('/')">÷</button>
                </div>
                <div class="calc-row">
                    <button class="calc-btn calc-sci" onclick="Calculator.factorial()" title="Factorial">n!</button>
                    <button class="calc-btn" onclick="Calculator.append('4')">4</button>
                    <button class="calc-btn" onclick="Calculator.append('5')">5</button>
                    <button class="calc-btn" onclick="Calculator.append('6')">6</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('*')">×</button>
                </div>
                <div class="calc-row">
                    <button class="calc-btn calc-sci" onclick="Calculator.append('Math.abs(')" title="Absolute">|x|</button>
                    <button class="calc-btn" onclick="Calculator.append('1')">1</button>
                    <button class="calc-btn" onclick="Calculator.append('2')">2</button>
                    <button class="calc-btn" onclick="Calculator.append('3')">3</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('-')">−</button>
                </div>
                <div class="calc-row">
                    <button class="calc-btn calc-operator" onclick="Calculator.backspace()">⌫</button>
                    <button class="calc-btn" onclick="Calculator.append('0')">0</button>
                    <button class="calc-btn" onclick="Calculator.append('.')">.</button>
                    <button class="calc-btn calc-equals" onclick="Calculator.calculate()">=</button>
                    <button class="calc-btn calc-operator" onclick="Calculator.append('+')">+</button>
                </div>
            `;
        }
    },

    toggleMode() {
        this.mode = this.mode === 'basic' ? 'scientific' : 'basic';
        document.getElementById('calcModeLabel').textContent = this.mode === 'basic' ? 'Basic' : 'Scientific';
        this.renderButtons();
        // Update container width for sci mode
        const container = document.getElementById('calcContainer');
        if (container) {
            container.style.width = this.mode === 'basic' ? '320px' : '400px';
        }
    },

    toggleMinimize() {
        this.isMinimized = !this.isMinimized;
        const body = document.getElementById('calcBody');
        const icon = document.getElementById('calcMinimizeIcon');
        if (body) body.style.display = this.isMinimized ? 'none' : 'block';
        if (icon) icon.className = this.isMinimized ? 'fas fa-expand' : 'fas fa-minus';
    },

    open() {
        const modal = document.getElementById('calculatorModal');
        if (modal) {
            modal.style.display = 'block';
            this.isOpen = true;
            this.loadPosition();
            document.getElementById('calcDisplay').focus();
        }
    },

    close() {
        const modal = document.getElementById('calculatorModal');
        if (modal) {
            modal.style.display = 'none';
            this.isOpen = false;
        }
    },

    append(value) {
        const display = document.getElementById('calcDisplay');
        if (!display) return;

        // Smart append for Math functions
        if (value.startsWith('Math.')) {
            display.value += value;
        } else {
            display.value += value;
        }
        display.focus();
    },

    clear() {
        const display = document.getElementById('calcDisplay');
        if (display) display.value = '';
    },

    backspace() {
        const display = document.getElementById('calcDisplay');
        if (display) display.value = display.value.slice(0, -1);
    },

    factorial() {
        const display = document.getElementById('calcDisplay');
        if (!display) return;
        try {
            const val = parseInt(eval(display.value));
            if (val < 0) throw new Error();
            let res = 1;
            for (let i = 2; i <= val; i++) res *= i;
            display.value = res;
        } catch (e) {
            display.value = 'Error';
        }
    },

    calculate() {
        const display = document.getElementById('calcDisplay');
        if (!display || !display.value) return;

        try {
            let expr = display.value;
            // Clean expression
            expr = expr.replace(/×/g, '*').replace(/−/g, '-').replace(/÷/g, '/');

            // Auto-close missing brackets for Math functions
            const openBrackets = (expr.match(/\(/g) || []).length;
            const closeBrackets = (expr.match(/\)/g) || []).length;
            if (openBrackets > closeBrackets) {
                expr += ')'.repeat(openBrackets - closeBrackets);
            }

            const result = eval(expr);
            display.value = Number.isFinite(result) ?
                (Math.round(result * 10000000) / 10000000).toString() :
                'Error';
        } catch (e) {
            console.error('Calc Error:', e);
            display.value = 'Error';
        }
        display.focus();
    },

    toggle() {
        if (this.isOpen) this.close();
        else this.open();
    },

    setupKeyboardSupport() {
        document.addEventListener('keydown', (e) => {
            if (!this.isOpen) return;

            if (e.key >= '0' && e.key <= '9') this.append(e.key);
            else if (e.key === '.') this.append('.');
            else if (e.key === '+') this.append('+');
            else if (e.key === '-') this.append('-');
            else if (e.key === '*') this.append('*');
            else if (e.key === '/') {
                e.preventDefault();
                this.append('/');
            }
            else if (e.key === 'Enter') {
                e.preventDefault();
                this.calculate();
            }
            else if (e.key === 'Backspace') this.backspace();
            else if (e.key === 'Escape') this.close();
            else if (e.key === '(') this.append('(');
            else if (e.key === ')') this.append(')');
        });
    }
};

window.Calculator = Calculator;

// Initialize when library loaded or via Student portal
if (typeof App !== 'undefined' && App.init) {
    // Already handled by Student portal in line 1203
}

// data-optimizer.js
// This file helps you store data more efficiently

const DataOptimizer = {
    // Convert status strings to numbers (saves tons of space!)
    attendanceStatus: {
        'present': 1,
        'absent': 0,
        'late': 2
    },
    
    // Convert term strings to numbers
    termToNumber: {
        'First Term': 1,
        'Second Term': 2, 
        'Third Term': 3
    },
    
    // Convert number back to term
    numberToTerm(termNum) {
        const terms = ['First Term', 'Second Term', 'Third Term'];
        return terms[termNum - 1] || 'First Term';
    },
    
    // Compress a student record before saving (preserves all data, adds optimization markers)
    compressStudent(student) {
        // Return the student as-is but add optimization markers
        // This preserves ALL original data including username, password, passportUrl, etc.
        return {
            ...student,
            _optimized: true,
            _version: '1.0'
        };
    },
    
    // Expand back for display (since we're preserving all data, this is now just a passthrough)
    expandStudent(compressed) {
        // Return as-is since we preserved all data
        return {
            ...compressed
        };
    },
    
    // Compress attendance record
    compressAttendance(attendance) {
        // Remove the 'T' from date (2026-02-28 instead of 2026-02-28T...)
        const date = attendance.date.split('T')[0];
        
        return {
            s: attendance.studentId.slice(-8),  // Last 8 chars of student ID
            d: date.replace(/-/g, ''),           // 20260228 format (8 chars)
            t: this.attendanceStatus[attendance.status] || 0
        };
    },
    
    // Compress score record
    compressScore(score) {
        return {
            s: score.studentId.slice(-8),
            sub: this.getSubjectCode(score.subject),  // Convert subject to number
            t: this.termToNumber[score.term] || 1,
            y: score.year,
            sc: Math.round(score.score * 100),        // Store as integer (85.5 -> 8550)
            tp: this.getScoreTypeCode(score.type)      // Convert type to number
        };
    },
    
    // Simple subject to number mapping (you'll need to maintain this per school)
    getSubjectCode(subject) {
        // You can store these codes per school
        const subjectCodes = {
            'Mathematics': 1,
            'English': 2,
            'Basic Science': 3,
            // Add more as needed
        };
        return subjectCodes[subject] || 99;
    },
    
    getScoreTypeCode(type) {
        const typeCodes = {
            'Daily': 1,
            'Weekly': 2,
            'Mid-term': 3,
            'Exam': 4
        };
        return typeCodes[type] || 1;
    }
};

// Expose to window
window.DataOptimizer = DataOptimizer;
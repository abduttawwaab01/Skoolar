// Service Worker for Skoolar PWA
// Caches static assets and provides offline fallback
// Version 2: fixed redirect handling, clean URL support

const CACHE_NAME = 'skoolar-cache-v2';
const STATIC_CACHE = 'skoolar-static-v2';
const DYNAMIC_CACHE = 'skoolar-dynamic-v2';

// Assets to cache immediately on install (static assets)
const STATIC_ASSETS = [
    // Pages - include both .html and extensionless versions
    '/',
    '/index.html',
    '/login',
    '/login.html',
    '/student-login',
    '/student-login.html',
    '/parent-login',
    '/parent-login.html',
    '/register-school',
    '/register-school.html',
    '/reset-password',
    '/reset-password.html',
    '/offline.html',
    '/manifest.json',
    '/assets/css/style.css',
    '/assets/js/supabase-config.js',
    '/assets/js/supabase-auth.js',
    '/assets/js/supabase-sync.js',
    '/assets/js/storage.js',
    '/assets/js/auth.js',
    '/assets/js/core.js',
    '/assets/js/cache-manager.js',
    // Icons when they exist
    '/assets/icons/icon-192x192.png',
    '/assets/icons/icon-512x512.png'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
    console.log('[Service Worker] Installing...');
    event.waitUntil(
        caches.open(STATIC_CACHE)
            .then((cache) => {
                console.log('[Service Worker] Pre-caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => {
                console.log('[Service Worker] Install complete');
                return self.skipWaiting();
            })
            .catch((error) => {
                console.error('[Service Worker] Install failed:', error);
            })
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
    console.log('[Service Worker] Activating...');
    event.waitUntil(
        caches.keys()
            .then((cacheNames) => {
                return Promise.all(
                    cacheNames.map((cacheName) => {
                        if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
                            console.log('[Service Worker] Deleting old cache:', cacheName);
                            return caches.delete(cacheName);
                        }
                    })
                );
            })
            .then(() => {
                console.log('[Service Worker] Activation complete');
                return self.clients.claim();
            })
            .catch((error) => {
                console.error('[Service Worker] Activation failed:', error);
            })
    );
});

// Fetch event - serve from cache, fallback to network, then offline page
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    // Skip non-GET requests
    if (request.method !== 'GET') {
        return;
    }

    // Skip chrome-extension, data URLs etc
    if (!url.protocol.startsWith('http')) {
        return;
    }

    // Determine caching strategy based on request type
    if (isStaticAsset(request)) {
        // Local static assets (CSS, JS, icons) - cache first, no offline fallback needed
        event.respondWith(cacheFirst(request));
    } else if (isPage(request)) {
        // HTML pages - network first for fresh content, fallback to offline.html
        event.respondWith(networkFirst(request, '/offline.html'));
    } else if (isSupabaseRequest(url)) {
        // For Supabase API calls, try network first, no offline fallback (must be online)
        event.respondWith(networkFirst(request));
    } else {
        // Other external resources - network first, fallback to offline.html
        event.respondWith(networkFirst(request, '/offline.html'));
    }
});

// Cache-first strategy for static assets (CSS, JS, images, fonts)
async function cacheFirst(request) {
    const cache = await caches.open(STATIC_CACHE);
    const cached = await cache.match(request);

    if (cached) {
        // Skip cached redirects (3xx responses)
        if (cached.status >= 300 && cached.status < 400) {
            console.log('[SW] Skipped cached redirect for', request.url);
        } else {
            return cached;
        }
    }

    try {
        const networkResponse = await fetch(request);
        // Only cache successful responses (200-299), not redirects or errors
        if (networkResponse.ok && isCacheable(request)) {
            cache.put(request, networkResponse.clone());
        }
        return networkResponse;
    } catch (error) {
        return new Response('Offline - content not available', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: { 'Content-Type': 'text/plain' }
        });
    }
}

// Network-first strategy with cache fallback
async function networkFirst(request, offlineFallback = null) {
    try {
        const networkResponse = await fetch(request);
        // Only cache successful responses (200-299), never cache redirects (3xx) or errors (4xx/5xx)
        if (networkResponse.ok && isCacheable(request)) {
            const cache = await caches.open(DYNAMIC_CACHE);
            cache.put(request, networkResponse.clone());
        }
        return networkResponse;
    } catch (error) {
        console.log('[Service Worker] Network failed, trying cache:', error);
        const cache = await caches.open(DYNAMIC_CACHE);
        const cached = await cache.match(request);
        if (cached) {
            // Skip cached redirects
            if (cached.status >= 300 && cached.status < 400) {
                // Continue to offline fallback
            } else {
                return cached;
            }
        }
        if (offlineFallback) {
            const staticCache = await caches.open(STATIC_CACHE);
            const fallback = await staticCache.match(offlineFallback);
            if (fallback) return fallback;
        }
        return new Response('Offline - no cached version available', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: { 'Content-Type': 'text/plain' }
        });
    }
}

// Determine if a request is for a static asset (CSS, JS, images, fonts)
function isStaticAsset(request) {
    const url = new URL(request.url);
    return url.pathname.match(/\.(css|js|png|jpg|jpeg|gif|svg|webp|ico|woff|woff2|ttf|eot)$/) !== null;
}

// Determine if a request is for a page (HTML)
function isPage(request) {
    const url = new URL(request.url);
    return url.pathname.endsWith('.html') || url.pathname === '/' || !url.pathname.includes('.');
}

// Determine if a request should be cached (not API calls or external resources)
function isCacheable(request) {
    const url = new URL(request.url);
    // Don't cache Supabase API responses (they change frequently)
    // Don't cache external CDN resources (they have their own caching)
    return !isSupabaseRequest(url) && !url.hostname.includes('cdn') && !url.hostname.includes('google');
}

// Check if request is to Supabase
function isSupabaseRequest(url) {
    return url.hostname.includes('supabase') || url.hostname.includes('amccnstthagjzdidshpw');
}

// Background sync for offline actions (optional enhancement)
self.addEventListener('sync', (event) => {
    console.log('[Service Worker] Background sync:', event.tag);
    if (event.tag === 'sync-data') {
        event.waitUntil(
            syncOfflineData()
        );
    }
});

// Sync offline data when back online
async function syncOfflineData() {
    // This would sync any queued offline actions to Supabase
    console.log('[Service Worker] Syncing offline data...');
    // Implementation depends on specific offline queue
    return true;
}

// Push notification handling (for future use)
self.addEventListener('push', (event) => {
    console.log('[Service Worker] Push received:', event);
    // Implement push notifications later if needed
});

console.log('[Service Worker] Service Worker loaded');

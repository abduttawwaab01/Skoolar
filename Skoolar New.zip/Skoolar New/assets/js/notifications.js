const NotificationSystem = {
    currentPage: 1,
    currentFilter: 'all',
    itemsPerPage: 20,

    init() {
        this.updateUnreadCount();
    },

    loadNotifications(page = 1, filter = 'all') {
        this.currentPage = page;
        this.currentFilter = filter;
        
        const user = this.getCurrentUser();
        if (!user) return;
        
        const userId = user.id;
        let notifications = Storage.getData('notifications')?.filter(n => n.userId === userId) || [];
        
        if (filter === 'unread') {
            notifications = notifications.filter(n => !n.read);
        } else if (filter === 'read') {
            notifications = notifications.filter(n => n.read);
        }
        
        notifications.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        
        const totalItems = notifications.length;
        const totalPages = Math.ceil(totalItems / this.itemsPerPage);
        const start = (page - 1) * this.itemsPerPage;
        const paginated = notifications.slice(start, start + this.itemsPerPage);
        
        this.renderNotifications(paginated);
        this.renderPagination(totalItems, totalPages, page);
        this.updateCounts(userId);
        this.updateUnreadCount();
    },

    getCurrentUser() {
        if (typeof Auth !== 'undefined' && Auth.getSession) {
            const session = Auth.getSession();
            return session?.user;
        }
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentStudent) {
            return StudentAuth.getCurrentStudent();
        }
        if (typeof ParentDashboard !== 'undefined' && ParentDashboard.getCurrentParent) {
            return ParentDashboard.getCurrentParent();
        }
        return null;
    },

    renderNotifications(notifications) {
        const container = document.getElementById('notificationListContainer');
        if (!container) return;
        
        if (notifications.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-bell-slash"></i>
                    <p>No notifications</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        notifications.forEach(notif => {
            const iconClass = this.getIconForType(notif.type);
            const time = this.formatTime(notif.createdAt);
            html += `
                <div class="notification-item ${notif.read ? '' : 'unread'}" data-id="${notif.id}">
                    <div class="notification-item-icon ${notif.type || 'info'}">
                        <i class="fas ${iconClass}"></i>
                    </div>
                    <div class="notification-item-content">
                        <p class="notification-message">${notif.message || notif.description || ''}</p>
                        <span class="notification-time">${time}</span>
                    </div>
                    <div class="notification-item-actions">
                        ${notif.read ? '' : `<button class="btn-icon" onclick="NotificationSystem.markAsRead('${notif.id}')" title="Mark as read"><i class="fas fa-check"></i></button>`}
                        <button class="btn-icon" onclick="NotificationSystem.deleteNotification('${notif.id}')" title="Delete"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    },

    renderPagination(totalItems, totalPages, currentPage) {
        const container = document.getElementById('notificationPagination');
        if (!container) return;
        
        if (totalPages <= 1) {
            container.innerHTML = '';
            return;
        }
        
        let html = `<span class="pagination-info">Showing ${((currentPage - 1) * this.itemsPerPage) + 1}-${Math.min(currentPage * this.itemsPerPage, totalItems)} of ${totalItems}</span>`;
        html += '<div class="pagination-buttons">';
        
        if (currentPage > 1) {
            html += `<button class="btn btn-sm" onclick="NotificationSystem.loadNotifications(${currentPage - 1}, '${this.currentFilter}')"><i class="fas fa-chevron-left"></i> Previous</button>`;
        }
        
        for (let i = Math.max(1, currentPage - 2); i <= Math.min(totalPages, currentPage + 2); i++) {
            html += `<button class="btn btn-sm ${i === currentPage ? 'active' : ''}" onclick="NotificationSystem.loadNotifications(${i}, '${this.currentFilter}')">${i}</button>`;
        }
        
        if (currentPage < totalPages) {
            html += `<button class="btn btn-sm" onclick="NotificationSystem.loadNotifications(${currentPage + 1}, '${this.currentFilter}')">Next <i class="fas fa-chevron-right"></i></button>`;
        }
        
        html += '</div>';
        container.innerHTML = html;
    },

    updateCounts(userId) {
        const notifications = Storage.getData('notifications')?.filter(n => n.userId === userId) || [];
        const total = notifications.length;
        const unread = notifications.filter(n => !n.read).length;
        
        const totalEl = document.getElementById('notificationTotalCount');
        const unreadEl = document.getElementById('notificationUnreadCount');
        
        if (totalEl) totalEl.textContent = total;
        if (unreadEl) unreadEl.textContent = unread;
        
        const filterBtns = document.querySelectorAll('.notification-filter-btn');
        filterBtns.forEach(btn => {
            const filter = btn.dataset.filter;
            btn.classList.remove('active');
            if (filter === this.currentFilter) btn.classList.add('active');
        });
    },

    markAsRead(notificationId) {
        const notifications = Storage.getData('notifications') || [];
        const index = notifications.findIndex(n => n.id === notificationId);
        if (index !== -1) {
            notifications[index].read = true;
            Storage.setData('notifications', notifications);
            this.loadNotifications(this.currentPage, this.currentFilter);
            this.updateUnreadCount();
        }
    },

    markAllRead() {
        const user = this.getCurrentUser();
        if (!user) return;
        
        const notifications = Storage.getData('notifications') || [];
        notifications.forEach(n => {
            if (n.userId === user.id) n.read = true;
        });
        Storage.setData('notifications', notifications);
        this.loadNotifications(1, this.currentFilter);
        this.updateUnreadCount();
        
        if (typeof Toast !== 'undefined') {
            Toast.success('All notifications marked as read');
        }
    },

    deleteNotification(notificationId) {
        let notifications = Storage.getData('notifications') || [];
        notifications = notifications.filter(n => n.id !== notificationId);
        Storage.setData('notifications', notifications);
        this.loadNotifications(this.currentPage, this.currentFilter);
        this.updateUnreadCount();
        
        if (typeof Toast !== 'undefined') {
            Toast.success('Notification deleted');
        }
    },

    updateUnreadCount() {
        const user = this.getCurrentUser();
        if (!user) return;
        
        const notifications = Storage.getData('notifications') || [];
        const unread = notifications.filter(n => n.userId === user.id && !n.read).length;
        
        const dot = document.getElementById('notificationDot');
        if (dot) dot.style.display = unread > 0 ? 'block' : 'none';
        
        const badge = document.querySelector('.nav-badge');
        if (badge) {
            badge.textContent = unread > 99 ? '99+' : unread;
            badge.style.display = unread > 0 ? 'flex' : 'none';
        }
    },

    getIconForType(type) {
        const icons = {
            'info': 'fa-info-circle',
            'success': 'fa-check-circle',
            'warning': 'fa-exclamation-triangle',
            'error': 'fa-times-circle',
            'student': 'fa-user-graduate',
            'score': 'fa-star',
            'finance': 'fa-wallet',
            'message': 'fa-envelope',
            'attendance': 'fa-clipboard-check',
            'announcement': 'fa-bullhorn'
        };
        return icons[type] || 'fa-bell';
    },

    formatTime(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
        if (diff < 604800000) return `${Math.floor(diff / 86400000)} days ago`;
        
        return date.toLocaleDateString();
    },

    setFilter(filter) {
        this.loadNotifications(1, filter);
    }
};

if (typeof Storage !== 'undefined' && !Storage.getData('notifications')) {
    Storage.setData('notifications', []);
}

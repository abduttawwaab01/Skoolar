// data-pruner.js - Complete Version

const DataPruner = {
    // Configuration - Adjust these based on your needs
    config: {
        // How long to keep different types of data (in days)
        retention: {
            attendance: 365 * 2,        // Keep attendance for 2 years
            scores: 365 * 3,             // Keep scores for 3 years
            messages: 180,                // Keep chat messages for 6 months
            studentMessages: 365,         // Keep student messages for 1 year
            finance: 365 * 5,              // Keep financial records for 5 years
            activities: 90,                // Keep activity logs for 3 months
            notifications: 30,              // Keep notifications for 1 month
            testResults: 365 * 2,          // Keep test results for 2 years
            scoreSessions: 365 * 2,        // Keep score sessions for 2 years
            calendarEvents: 30,             // Keep past events for 1 month
            staffAttendance: 365 * 2        // Keep staff attendance for 2 years
        },
        
        // Auto-prune settings
        autoPrune: {
            enabled: true,
            schedule: 'daily',              // 'daily', 'weekly', 'monthly'
            time: '02:00',                  // Run at 2 AM
            notifyBefore: true,              // Show notification before pruning
            dryRun: false                    // Set to true to test without deleting
        },
        
        // Archive settings (instead of delete, move to archive)
        archive: {
            enabled: true,
            archiveAfter: 365 * 2,           // Archive after 2 years
            keepArchived: true                // Keep archived data in separate storage
        }
    },
    
    // Statistics
    stats: {
        lastRun: null,
        recordsDeleted: 0,
        recordsArchived: 0,
        spaceSaved: 0
    },
    
    /**
     * Initialize the pruner
     */
    init() {
        console.log('📊 Data Pruner initialized');
        
        // Load stats from localStorage
        this.loadStats();
        
        // Schedule auto-prune if enabled
        if (this.config.autoPrune.enabled) {
            this.scheduleAutoPrune();
        }
        
        // Show summary on load
        this.showSummary();
    },
    
    /**
     * Load stats from localStorage
     */
    loadStats() {
        const saved = localStorage.getItem('pruner_stats');
        if (saved) {
            try {
                this.stats = JSON.parse(saved);
            } catch (e) {
                console.error('Error loading pruner stats:', e);
            }
        }
    },
    
    /**
     * Save stats to localStorage
     */
    saveStats() {
        localStorage.setItem('pruner_stats', JSON.stringify(this.stats));
    },
    
    /**
     * Show summary of what will be pruned
     */
    showSummary() {
        console.log('📊 Data Pruner Summary:');
        console.log(`- Last run: ${this.stats.lastRun || 'Never'}`);
        console.log(`- Total records deleted: ${this.stats.recordsDeleted}`);
        console.log(`- Total space saved: ${this.formatBytes(this.stats.spaceSaved)}`);
    },
    
    /**
     * Schedule automatic pruning
     */
    scheduleAutoPrune() {
        const now = new Date();
        const [hours, minutes] = this.config.autoPrune.time.split(':').map(Number);
        
        // Calculate next run time
        const nextRun = new Date();
        nextRun.setHours(hours, minutes, 0, 0);
        
        if (nextRun < now) {
            nextRun.setDate(nextRun.getDate() + 1);
        }
        
        const timeUntilNext = nextRun - now;
        console.log(`📅 Next auto-prune scheduled for: ${nextRun.toLocaleString()}`);
        
        setTimeout(() => {
            this.autoPrune();
        }, timeUntilNext);
    },
    
    /**
     * Auto-prune based on schedule
     */
    async autoPrune() {
        console.log('🔄 Running scheduled auto-prune...');
        
        if (this.config.autoPrune.notifyBefore && window.Toast) {
            Toast.info('Auto-prune starting...');
        }
        
        const results = await this.pruneAll();
        
        console.log('✅ Auto-prune complete:', results);
        
        // Schedule next run
        this.scheduleAutoPrune();
    },
    
    /**
     * Prune all data types
     */
    async pruneAll() {
        const results = {
            attendance: 0,
            scores: 0,
            messages: 0,
            studentMessages: 0,
            finance: 0,
            activities: 0,
            notifications: 0,
            testResults: 0,
            scoreSessions: 0,
            calendarEvents: 0,
            staffAttendance: 0,
            totalDeleted: 0,
            spaceSaved: 0
        };
        
        // Calculate cutoff dates
        const now = new Date();
        const cutoffs = {};
        
        for (const [type, days] of Object.entries(this.config.retention)) {
            const cutoff = new Date(now);
            cutoff.setDate(cutoff.getDate() - days);
            cutoffs[type] = cutoff.toISOString();
        }
        
        // Prune each data type
        for (const type of Object.keys(this.config.retention)) {
            try {
                const count = await this.pruneDataType(type, cutoffs[type]);
                results[type] = count;
                results.totalDeleted += count;
            } catch (error) {
                console.error(`Error pruning ${type}:`, error);
            }
        }
        
        // Update stats
        this.stats.lastRun = new Date().toISOString();
        this.stats.recordsDeleted += results.totalDeleted;
        this.stats.spaceSaved += results.spaceSaved;
        this.saveStats();
        
        return results;
    },
    
    /**
     * Prune a specific data type
     */
    async pruneDataType(type, cutoffDate) {
        const storage = Storage || window.Storage;
        if (!storage) return 0;
        
        // Get all data
        const allData = storage.getData(type) || [];
        const beforeCount = allData.length;
        
        if (beforeCount === 0) return 0;
        
        // Filter out old records
        const cutoff = new Date(cutoffDate);
        
        const [keep, delete_these] = this.separateByDate(allData, cutoff, type);
        
        if (delete_these.length === 0) return 0;
        
        // Dry run mode - just count, don't delete
        if (this.config.autoPrune.dryRun) {
            console.log(`[DRY RUN] Would delete ${delete_these.length} old ${type} records`);
            return delete_these.length;
        }
        
        // Archive old records if enabled
        if (this.config.archive.enabled && delete_these.length > 0) {
            await this.archiveRecords(type, delete_these);
            results.archived += delete_these.length;
        }
        
        // Save back the kept records
        storage.setData(type, keep);
        
        // Calculate approximate space saved
        const spaceSaved = this.estimateSpaceSaved(delete_these);
        
        console.log(`✅ Pruned ${delete_these.length} old ${type} records`);
        
        return delete_these.length;
    },
    
    /**
     * Separate records by date
     */
    separateByDate(records, cutoffDate, type) {
        const keep = [];
        const delete_these = [];
        
        records.forEach(record => {
            let recordDate = null;
            
            // Extract date based on record type
            switch (type) {
                case 'attendance':
                    recordDate = new Date(record.date);
                    break;
                case 'scores':
                case 'testResults':
                case 'scoreSessions':
                    recordDate = new Date(record.createdAt || record.date);
                    break;
                case 'messages':
                case 'studentMessages':
                    recordDate = new Date(record.createdAt || record.timestamp);
                    break;
                case 'finance':
                    recordDate = new Date(record.date || record.createdAt);
                    break;
                case 'activities':
                case 'notifications':
                    recordDate = new Date(record.timestamp || record.createdAt);
                    break;
                case 'calendarEvents':
                    recordDate = new Date(record.date);
                    break;
                case 'staffAttendance':
                    recordDate = new Date(record.timestamp || record.date);
                    break;
                default:
                    recordDate = new Date(record.createdAt || record.updatedAt || Date.now());
            }
            
            if (recordDate < cutoffDate) {
                delete_these.push(record);
            } else {
                keep.push(record);
            }
        });
        
        return [keep, delete_these];
    },
    
    /**
     * Archive old records before deletion
     */
    async archiveRecords(type, records) {
        try {
            // Create archive object
            const archive = {
                id: 'archive_' + Date.now(),
                type: type,
                records: records,
                archivedAt: new Date().toISOString(),
                count: records.length
            };
            
            // Try to save to Supabase Storage first
            if (window.isSupabaseEnabled && isSupabaseEnabled()) {
                try {
                    const fileName = `archive_${type}_${Date.now()}.json`;
                    const blob = new Blob([JSON.stringify(records, null, 2)], { type: 'application/json' });
                    
                    const { error } = await supabase.storage
                        .from('archives')
                        .upload(fileName, blob);
                    
                    if (!error) {
                        console.log(`📦 Archived ${records.length} ${type} records to cloud`);
                        return;
                    }
                } catch (e) {
                    console.warn('Cloud archive failed, using local backup:', e);
                }
            }
            
            // Fallback: save to localStorage backup
            const backups = JSON.parse(localStorage.getItem('data_archives') || '[]');
            backups.push(archive);
            
            // Keep only last 10 backups
            if (backups.length > 10) {
                backups.shift();
            }
            
            localStorage.setItem('data_archives', JSON.stringify(backups));
            console.log(`📦 Archived ${records.length} ${type} records locally`);
            
        } catch (error) {
            console.error('Failed to archive records:', error);
        }
    },
    
    /**
     * Estimate space saved (rough approximation)
     */
    estimateSpaceSaved(records) {
        let totalSize = 0;
        
        records.forEach(record => {
            // Rough estimate: each record is about 500 bytes
            totalSize += 500;
            
            // Add extra for images in student records
            if (record.passportUrl && record.passportUrl.startsWith('data:image')) {
                totalSize += record.passportUrl.length * 0.75; // Approximate binary size
            }
        });
        
        return totalSize;
    },
    
    /**
     * Format bytes to human readable
     */
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },
    
    /**
     * Manual prune (can be called from UI)
     */
    async manualPrune(options = {}) {
        const { types = 'all', days = null, confirm = true } = options;
        
        if (confirm) {
            const userConfirm = confirm('⚠️ This will permanently delete old data. Continue?');
            if (!userConfirm) return;
        }
        
        // Temporarily override retention if days specified
        const originalRetention = { ...this.config.retention };
        
        if (days) {
            Object.keys(this.config.retention).forEach(type => {
                this.config.retention[type] = days;
            });
        }
        
        // Run prune
        const results = await this.pruneAll();
        
        // Restore original retention
        if (days) {
            this.config.retention = originalRetention;
        }
        
        return results;
    },
    
    /**
     * Get data size statistics
     */
    getDataStats() {
        const storage = Storage || window.Storage;
        if (!storage) return {};
        
        const stats = {};
        const types = Object.keys(this.config.retention);
        
        types.forEach(type => {
            const data = storage.getData(type) || [];
            stats[type] = {
                count: data.length,
                size: this.estimateSpaceSaved(data)
            };
        });
        
        return stats;
    },
    
    /**
     * Export archive list
     */
    getArchives() {
        return JSON.parse(localStorage.getItem('data_archives') || '[]');
    },
    
    /**
     * Restore from archive
     */
    restoreFromArchive(archiveId) {
        const archives = this.getArchives();
        const archive = archives.find(a => a.id === archiveId);
        
        if (!archive) {
            Toast.error('Archive not found');
            return;
        }
        
        const storage = Storage || window.Storage;
        const current = storage.getData(archive.type) || [];
        const restored = [...current, ...archive.records];
        
        storage.setData(archive.type, restored);
        
        Toast.success(`Restored ${archive.records.length} records from archive`);
        
        // Remove from archives
        const updated = archives.filter(a => a.id !== archiveId);
        localStorage.setItem('data_archives', JSON.stringify(updated));
    }
};

// Initialize on load
DataPruner.init();

// Make globally available
window.DataPruner = DataPruner;
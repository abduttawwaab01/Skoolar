const StudentTimetable = {
    loadTimetable() {
        const student = this.getCurrentStudent();
        if (!student) {
            this.showError('Student not found');
            return;
        }
        
        const schoolId = this.getCurrentSchoolId();
        if (!schoolId) {
            this.showError('School not found');
            return;
        }
        
        // Sync from cloud first, then load
        this.syncAndLoad(student, schoolId);
    },

    syncAndLoad(student, schoolId) {
        // Sync from cloud first to get latest timetable
        if (typeof SupabaseSync !== 'undefined' && typeof SupabaseSync.isReady === 'function' && SupabaseSync.isReady()) {
            SupabaseSync.syncFromCloud().then(() => {
                this.loadTimetableData(student, schoolId);
            }).catch(e => {
                console.warn('Sync failed, loading from local:', e);
                this.loadTimetableData(student, schoolId);
            });
        } else {
            this.loadTimetableData(student, schoolId);
        }
    },
    
    loadTimetableData(student, schoolId) {
        const timetable = Storage.getData('timetable')?.filter(t => 
            t.schoolId === schoolId && 
            t.class === student.class
        ) || [];
        
        this.renderWeeklyGrid(timetable);
    },

    getCurrentStudent() {
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentStudent) {
            return StudentAuth.getCurrentStudent();
        }
        return null;
    },

    getCurrentSchoolId() {
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentSchoolId) {
            return StudentAuth.getCurrentSchoolId();
        }
        return null;
    },

    renderWeeklyGrid(timetable) {
        const container = document.getElementById('studentTimetableGrid');
        if (!container) return;
        
        if (timetable.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-calendar-alt"></i>
                    <p>No timetable entries found</p>
                </div>
            `;
            return;
        }
        
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
        const periods = [];
        timetable.forEach(t => {
            if (!periods.includes(t.periodNumber)) periods.push(t.periodNumber);
        });
        periods.sort((a, b) => a - b);
        
        let html = '<div class="timetable-week-grid">';
        
        html += '<div class="timetable-header-row">';
        html += '<div class="timetable-period-header">Period</div>';
        days.forEach(day => {
            html += `<div class="timetable-day-header">${day}</div>`;
        });
        html += '</div>';
        
        periods.forEach(period => {
            html += `<div class="timetable-row" data-period="${period}">`;
            html += `<div class="timetable-period-label">Period ${period}</div>`;
            
            days.forEach(day => {
                const entry = timetable.find(t => 
                    t.dayOfWeek === day && 
                    t.periodNumber === period
                );
                
                if (entry) {
                    html += `
                        <div class="timetable-cell ${this.getSubjectColorClass(entry.subject)}">
                            <div class="timetable-subject">${entry.subject}</div>
                            <div class="timetable-room">Room ${entry.room || 'N/A'}</div>
                            <div class="timetable-teacher">${entry.teacherName || 'N/A'}</div>
                        </div>
                    `;
                } else {
                    html += '<div class="timetable-cell empty"></div>';
                }
            });
            
            html += '</div>';
        });
        
        html += '</div>';
        container.innerHTML = html;
    },

    getSubjectColorClass(subject) {
        const colors = [
            'color-1', 'color-2', 'color-3', 'color-4', 'color-5',
            'color-6', 'color-7', 'color-8', 'color-9', 'color-10'
        ];
        const index = subject ? Math.abs(this.hashCode(subject)) % colors.length : 0;
        return colors[index];
    },

    hashCode(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return hash;
    },

    showError(message) {
        const container = document.getElementById('studentTimetableGrid');
        if (container) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>${message}</p>
                </div>
            `;
        }
    }
};

window.StudentTimetable = StudentTimetable;

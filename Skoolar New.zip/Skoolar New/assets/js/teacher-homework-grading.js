const TeacherHomeworkGrading = {
    currentPage: 1,
    itemsPerPage: 20,

    init() {
        this.loadHomeworkList();
    },

    loadHomeworkList() {
        const teacher = this.getCurrentTeacher();
        if (!teacher) {
            this.showError('Teacher not found');
            return;
        }
        
        const schoolId = String(teacher.schoolId);
        const homeworks = Storage.getData('homework')?.filter(h => 
            String(h.schoolId) === schoolId
        ) || [];
        
        const sortedHomeworks = homeworks.sort((a, b) => 
            new Date(b.created_at || b.due_date) - new Date(a.created_at || b.due_date)
        );
        
        this.renderHomeworkDropdown(sortedHomeworks);
        
        if (sortedHomeworks.length === 0) {
            document.getElementById('homeworkGradingContent').innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-tasks"></i>
                    <p>No homework assignments created yet.</p>
                </div>
            `;
        }
    },

    renderHomeworkDropdown(homeworks) {
        const select = document.getElementById('homeworkGradingSelect');
        if (!select) return;
        
        const currentValue = select.value;
        select.innerHTML = '<option value="">Choose homework...</option>';
        
        homeworks.forEach(homework => {
            const option = document.createElement('option');
            option.value = homework.id;
            option.textContent = `${homework.title} (${homework.subject}) - ${homework.class}`;
            select.appendChild(option);
        });
        
        if (currentValue) {
            select.value = currentValue;
        }
        
        // Show/hide edit/delete buttons based on selection
        const editBtn = document.getElementById('editHomeworkBtn');
        const deleteBtn = document.getElementById('deleteHomeworkBtn');
        if (editBtn) editBtn.style.display = currentValue ? 'inline-block' : 'none';
        if (deleteBtn) deleteBtn.style.display = currentValue ? 'inline-block' : 'none';
    },

     loadHomeworkSubmissions() {
         const homeworkId = document.getElementById('homeworkGradingSelect')?.value;
         if (!homeworkId) {
             document.getElementById('homeworkGradingContent').innerHTML = `
                 <div class="empty-state">
                     <i class="fas fa-tasks"></i>
                     <p>Select a homework assignment to view submissions</p>
                 </div>
             `;
             return;
         }

         const homework = Storage.getData('homework')?.find(h => String(h.id) === String(homeworkId));
         if (!homework) {
             this.showError('Homework not found');
             return;
         }

         // Use normalized homework_submissions table for reliability
         const submissions = Storage.getHomeworkSubmissions(String(homeworkId));
         const sortedSubmissions = submissions.sort((a, b) =>
             new Date(b.submissionDate) - new Date(a.submissionDate)
         );

         this.renderSubmissions(homework, sortedSubmissions);
     },

     renderSubmissions(homework, submissions) {
        const container = document.getElementById('homeworkGradingContent');
        if (!container) return;
        
        if (submissions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>No submissions yet for this homework.</p>
                </div>
            `;
            return;
        }
        
        let html = `
            <div class="card mb-3">
                <div class="card-body">
                    <h4>${homework.title}</h4>
                    <p class="text-muted">${homework.description || ''}</p>
                    <div class="stats-grid" style="margin-top: 16px;">
                        <div class="stat-card">
                            <div class="stat-label">Total Submissions</div>
                            <div class="stat-value">${submissions.length}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Graded</div>
                            <div class="stat-value">${submissions.filter(s => s.grade !== null).length}</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Pending</div>
                            <div class="stat-value">${submissions.filter(s => s.grade === null).length}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Submitted</th>
                                    <th>Answer Preview</th>
                                    <th>Status</th>
                                    <th>Grade</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
        `;
        
        submissions.forEach(submission => {
            const student = this.getStudentById(submission.studentId);
            const isGraded = submission.grade !== null;
            const submissionDate = new Date(submission.submissionDate).toLocaleString();
            const preview = this.truncateText(submission.answerText, 150);
            
            html += `
                <tr>
                    <td>
                        <strong>${student?.name || submission.studentName}</strong>
                        <br><small class="text-muted">${student?.class || ''}</small>
                    </td>
                    <td>${submissionDate}</td>
                    <td>${preview}</td>
                    <td>
                        ${isGraded 
                            ? `<span class="badge badge-success">Graded (${submission.grade}%)</span>` 
                            : '<span class="badge badge-warning">Pending</span>'
                        }
                    </td>
                    <td>
                        ${isGraded 
                            ? `<strong>${submission.grade}%</strong>` 
                            : '-'
                        }
                    </td>
                    <td>
                        <button class="btn btn-sm btn-outline" onclick="TeacherHomeworkGrading.showGradeModal('${homework.id}', '${submission.id}')">
                            ${isGraded ? 'Regrade' : 'Grade'}
                        </button>
                    </td>
                </tr>
            `;
        });
        
        html += `
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        container.innerHTML = html;
    },

    getStudentById(studentId) {
        const students = Storage.getData('students') || [];
        return students.find(s => String(s.id) === String(studentId));
    },

    truncateText(text, maxLength) {
        if (!text) return '';
        text = text.replace(/<[^>]*>/g, '');
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    },

     showGradeModal(homeworkId, submissionId) {
         const homework = Storage.getData('homework')?.find(h => String(h.id) === String(homeworkId));
         // Fetch submission from normalized table
         const submissions = Storage.getHomeworkSubmissions(String(homeworkId));
         const submission = submissions.find(s => String(s.id) === String(submissionId));
         const student = this.getStudentById(submission?.studentId);
        
        if (!homework || !submission || !student) {
            Toast.error('Data not found');
            return;
        }
        
        const teacher = this.getCurrentTeacher();
        const totalMarks = homework.total_marks || 100;
        
         const modalHtml = `
             <div class="modal-overlay" id="gradeHomeworkModal">
                 <div class="modal" style="max-width: 600px;">
                     <div class="modal-header">
                         <h3 class="modal-title">Grade Homework</h3>
                         <button class="modal-close" onclick="Modal.hide('gradeHomeworkModal')">&times;</button>
                     </div>
                     <div class="modal-body">
                         <div class="form-group">
                             <label>Student</label>
                             <p><strong>${student.name}</strong> (${student.class || 'N/A'})</p>
                         </div>
                         <div class="form-group">
                             <label>Assignment</label>
                             <p>${homework.title}</p>
                         </div>
                         <div class="form-group">
                             <label>Student's Answer</label>
                             <div style="background: var(--lighter); padding: 15px; border-radius: 8px; max-height: 200px; overflow-y: auto; white-space: pre-wrap;">${submission.answerText}</div>
                         </div>
                         ${submission.attachments && submission.attachments.length > 0 ? `
                             <div class="form-group">
                                 <label>Attachments (${submission.attachments.length})</label>
                                 <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
                                     ${submission.attachments.map(att => `
                                         <div style="border: 1px solid var(--gray); border-radius: 8px; padding: 8px; text-align: center; background: #fff;">
                                             <img src="${att.data}" alt="${att.name}" style="width: 120px; height: 120px; object-fit: cover; border-radius: 4px; margin-bottom: 5px;">
                                             <div style="font-size: 11px; color: var(--gray); max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${att.name}</div>
                                         </div>
                                     `).join('')}
                                 </div>
                             </div>
                         ` : ''}
                         <div class="form-row">
                             <div class="form-group">
                                 <label>Grade (0-${totalMarks})</label>
                                 <input type="number" id="gradeInput" class="form-control" min="0" max="${totalMarks}" value="${submission.grade || ''}" placeholder="Enter grade">
                             </div>
                             <div class="form-group">
                                 <label>Percentage</label>
                                 <input type="text" class="form-control" id="percentageDisplay" readonly value="${submission.grade !== null ? Math.round((submission.grade / totalMarks) * 100) + '%' : ''}">
                             </div>
                         </div>
                         <div class="form-group">
                             <label>Feedback</label>
                             <textarea id="feedbackInput" class="form-control" rows="4" placeholder="Provide feedback to the student...">${submission.feedback || ''}</textarea>
                         </div>
                     </div>
                     <div class="modal-footer">
                         <button class="btn btn-secondary" onclick="Modal.hide('gradeHomeworkModal')">Cancel</button>
                         <button class="btn btn-primary" onclick="TeacherHomeworkGrading.saveGrade('${homeworkId}', '${submissionId}')">Save Grade</button>
                     </div>
                 </div>
             </div>
         `;
        
        Modal.showCustom(modalHtml);
        
        document.getElementById('gradeInput')?.addEventListener('input', function() {
            const grade = parseFloat(this.value) || 0;
            const percentage = Math.round((grade / totalMarks) * 100);
            document.getElementById('percentageDisplay').value = percentage + '%';
        });
    },

    saveGrade(homeworkId, submissionId) {
        const grade = parseFloat(document.getElementById('gradeInput')?.value);
        const feedback = document.getElementById('feedbackInput')?.value?.trim();
        
        if (isNaN(grade)) {
            Toast.error('Please enter a valid grade');
            return;
        }
        
        const homework = Storage.getData('homework')?.find(h => h.id === homeworkId);
        const totalMarks = homework?.total_marks || 100;
        
        if (grade < 0 || grade > totalMarks) {
            Toast.error(`Grade must be between 0 and ${totalMarks}`);
            return;
        }
        
        const teacher = this.getCurrentTeacher();
        
        try {
            Storage.updateHomeworkSubmission(homeworkId, submissionId, {
                grade: grade,
                feedback: feedback,
                gradedBy: teacher.name,
                status: 'graded'
            });
            
            // Notify the student about their grade
            const submission = Storage.getData('homework_submissions')?.find(s => s.id === submissionId);
            if (submission && homework) {
                Auth.addNotification(submission.studentId, `Your ${homework.title} has been graded: ${grade}/${totalMarks}`, 'score');
            }
            
            // Trigger data sync event for real-time updates to student
            window.dispatchEvent(new CustomEvent('skoolar_data_updated', { 
                detail: { key: 'homework_submissions', action: 'update' } 
            }));
            
            Toast.success('Grade saved successfully');
            Modal.hide('gradeHomeworkModal');
            this.loadHomeworkSubmissions();
        } catch (error) {
            Toast.error('Failed to save grade: ' + error.message);
        }
    },

    getCurrentTeacher() {
        if (typeof Auth !== 'undefined' && Auth.getCurrentUser) {
            return Auth.getCurrentUser();
        }
        return null;
    },

    showError(message) {
        const container = document.getElementById('homeworkGradingContent');
        if (container) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>${message}</p>
                </div>
            `;
        }
    }
};

window.TeacherHomeworkGrading = TeacherHomeworkGrading;

-- ============================================
-- SKOOLAR COMPLETE DATABASE SCHEMA
-- Multi-Tenant School Management System
-- Compatible with Supabase PostgreSQL
-- ============================================

-- ============================================
-- DROP EXISTING TABLES (in correct order)
-- ============================================
DROP TABLE IF EXISTS messages CASCADE;
DROP TABLE IF EXISTS chats CASCADE;
DROP TABLE IF EXISTS student_messages CASCADE;
DROP TABLE IF EXISTS exam_results CASCADE;
DROP TABLE IF EXISTS exam_questions CASCADE;
DROP TABLE IF EXISTS exams CASCADE;
DROP TABLE IF EXISTS homework CASCADE;
DROP TABLE IF EXISTS timetable CASCADE;
DROP TABLE IF EXISTS library_books CASCADE;
DROP TABLE IF EXISTS parent_announcements CASCADE;
DROP TABLE IF EXISTS adverts CASCADE;
DROP TABLE IF EXISTS score_sessions CASCADE;
DROP TABLE IF EXISTS staff_attendance CASCADE;
DROP TABLE IF EXISTS calendar_events CASCADE;
DROP TABLE IF EXISTS test_results CASCADE;
DROP TABLE IF EXISTS test_attempts CASCADE;
DROP TABLE IF EXISTS questions CASCADE;
DROP TABLE IF EXISTS tests CASCADE;
DROP TABLE IF EXISTS sync_log CASCADE;
DROP TABLE IF EXISTS audit_log CASCADE;
DROP TABLE IF EXISTS notifications CASCADE;
DROP TABLE IF EXISTS finance CASCADE;
DROP TABLE IF EXISTS scores CASCADE;
DROP TABLE IF EXISTS attendance CASCADE;
DROP TABLE IF EXISTS students CASCADE;
DROP TABLE IF EXISTS teachers CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS activation_codes CASCADE;
DROP TABLE IF EXISTS schools CASCADE;

-- ============================================
-- CORE TABLES
-- ============================================

-- SCHOOLS TABLE
CREATE TABLE IF NOT EXISTS schools (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    alias TEXT,
    email TEXT,
    phone TEXT,
    address TEXT,
    type TEXT DEFAULT 'primary' CHECK (type IN ('primary', 'secondary', 'both')),
    currency TEXT DEFAULT 'NGN',
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'closed')),
    logo TEXT,
    settings JSONB DEFAULT '{}',
    restrictions JSONB DEFAULT '{"disabled_features": [], "disabled_dashboards": []}',
    activation_code_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    subscription_days INTEGER DEFAULT 365,
    supabase_last_sync TIMESTAMPTZ
);

-- USERS TABLE (Staff/Admin accounts)
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT NOT NULL CHECK (role IN ('super_admin', 'school_admin', 'teacher', 'accountant', 'director', 'parent', 'student')),
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
    avatar TEXT,
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- STUDENTS TABLE
CREATE TABLE IF NOT EXISTS students (
    id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    student_id TEXT UNIQUE,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    class TEXT,
    section TEXT,
    gender TEXT CHECK (gender IN ('male', 'female', 'other')),
    dob DATE,
    blood_group TEXT,
    address TEXT,
    guardian_name TEXT,
    guardian_phone TEXT,
    guardian_email TEXT,
    guardian_occupation TEXT,
    username TEXT UNIQUE,
    password TEXT,
    photo TEXT,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'graduated', 'transferred', 'suspended')),
    enrollment_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- TEACHERS TABLE
CREATE TABLE IF NOT EXISTS teachers (
    id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    employee_id TEXT,
    department TEXT,
    classes JSONB DEFAULT '[]',
    subjects JSONB DEFAULT '[]',
    qualifications TEXT,
    experience_years INTEGER,
    photo TEXT,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- ACTIVATION CODES TABLE
CREATE TABLE IF NOT EXISTS activation_codes (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    school_id TEXT REFERENCES schools(id) ON DELETE SET NULL,
    is_used BOOLEAN DEFAULT FALSE,
    is_revoked BOOLEAN DEFAULT FALSE,
    subscription_days INTEGER DEFAULT 365,
    expires_at TIMESTAMPTZ,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    used_at TIMESTAMPTZ,
    supabase_last_sync TIMESTAMPTZ
);

-- ============================================
-- ACADEMIC TABLES
-- ============================================

-- ATTENDANCE TABLE
CREATE TABLE IF NOT EXISTS attendance (
    id TEXT PRIMARY KEY,
    student_id TEXT REFERENCES students(id) ON DELETE CASCADE,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    class TEXT,
    section TEXT,
    date DATE NOT NULL,
    status TEXT DEFAULT 'present' CHECK (status IN ('present', 'absent', 'late', 'excused')),
    remarks TEXT,
    marked_by TEXT,
    marked_at TIMESTAMPTZ DEFAULT NOW(),
    term TEXT CHECK (term IN ('First', 'Second', 'Third')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    supabase_last_sync TIMESTAMPTZ,
    UNIQUE(student_id, date, term, year)
);

-- STAFF ATTENDANCE TABLE
CREATE TABLE IF NOT EXISTS staff_attendance (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    staff_id TEXT NOT NULL,
    staff_name TEXT,
    date DATE NOT NULL,
    check_in TIMESTAMPTZ,
    check_out TIMESTAMPTZ,
    location_in TEXT,
    location_out TEXT,
    status TEXT DEFAULT 'present' CHECK (status IN ('present', 'absent', 'late', 'excused', 'on_leave')),
    remarks TEXT,
    supabase_last_sync TIMESTAMPTZ,
    UNIQUE(staff_id, date)
);

-- SCORES TABLE
CREATE TABLE IF NOT EXISTS scores (
    id TEXT PRIMARY KEY,
    student_id TEXT REFERENCES students(id) ON DELETE CASCADE,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    student_name TEXT,
    class TEXT,
    subject TEXT,
    term TEXT CHECK (term IN ('First', 'Second', 'Third')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    score_type TEXT CHECK (score_type IN ('Daily', 'Weekly', 'Mid-term', 'Exam')),
    score DECIMAL(5,2),
    max_score DECIMAL(5,2) DEFAULT 100,
    entered_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ,
    UNIQUE(student_id, subject, term, year, score_type)
);

-- SCORE SESSIONS TABLE
CREATE TABLE IF NOT EXISTS score_sessions (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    teacher_id TEXT,
    class TEXT,
    subject TEXT,
    type TEXT CHECK (type IN ('Daily', 'Weekly', 'Mid-term', 'Exam')),
    term TEXT CHECK (term IN ('First', 'Second', 'Third')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    date DATE DEFAULT CURRENT_DATE,
    total_students INTEGER DEFAULT 0,
    average_score DECIMAL(5,2),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- QUESTIONS TABLE (Question Bank)
CREATE TABLE IF NOT EXISTS questions (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    teacher_id TEXT,
    subject TEXT NOT NULL,
    class TEXT NOT NULL,
    question TEXT NOT NULL,
    type TEXT CHECK (type IN ('mcq', 'true_false', 'fill_blank', 'essay', 'short_answer')),
    options JSONB DEFAULT '[]',
    correct_answer TEXT,
    marks DECIMAL(5,2) DEFAULT 1,
    difficulty TEXT CHECK (difficulty IN ('easy', 'medium', 'hard')),
    topic TEXT,
    explanation TEXT,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- TESTS TABLE
CREATE TABLE IF NOT EXISTS tests (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    teacher_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    subject TEXT NOT NULL,
    class TEXT NOT NULL,
    type TEXT CHECK (type IN ('mcq', 'true_false', 'fill_blank', 'essay', 'mixed')),
    term TEXT CHECK (term IN ('First', 'Second', 'Third')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    duration_minutes INTEGER DEFAULT 30,
    passing_percentage DECIMAL(5,2) DEFAULT 50,
    shuffle_questions BOOLEAN DEFAULT FALSE,
    show_results BOOLEAN DEFAULT TRUE,
    status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- TEST QUESTIONS (junction table)
CREATE TABLE IF NOT EXISTS test_questions (
    id TEXT PRIMARY KEY,
    test_id TEXT REFERENCES tests(id) ON DELETE CASCADE,
    question_id TEXT REFERENCES questions(id) ON DELETE CASCADE,
    question_order INTEGER,
    marks DECIMAL(5,2)
);

-- TEST RESULTS TABLE
CREATE TABLE IF NOT EXISTS test_results (
    id TEXT PRIMARY KEY,
    test_id TEXT REFERENCES tests(id) ON DELETE CASCADE,
    student_id TEXT REFERENCES students(id) ON DELETE CASCADE,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    score DECIMAL(5,2),
    total_marks DECIMAL(5,2),
    percentage DECIMAL(5,2),
    status TEXT CHECK (status IN ('passed', 'failed', 'incomplete')),
    answers JSONB DEFAULT '{}',
    started_at TIMESTAMPTZ,
    submitted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ,
    UNIQUE(test_id, student_id)
);

-- TEST ATTEMPTS TABLE
CREATE TABLE IF NOT EXISTS test_attempts (
    id TEXT PRIMARY KEY,
    test_id TEXT REFERENCES tests(id) ON DELETE CASCADE,
    student_id TEXT REFERENCES students(id) ON DELETE CASCADE,
    attempt_number INTEGER,
    best_score DECIMAL(5,2),
    total_attempts INTEGER DEFAULT 0,
    last_attempt_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(test_id, student_id)
);

-- ============================================
-- FINANCE TABLES
-- ============================================

-- FINANCE TABLE
CREATE TABLE IF NOT EXISTS finance (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    type TEXT CHECK (type IN ('income', 'expense')) NOT NULL,
    category TEXT NOT NULL,
    account_id TEXT REFERENCES chart_of_accounts(id) ON DELETE SET NULL,
    amount DECIMAL(12,2) NOT NULL,
    tax_amount DECIMAL(12,2) DEFAULT 0,
    description TEXT,
    payment_method TEXT CHECK (payment_method IN ('cash', 'bank_transfer', 'online', 'cheque', 'pos')),
    reference_number TEXT,
    related_student_id TEXT REFERENCES students(id) ON DELETE SET NULL,
    related_class TEXT,
    term TEXT CHECK (term IN ('First', 'Second', 'Third')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    date DATE DEFAULT CURRENT_DATE,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- CHART OF ACCOUNTS TABLE
CREATE TABLE IF NOT EXISTS chart_of_accounts (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    account_code TEXT NOT NULL,
    account_name TEXT NOT NULL,
    account_type TEXT CHECK (account_type IN ('asset', 'liability', 'equity', 'income', 'expense')) NOT NULL,
    sub_type TEXT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    is_default BOOLEAN DEFAULT FALSE,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ,
    UNIQUE(school_id, account_code)
);

-- BUDGETS TABLE
CREATE TABLE IF NOT EXISTS budgets (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    academic_year TEXT NOT NULL,
    term TEXT CHECK (term IN ('First', 'Second', 'Third', 'Annual')),
    category TEXT NOT NULL,
    subcategory TEXT,
    period_type TEXT CHECK (period_type IN ('monthly', 'quarterly', 'termly', 'annual')),
    allocated_amount DECIMAL(12,2) NOT NULL,
    actual_amount DECIMAL(12,2) DEFAULT 0,
    start_date DATE,
    end_date DATE,
    notes TEXT,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ,
    UNIQUE(school_id, academic_year, term, category, subcategory, period_type)
);

-- ACCOUNTS RECEIVABLE TABLE (Student Fees)
CREATE TABLE IF NOT EXISTS accounts_receivable (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    student_id TEXT REFERENCES students(id) ON DELETE SET NULL,
    student_name TEXT NOT NULL,
    guardian_name TEXT,
    guardian_phone TEXT,
    invoice_number TEXT,
    fee_type TEXT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    paid_amount DECIMAL(12,2) DEFAULT 0,
    due_date DATE,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'partial', 'paid', 'overdue', 'waived')),
    description TEXT,
    notes TEXT,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_payment_date TIMESTAMPTZ,
    supabase_last_sync TIMESTAMPTZ
);

-- TAX SETTINGS TABLE
CREATE TABLE IF NOT EXISTS tax_settings (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    tax_name TEXT NOT NULL,
    tax_rate DECIMAL(5,2) NOT NULL,
    is_inclusive BOOLEAN DEFAULT FALSE,
    applies_to_categories JSONB DEFAULT '[]',
    account_code TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- FINANCIAL ATTACHMENTS TABLE
CREATE TABLE IF NOT EXISTS financial_attachments (
    id TEXT PRIMARY KEY,
    transaction_id TEXT REFERENCES finance(id) ON DELETE CASCADE,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    file_type TEXT,
    file_size INTEGER,
    file_url TEXT NOT NULL,
    uploaded_by TEXT,
    uploaded_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- RECEIPTS TABLE
CREATE TABLE IF NOT EXISTS receipts (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    receipt_number TEXT UNIQUE NOT NULL,
    transaction_id TEXT REFERENCES finance(id) ON DELETE SET NULL,
    payment_type TEXT CHECK (payment_type IN ('school_fees', 'hostel_fees', 'tuition', 'other')),
    payer_name TEXT,
    payer_id TEXT,
    receiver_name TEXT,
    receiver_id TEXT,
    amount DECIMAL(12,2) NOT NULL,
    description TEXT,
    format TEXT CHECK (format IN ('pdf', 'doc', 'image')),
    file_url TEXT,
    generated_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ;

-- ============================================
-- COMMUNICATION TABLES
-- ============================================

-- CHATS TABLE
CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    title TEXT,
    type TEXT CHECK (type IN ('direct', 'group', 'class')),
    participants JSONB DEFAULT '[]',
    last_message TEXT,
    last_message_at TIMESTAMPTZ,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- MESSAGES TABLE
CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    chat_id TEXT REFERENCES chats(id) ON DELETE CASCADE,
    sender_id TEXT NOT NULL,
    sender_name TEXT,
    sender_role TEXT,
    message TEXT NOT NULL,
    message_type TEXT CHECK (message_type IN ('text', 'image', 'file', 'system')) DEFAULT 'text',
    attachments JSONB DEFAULT '[]',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- PARENT ANNOUNCEMENTS TABLE
CREATE TABLE IF NOT EXISTS parent_announcements (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    message TEXT,
    target_class TEXT,
    target_student_ids JSONB DEFAULT '[]',
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- STUDENT MESSAGES TABLE
 CREATE TABLE IF NOT EXISTS student_messages (
     id TEXT PRIMARY KEY,
     school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
     student_id TEXT REFERENCES students(id) ON DELETE CASCADE,
     from_role TEXT,
     from_name TEXT,
     subject TEXT,
     message TEXT,
     is_read BOOLEAN DEFAULT FALSE,
     reply_message TEXT,
     replied_at TIMESTAMPTZ,
     replied_by TEXT,
     created_at TIMESTAMPTZ DEFAULT NOW(),
     supabase_last_sync TIMESTAMPTZ
 );

 -- PARENT MESSAGES TABLE
 CREATE TABLE IF NOT EXISTS parent_messages (
     id TEXT PRIMARY KEY,
     school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
     parent_id TEXT,
     parent_name TEXT,
     student_id TEXT REFERENCES students(id) ON DELETE CASCADE,
     student_name TEXT,
     subject TEXT,
     message TEXT,
     is_read BOOLEAN DEFAULT FALSE,
     reply_message TEXT,
     replied_at TIMESTAMPTZ,
     replied_by TEXT,
     created_at TIMESTAMPTZ DEFAULT NOW(),
     supabase_last_sync TIMESTAMPTZ
 );

 CREATE INDEX IF NOT EXISTS idx_parent_messages_school_id ON parent_messages(school_id);
 CREATE INDEX IF NOT EXISTS idx_parent_messages_student_id ON parent_messages(student_id);
 CREATE INDEX IF NOT EXISTS idx_parent_messages_parent_id ON parent_messages(parent_id);
 CREATE INDEX IF NOT EXISTS idx_parent_messages_is_read ON parent_messages(is_read);

 -- NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    message TEXT,
    type TEXT CHECK (type IN ('info', 'success', 'warning', 'error', 'announcement')),
    is_read BOOLEAN DEFAULT FALSE,
    link TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- CALENDAR & EVENTS
-- ============================================

-- CALENDAR EVENTS TABLE
CREATE TABLE IF NOT EXISTS calendar_events (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    event_date DATE,
    event_type TEXT CHECK (event_type IN ('academic', 'exam', 'holiday', 'event', 'meeting', 'deadline')),
    for_classes JSONB DEFAULT '[]',
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- ============================================
-- ADVERTS & ANNOUNCEMENTS
-- ============================================

-- ADVERTS TABLE
 CREATE TABLE IF NOT EXISTS adverts (
     id TEXT PRIMARY KEY,
     school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
     title TEXT NOT NULL,
     description TEXT,
     media_type TEXT,
     media_url TEXT,
     button_text TEXT,
     button_link TEXT,
     target_schools JSONB DEFAULT '[]',
     target_roles JSONB DEFAULT '[]',
     is_active BOOLEAN DEFAULT TRUE,
     position TEXT CHECK (position IN ('sidebar', 'banner', 'popup', 'login')),
     start_date DATE,
     end_date DATE,
     expires_at TIMESTAMPTZ,
     impressions INTEGER DEFAULT 0,
     clicks INTEGER DEFAULT 0,
     created_by TEXT,
     display_order INTEGER DEFAULT 0,
     created_at TIMESTAMPTZ DEFAULT NOW(),
     supabase_last_sync TIMESTAMPTZ
 );

-- ============================================
-- ENHANCED FEATURES TABLES
-- ============================================

-- TIMETABLE TABLE
CREATE TABLE IF NOT EXISTS timetable (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    class TEXT NOT NULL,
    section TEXT,
    day_of_week TEXT CHECK (day_of_week IN ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')),
    period_number INTEGER NOT NULL,
    subject TEXT NOT NULL,
    teacher_id TEXT,
    teacher_name TEXT,
    room TEXT,
    term TEXT CHECK (term IN ('First', 'Second', 'Third')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ,
    UNIQUE(school_id, class, day_of_week, period_number, term, year)
);

-- LIBRARY BOOKS TABLE
CREATE TABLE IF NOT EXISTS library_books (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    isbn TEXT,
    title TEXT NOT NULL,
    author TEXT,
    publisher TEXT,
    category TEXT,
    quantity INTEGER DEFAULT 1,
    available INTEGER DEFAULT 1,
    shelf_location TEXT,
    status TEXT DEFAULT 'available' CHECK (status IN ('available', 'borrowed', 'lost', 'damaged')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
     supabase_last_sync TIMESTAMPTZ
 );

 -- BOOK LOANS TABLE
 CREATE TABLE IF NOT EXISTS book_loans (
     id TEXT PRIMARY KEY,
     school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
     book_id TEXT NOT NULL,
     student_id TEXT NOT NULL,
     student_name TEXT,
     checkout_date DATE NOT NULL,
     due_date DATE NOT NULL,
     return_date DATE,
     status TEXT DEFAULT 'borrowed' CHECK (status IN ('borrowed', 'returned')),
     fine_amount DECIMAL(10,2) DEFAULT 0,
     created_at TIMESTAMPTZ DEFAULT NOW(),
     supabase_last_sync TIMESTAMPTZ
 );

 CREATE INDEX IF NOT EXISTS idx_book_loans_school_id ON book_loans(school_id);
 CREATE INDEX IF NOT EXISTS idx_book_loans_student_id ON book_loans(student_id);
 CREATE INDEX IF NOT EXISTS idx_book_loans_book_id ON book_loans(book_id);
   CREATE INDEX IF NOT EXISTS idx_book_loans_status ON book_loans(status);

   -- ============================================
   -- SUPER ADMIN GLOBAL TABLES
   -- ============================================

   -- SYSTEM CONFIG (Theme settings, global announcement)
   CREATE TABLE IF NOT EXISTS system_config (
       id TEXT PRIMARY KEY DEFAULT 'global',
       settings JSONB DEFAULT '{}',
       announcement JSONB DEFAULT NULL,
       created_at TIMESTAMPTZ DEFAULT NOW(),
       updated_at TIMESTAMPTZ DEFAULT NOW(),
       supabase_last_sync TIMESTAMPTZ
   );

   -- BLOG POSTS TABLE
   CREATE TABLE IF NOT EXISTS blog_posts (
       id TEXT PRIMARY KEY,
       slug TEXT UNIQUE NOT NULL,
       title TEXT NOT NULL,
       excerpt TEXT,
       content TEXT NOT NULL,
       featured_image TEXT,
       category TEXT,
       tags JSONB DEFAULT '[]',
       video_url TEXT,
       audio_url TEXT,
       featured BOOLEAN DEFAULT FALSE,
       comments_enabled BOOLEAN DEFAULT TRUE,
       status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
       views INTEGER DEFAULT 0,
       author_name TEXT,
       author_avatar TEXT,
       created_at TIMESTAMPTZ DEFAULT NOW(),
       updated_at TIMESTAMPTZ DEFAULT NOW(),
       published_at TIMESTAMPTZ,
       supabase_last_sync TIMESTAMPTZ
   );

   CREATE INDEX IF NOT EXISTS idx_blog_posts_status ON blog_posts(status);
   CREATE INDEX IF NOT EXISTS idx_blog_posts_slug ON blog_posts(slug);
   CREATE INDEX IF NOT EXISTS idx_blog_posts_featured ON blog_posts(featured);
   CREATE INDEX IF NOT EXISTS idx_blog_posts_category ON blog_posts(category);
   CREATE INDEX IF NOT EXISTS idx_blog_posts_created_at ON blog_posts(created_at DESC);

   -- RESOURCES TABLE
   CREATE TABLE IF NOT EXISTS resources (
       id TEXT PRIMARY KEY,
       title TEXT NOT NULL,
       description TEXT,
       category TEXT NOT NULL CHECK (category IN ('Documents', 'Videos', 'Audio', 'Images', 'Archives', 'Other')),
       file_url TEXT,
       file_type TEXT,
       file_size TEXT,
       thumbnail TEXT,
       tags JSONB DEFAULT '[]',
       downloads INTEGER DEFAULT 0,
       status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'archived')),
       created_at TIMESTAMPTZ DEFAULT NOW(),
       updated_at TIMESTAMPTZ DEFAULT NOW(),
       supabase_last_sync TIMESTAMPTZ
   );

   CREATE INDEX IF NOT EXISTS idx_resources_category ON resources(category);
   CREATE INDEX IF NOT EXISTS idx_resources_status ON resources(status);

   -- PRICING PLANS TABLE
   CREATE TABLE IF NOT EXISTS pricing_plans (
       id TEXT PRIMARY KEY,
       plan_name TEXT NOT NULL UNIQUE,
       price DECIMAL(10,2),
       period TEXT DEFAULT 'monthly',
       description TEXT,
       features JSONB DEFAULT '[]',
       cta_text TEXT DEFAULT 'Get Started',
       highlighted BOOLEAN DEFAULT FALSE,
       display_order INTEGER DEFAULT 0,
       is_active BOOLEAN DEFAULT TRUE,
       created_at TIMESTAMPTZ DEFAULT NOW(),
       updated_at TIMESTAMPTZ DEFAULT NOW(),
       supabase_last_sync TIMESTAMPTZ
   );

   CREATE INDEX IF NOT EXISTS idx_pricing_plans_order ON pricing_plans(display_order);
   CREATE INDEX IF NOT EXISTS idx_pricing_plans_active ON pricing_plans(is_active);

   -- STATIC PAGES TABLE (Privacy Policy, Terms, etc.)
   CREATE TABLE IF NOT EXISTS static_pages (
       page_name TEXT PRIMARY KEY,
       title TEXT NOT NULL,
       content TEXT NOT NULL,
       meta_description TEXT,
       updated_at TIMESTAMPTZ DEFAULT NOW(),
       supabase_last_sync TIMESTAMPTZ
   );

   -- ============================================
   -- STORIES TABLES (Public Reading Platform)
   -- ============================================

   -- STORIES TABLE
   CREATE TABLE IF NOT EXISTS stories (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      subtitle TEXT,
      author_name TEXT NOT NULL,
      author_bio TEXT,
      author_photo TEXT,
      cover_image TEXT,
      description TEXT,
      content TEXT NOT NULL,
      content_type TEXT DEFAULT 'html' CHECK (content_type IN ('html', 'markdown', 'plain')),
      word_count INTEGER NOT NULL,
      read_time_minutes INTEGER NOT NULL,
      genre TEXT NOT NULL,
      age_group TEXT CHECK (age_group IN ('children', 'young_adult', 'adult', 'all')),
      status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'pending_review', 'published', 'archived', 'rejected')),
      featured BOOLEAN DEFAULT FALSE,
      featured_until TIMESTAMPTZ,
      allow_comments BOOLEAN DEFAULT TRUE,
      downloadable BOOLEAN DEFAULT FALSE,
      download_count INTEGER DEFAULT 0,
      downloadable_formats JSONB DEFAULT '["pdf","txt"]',
      tags JSONB DEFAULT '[]',
      engagement JSONB DEFAULT '{"views":0,"likes":0,"dislikes":0,"shares":0,"comments":0,"rating_sum":0,"rating_count":0}',
      submission_data JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      published_at TIMESTAMPTZ,
      supabase_last_sync TIMESTAMPTZ
  );

   CREATE INDEX IF NOT EXISTS idx_stories_status ON stories(status);
   CREATE INDEX IF NOT EXISTS idx_stories_featured ON stories(featured);
   CREATE INDEX IF NOT EXISTS idx_stories_genre ON stories(genre);
   CREATE INDEX IF NOT EXISTS idx_stories_created_at ON stories(created_at DESC);
   CREATE INDEX IF NOT EXISTS idx_stories_published_at ON stories(published_at DESC);
   CREATE INDEX IF NOT EXISTS idx_stories_slug ON stories(slug);

   -- STORY INTERACTIONS TABLE (Ratings only as requested; views/likes/shares tracked in JSON)
   CREATE TABLE IF NOT EXISTS story_interactions (
      id TEXT PRIMARY KEY,
      story_id TEXT NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
      user_id TEXT,
      user_ip TEXT,
      interaction_type TEXT CHECK (interaction_type IN ('like', 'dislike', 'share', 'download', 'rating', 'bookmark')),
      rating_value INTEGER CHECK (rating_value >= 1 AND rating_value <= 5),
      created_at TIMESTAMPTZ DEFAULT NOW(),
      supabase_last_sync TIMESTAMPTZ,
      UNIQUE(story_id, user_id, user_ip, interaction_type)
  );

   CREATE INDEX IF NOT EXISTS idx_story_interactions_story_id ON story_interactions(story_id);
   CREATE INDEX IF NOT EXISTS idx_story_interactions_user_id ON story_interactions(user_id);
   CREATE INDEX IF NOT EXISTS idx_story_interactions_type ON story_interactions(interaction_type);

   -- STORY COMMENTS TABLE
   CREATE TABLE IF NOT EXISTS story_comments (
      id TEXT PRIMARY KEY,
      story_id TEXT NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
      user_id TEXT,
      user_name TEXT NOT NULL,
      user_email TEXT,
      parent_id TEXT REFERENCES story_comments(id) ON DELETE CASCADE,
      content TEXT NOT NULL,
      status TEXT DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'rejected', 'spam')),
      reported BOOLEAN DEFAULT FALSE,
      likes INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      supabase_last_sync TIMESTAMPTZ
  );

   CREATE INDEX IF NOT EXISTS idx_story_comments_story_id ON story_comments(story_id);
   CREATE INDEX IF NOT EXISTS idx_story_comments_user_id ON story_comments(user_id);
   CREATE INDEX IF NOT EXISTS idx_story_comments_created_at ON story_comments(created_at DESC);
   CREATE INDEX IF NOT EXISTS idx_story_comments_parent_id ON story_comments(parent_id);

   -- STORY SUBMISSIONS TABLE (for user submissions)
   CREATE TABLE IF NOT EXISTS story_submissions (
       id TEXT PRIMARY KEY,
       story_id TEXT REFERENCES stories(id) ON DELETE SET NULL,
       submitter_id TEXT,
       submitter_name TEXT NOT NULL,
       submitter_email TEXT,
       submitter_role TEXT DEFAULT 'user',
       submitter_school_id TEXT REFERENCES schools(id) ON DELETE SET NULL,
       submission_data JSONB NOT NULL,
       status TEXT DEFAULT 'pending_review' CHECK (status IN ('submitted', 'under_review', 'approved', 'rejected', 'needs_revision', 'published')),
       reviewer_id TEXT,
       reviewer_notes TEXT,
       reviewed_at TIMESTAMPTZ,
       publish_immediately BOOLEAN DEFAULT FALSE,
       created_at TIMESTAMPTZ DEFAULT NOW(),
       updated_at TIMESTAMPTZ DEFAULT NOW(),
       supabase_last_sync TIMESTAMPTZ
   );

   CREATE INDEX IF NOT EXISTS idx_story_submissions_status ON story_submissions(status);
   CREATE INDEX IF NOT EXISTS idx_story_submissions_submitter_id ON story_submissions(submitter_id);
   CREATE INDEX IF NOT EXISTS idx_story_submissions_created_at ON story_submissions(created_at DESC);
   CREATE INDEX IF NOT EXISTS idx_story_submissions_story_id ON story_submissions(story_id);

   -- HOMEWORK TABLE
CREATE TABLE IF NOT EXISTS homework (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    teacher_id TEXT,
    class TEXT NOT NULL,
    subject TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    due_date DATE,
    total_marks DECIMAL(5,2),
    attachments JSONB DEFAULT '[]',
    term TEXT CHECK (term IN ('First', 'Second', 'Third')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'closed', 'archived')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
     supabase_last_sync TIMESTAMPTZ
 );

 -- HOMEWORK SUBMISSIONS TABLE
 CREATE TABLE IF NOT EXISTS homework_submissions (
     id TEXT PRIMARY KEY,
     homework_id TEXT NOT NULL,
     student_id TEXT NOT NULL,
     student_name TEXT,
     school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
     submission_date DATE NOT NULL,
     status TEXT DEFAULT 'submitted' CHECK (status IN ('submitted', 'graded', 'returned')),
     answer_text TEXT,
     attachments JSONB DEFAULT '[]',
     grade DECIMAL(5,2),
     feedback TEXT,
     graded_by TEXT,
     graded_at TIMESTAMPTZ,
     created_at TIMESTAMPTZ DEFAULT NOW(),
     supabase_last_sync TIMESTAMPTZ,
     UNIQUE(homework_id, student_id)
 );

 CREATE INDEX IF NOT EXISTS idx_homework_submissions_homework_id ON homework_submissions(homework_id);
 CREATE INDEX IF NOT EXISTS idx_homework_submissions_student_id ON homework_submissions(student_id);
 CREATE INDEX IF NOT EXISTS idx_homework_submissions_school_id ON homework_submissions(school_id);

 -- ============================================
 -- EXAMS TABLE (Online Exams)
 -- ============================================

-- EXAMS TABLE
CREATE TABLE IF NOT EXISTS exams (
    id TEXT PRIMARY KEY,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    subject TEXT NOT NULL,
    class TEXT NOT NULL,
    exam_type TEXT CHECK (exam_type IN ('objective', 'subjective', 'mixed')),
    term TEXT CHECK (term IN ('First', 'Second', 'Third')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    start_date TIMESTAMPTZ,
    end_date TIMESTAMPTZ,
    duration_minutes INTEGER DEFAULT 60,
    passing_score DECIMAL(5,2) DEFAULT 50,
    randomize_questions BOOLEAN DEFAULT FALSE,
    randomize_options BOOLEAN DEFAULT FALSE,
    show_results BOOLEAN DEFAULT TRUE,
    status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'ongoing', 'completed', 'archived')),
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ
);

-- EXAM QUESTIONS TABLE
CREATE TABLE IF NOT EXISTS exam_questions (
    id TEXT PRIMARY KEY,
    exam_id TEXT REFERENCES exams(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    question_type TEXT CHECK (question_type IN ('mcq', 'true_false', 'fill_blank', 'essay', 'short_answer')),
    options JSONB DEFAULT '[]',
    correct_answer TEXT,
    points DECIMAL(5,2) DEFAULT 1,
    explanation TEXT,
    question_order INTEGER
);

-- EXAM RESULTS TABLE
CREATE TABLE IF NOT EXISTS exam_results (
    id TEXT PRIMARY KEY,
    exam_id TEXT REFERENCES exams(id) ON DELETE CASCADE,
    student_id TEXT REFERENCES students(id) ON DELETE CASCADE,
    school_id TEXT REFERENCES schools(id) ON DELETE CASCADE,
    answers JSONB DEFAULT '{}',
    score DECIMAL(5,2),
    total_points DECIMAL(5,2),
    percentage DECIMAL(5,2),
    status TEXT CHECK (status IN ('in_progress', 'submitted', 'graded')),
    started_at TIMESTAMPTZ,
    submitted_at TIMESTAMPTZ,
    graded_by TEXT,
    graded_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    supabase_last_sync TIMESTAMPTZ,
    UNIQUE(exam_id, student_id)
);

-- ============================================
-- SYSTEM TABLES
-- ============================================

-- SYNC LOG TABLE
CREATE TABLE IF NOT EXISTS sync_log (
    id TEXT PRIMARY KEY,
    school_id TEXT,
    sync_type TEXT,
    direction TEXT CHECK (direction IN ('upload', 'download', 'both')),
    records_count INTEGER DEFAULT 0,
    status TEXT CHECK (status IN ('success', 'partial', 'error')),
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AUDIT LOG TABLE
CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    school_id TEXT,
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    old_values JSONB,
    new_values JSONB,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================

-- Schools indexes
CREATE INDEX IF NOT EXISTS idx_schools_status ON schools(status);
CREATE INDEX IF NOT EXISTS idx_schools_expires_at ON schools(expires_at);

-- Users indexes
CREATE INDEX IF NOT EXISTS idx_users_school_id ON users(school_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

-- Students indexes
CREATE INDEX IF NOT EXISTS idx_students_school_id ON students(school_id);
CREATE INDEX IF NOT EXISTS idx_students_class ON students(class);
CREATE INDEX IF NOT EXISTS idx_students_status ON students(status);
CREATE INDEX IF NOT EXISTS idx_students_student_id ON students(student_id);

-- Attendance indexes
CREATE INDEX IF NOT EXISTS idx_attendance_student_id ON attendance(student_id);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
CREATE INDEX IF NOT EXISTS idx_attendance_class_term_year ON attendance(class, term, year);
CREATE INDEX IF NOT EXISTS idx_attendance_school_date ON attendance(school_id, date);

-- Scores indexes
CREATE INDEX IF NOT EXISTS idx_scores_student_id ON scores(student_id);
CREATE INDEX IF NOT EXISTS idx_scores_subject ON scores(subject);
CREATE INDEX IF NOT EXISTS idx_scores_class_term_year ON scores(class, term, year);
CREATE INDEX IF NOT EXISTS idx_scores_school_term_year ON scores(school_id, term, year);

-- Finance indexes
CREATE INDEX IF NOT EXISTS idx_finance_school_id ON finance(school_id);
CREATE INDEX IF NOT EXISTS idx_finance_type ON finance(type);
CREATE INDEX IF NOT EXISTS idx_finance_category ON finance(category);
CREATE INDEX IF NOT EXISTS idx_finance_account_id ON finance(account_id);
CREATE INDEX IF NOT EXISTS idx_finance_date ON finance(date);
CREATE INDEX IF NOT EXISTS idx_finance_term_year ON finance(term, year);

-- Chart of Accounts indexes
CREATE INDEX IF NOT EXISTS idx_chart_of_accounts_school_id ON chart_of_accounts(school_id);
CREATE INDEX IF NOT EXISTS idx_chart_of_accounts_code ON chart_of_accounts(account_code);
CREATE INDEX IF NOT EXISTS idx_chart_of_accounts_type ON chart_of_accounts(account_type);

-- Budgets indexes
CREATE INDEX IF NOT EXISTS idx_budgets_school_id ON budgets(school_id);
CREATE INDEX IF NOT EXISTS idx_budgets_year_term ON budgets(academic_year, term);
CREATE INDEX IF NOT EXISTS idx_budgets_category ON budgets(category);

-- Accounts Receivable indexes
CREATE INDEX IF NOT EXISTS idx_accounts_receivable_school_id ON accounts_receivable(school_id);
CREATE INDEX IF NOT EXISTS idx_accounts_receivable_student_id ON accounts_receivable(student_id);
CREATE INDEX IF NOT EXISTS idx_accounts_receivable_status ON accounts_receivable(status);
CREATE INDEX IF NOT EXISTS idx_accounts_receivable_due_date ON accounts_receivable(due_date);

-- Tax Settings indexes
CREATE INDEX IF NOT EXISTS idx_tax_settings_school_id ON tax_settings(school_id);

-- Financial Attachments indexes
CREATE INDEX IF NOT EXISTS idx_financial_attachments_transaction ON financial_attachments(transaction_id);
CREATE INDEX IF NOT EXISTS idx_financial_attachments_school ON financial_attachments(school_id);

-- Receipts indexes
CREATE INDEX IF NOT EXISTS idx_receipts_school_id ON receipts(school_id);
CREATE INDEX IF NOT EXISTS idx_receipts_transaction ON receipts(transaction_id);
CREATE INDEX IF NOT EXISTS idx_receipts_number ON receipts(receipt_number);

-- Messages indexes
CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);

-- Questions/Tests indexes
CREATE INDEX IF NOT EXISTS idx_questions_school_id ON questions(school_id);
CREATE INDEX IF NOT EXISTS idx_questions_subject_class ON questions(subject, class);
CREATE INDEX IF NOT EXISTS idx_tests_school_id ON tests(school_id);
CREATE INDEX IF NOT EXISTS idx_tests_status ON tests(status);

-- Test Results indexes
CREATE INDEX IF NOT EXISTS idx_test_results_test_id ON test_results(test_id);
CREATE INDEX IF NOT EXISTS idx_test_results_student_id ON test_results(student_id);

-- Notifications indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);

-- Calendar indexes
CREATE INDEX IF NOT EXISTS idx_calendar_events_date ON calendar_events(event_date);
CREATE INDEX IF NOT EXISTS idx_calendar_events_type ON calendar_events(event_type);

-- ============================================
-- ENABLE ROW LEVEL SECURITY
-- ============================================

ALTER TABLE schools ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE activation_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE score_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE test_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE test_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE test_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance ENABLE ROW LEVEL SECURITY;
ALTER TABLE chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE parent_announcements ENABLE ROW LEVEL SECURITY;
 ALTER TABLE student_messages ENABLE ROW LEVEL SECURITY;
 ALTER TABLE stories ENABLE ROW LEVEL SECURITY;
 ALTER TABLE story_comments ENABLE ROW LEVEL SECURITY;
 ALTER TABLE story_interactions ENABLE ROW LEVEL SECURITY;
 ALTER TABLE story_submissions ENABLE ROW LEVEL SECURITY;
 ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE calendar_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE adverts ENABLE ROW LEVEL SECURITY;
ALTER TABLE timetable ENABLE ROW LEVEL SECURITY;
ALTER TABLE library_books ENABLE ROW LEVEL SECURITY;
ALTER TABLE homework ENABLE ROW LEVEL SECURITY;
ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- ============================================
-- ROW LEVEL SECURITY POLICIES
-- Multi-tenant data isolation
-- ============================================

-- Schools: Allow access to all (managed by Super Admin)
CREATE POLICY IF NOT EXISTS "schools_all_access" ON schools FOR ALL USING (true) WITH CHECK (true);

 -- Stories: Allow all access (public reading platform)
 CREATE POLICY IF NOT EXISTS "stories_all_access" ON stories FOR ALL USING (true) WITH CHECK (true);

 -- Story Comments: Allow all access
 CREATE POLICY IF NOT EXISTS "story_comments_all_access" ON story_comments FOR ALL USING (true) WITH CHECK (true);

 -- Story Interactions: Allow all access
 CREATE POLICY IF NOT EXISTS "story_interactions_all_access" ON story_interactions FOR ALL USING (true) WITH CHECK (true);

 -- Story Submissions: Allow all access
 CREATE POLICY IF NOT EXISTS "story_submissions_all_access" ON story_submissions FOR ALL USING (true) WITH CHECK (true);

-- Users: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "users_school_access" ON users FOR ALL USING (true) WITH CHECK (true);

-- Students: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "students_school_access" ON students FOR ALL USING (true) WITH CHECK (true);

-- Teachers: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "teachers_school_access" ON teachers FOR ALL USING (true) WITH CHECK (true);

-- Activation Codes: Allow all access
CREATE POLICY IF NOT EXISTS "activation_codes_all_access" ON activation_codes FOR ALL USING (true) WITH CHECK (true);

-- Attendance: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "attendance_school_access" ON attendance FOR ALL USING (true) WITH CHECK (true);

-- Staff Attendance: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "staff_attendance_school_access" ON staff_attendance FOR ALL USING (true) WITH CHECK (true);

-- Scores: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "scores_school_access" ON scores FOR ALL USING (true) WITH CHECK (true);

-- Score Sessions: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "score_sessions_school_access" ON score_sessions FOR ALL USING (true) WITH CHECK (true);

-- Questions: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "questions_school_access" ON questions FOR ALL USING (true) WITH CHECK (true);

-- Tests: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "tests_school_access" ON tests FOR ALL USING (true) WITH CHECK (true);

-- Test Questions: Allow access
CREATE POLICY IF NOT EXISTS "test_questions_all_access" ON test_questions FOR ALL USING (true) WITH CHECK (true);

-- Test Results: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "test_results_school_access" ON test_results FOR ALL USING (true) WITH CHECK (true);

-- Test Attempts: Allow access
CREATE POLICY IF NOT EXISTS "test_attempts_all_access" ON test_attempts FOR ALL USING (true) WITH CHECK (true);

-- Finance: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "finance_school_access" ON finance FOR ALL USING (true) WITH CHECK (true);

-- Chart of Accounts: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "chart_of_accounts_school_access" ON chart_of_accounts FOR ALL USING (true) WITH CHECK (true);

-- Budgets: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "budgets_school_access" ON budgets FOR ALL USING (true) WITH CHECK (true);

-- Accounts Receivable: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "accounts_receivable_school_access" ON accounts_receivable FOR ALL USING (true) WITH CHECK (true);

-- Tax Settings: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "tax_settings_school_access" ON tax_settings FOR ALL USING (true) WITH CHECK (true);

-- Financial Attachments: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "financial_attachments_school_access" ON financial_attachments FOR ALL USING (true) WITH CHECK (true);

-- Receipts: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "receipts_school_access" ON receipts FOR ALL USING (true) WITH CHECK (true);

-- Chats: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "chats_school_access" ON chats FOR ALL USING (true) WITH CHECK (true);

-- Messages: Allow access
CREATE POLICY IF NOT EXISTS "messages_all_access" ON messages FOR ALL USING (true) WITH CHECK (true);

-- Parent Announcements: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "parent_announcements_school_access" ON parent_announcements FOR ALL USING (true) WITH CHECK (true);

-- Student Messages: Allow access
CREATE POLICY IF NOT EXISTS "student_messages_all_access" ON student_messages FOR ALL USING (true) WITH CHECK (true);

-- Notifications: Allow access based on user_id
CREATE POLICY IF NOT EXISTS "notifications_user_access" ON notifications FOR ALL USING (true) WITH CHECK (true);

-- Calendar Events: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "calendar_events_school_access" ON calendar_events FOR ALL USING (true) WITH CHECK (true);

-- Adverts: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "adverts_school_access" ON adverts FOR ALL USING (true) WITH CHECK (true);

-- Timetable: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "timetable_school_access" ON timetable FOR ALL USING (true) WITH CHECK (true);

-- Library Books: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "library_books_school_access" ON library_books FOR ALL USING (true) WITH CHECK (true);

-- Homework: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "homework_school_access" ON homework FOR ALL USING (true) WITH CHECK (true);

-- Exams: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "exams_school_access" ON exams FOR ALL USING (true) WITH CHECK (true);

-- Exam Questions: Allow access
CREATE POLICY IF NOT EXISTS "exam_questions_all_access" ON exam_questions FOR ALL USING (true) WITH CHECK (true);

-- Exam Results: Allow access based on school_id
CREATE POLICY IF NOT EXISTS "exam_results_school_access" ON exam_results FOR ALL USING (true) WITH CHECK (true);

-- Sync Log: Allow all access (for tracking)
CREATE POLICY IF NOT EXISTS "sync_log_all_access" ON sync_log FOR ALL USING (true) WITH CHECK (true);

-- Audit Log: Allow all access (for tracking)
CREATE POLICY IF NOT EXISTS "audit_log_all_access" ON audit_log FOR ALL USING (true) WITH CHECK (true);

-- ============================================
-- SUPER ADMIN GLOBAL TABLES RLS POLICIES
-- ============================================

-- System Config: Allow all access (single global row)
CREATE POLICY IF NOT EXISTS "system_config_all_access" ON system_config FOR ALL USING (true) WITH CHECK (true);

-- Blog Posts: Allow public read, authenticated write
CREATE POLICY IF NOT EXISTS "blog_posts_all_access" ON blog_posts FOR ALL USING (true) WITH CHECK (true);

-- Resources: Allow public read, authenticated write
CREATE POLICY IF NOT EXISTS "resources_all_access" ON resources FOR ALL USING (true) WITH CHECK (true);

-- Pricing Plans: Allow public read, authenticated write
CREATE POLICY IF NOT EXISTS "pricing_plans_all_access" ON pricing_plans FOR ALL USING (true) WITH CHECK (true);

-- Static Pages: Allow public read, authenticated write
CREATE POLICY IF NOT EXISTS "static_pages_all_access" ON static_pages FOR ALL USING (true) WITH CHECK (true);

-- ============================================
-- FINAL VERIFICATION
-- ============================================
SELECT 
    'Schema created successfully!' as status,
    (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public') as total_tables;

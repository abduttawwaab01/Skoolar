const StudentLibrary = {
    currentTab: 'browse',

    init() {
        this.showTab('browse');
    },

    showTab(tab) {
        this.currentTab = tab;
        
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.tab === tab) btn.classList.add('active');
        });
        
        // Update tab content
        document.getElementById('libraryBrowseTab').style.display = tab === 'browse' ? 'block' : 'none';
        document.getElementById('libraryMyBooksTab').style.display = tab === 'mybooks' ? 'block' : 'none';
        
        if (tab === 'browse') {
            this.loadBrowseBooks();
        } else if (tab === 'mybooks') {
            this.loadMyBooks();
        }
    },

    getCurrentStudent() {
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentStudent) {
            return StudentAuth.getCurrentStudent();
        }
        return null;
    },

    getCurrentSchoolId() {
        if (typeof StudentAuth !== 'undefined' && StudentAuth.getCurrentSchoolId) {
            return StudentAuth.getCurrentSchoolId();
        }
        return null;
    },

    loadBrowseBooks() {
        const schoolId = this.getCurrentSchoolId();
        if (!schoolId) {
            this.showError('School not found');
            return;
        }
        
        const search = document.getElementById('librarySearch')?.value || '';
        const category = document.getElementById('libraryCategory')?.value || '';
        
        const books = Storage.getLibraryBooks(schoolId, search, category);
        this.renderBooksGrid(books);
        this.loadCategories(books);
    },

    loadCategories(books) {
        const categorySelect = document.getElementById('libraryCategory');
        if (!categorySelect) return;
        
        const categories = [...new Set(books.map(b => b.category).filter(Boolean))].sort();
        const currentValue = categorySelect.value;
        
        categorySelect.innerHTML = '<option value="">All Categories</option>';
        categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            categorySelect.appendChild(option);
        });
        
        // Restore selection if still valid
        if (currentValue && categories.includes(currentValue)) {
            categorySelect.value = currentValue;
        }
    },

    renderBooksGrid(books) {
        const container = document.getElementById('libraryBooksGrid');
        if (!container) return;
        
        if (books.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-book-open"></i>
                    <p>No books found</p>
                </div>
            `;
            return;
        }
        
        let html = '<div class="books-grid-container">';
        books.forEach(book => {
            const isAvailable = book.available > 0;
            const coverColor = this.getBookCoverColor(book.title || book.isbn);
            const initials = this.getBookInitials(book.title);
            
            html += `
                <div class="book-card ${isAvailable ? '' : 'unavailable'}">
                    <div class="book-cover" style="background: ${coverColor};">
                        <span class="book-initials">${initials}</span>
                    </div>
                    <div class="book-info">
                        <h4 class="book-title">${book.title || 'Untitled'}</h4>
                        <p class="book-author">by ${book.author || 'Unknown'}</p>
                        <p class="book-category">${book.category || 'Uncategorized'}</p>
                        <p class="book-availability">
                            <i class="fas fa-${isAvailable ? 'check-circle' : 'times-circle'}"></i>
                            ${isAvailable ? `${book.available} available` : 'Not available'}
                        </p>
                        <button class="btn btn-sm ${isAvailable ? 'btn-primary' : 'btn-secondary'}" 
                                style="width: 100%; margin-top: 8px;"
                                onclick="StudentLibrary.borrowBook('${book.id}')"
                                ${!isAvailable ? 'disabled' : ''}>
                            ${isAvailable ? 'Borrow' : 'Unavailable'}
                        </button>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        
        container.innerHTML = html;
    },

    getBookCoverColor(titleOrIsbn) {
        const colors = [
            'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
            'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
            'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
            'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
            'linear-gradient(135deg, #30cfd0 0%, #330867 100%)',
            'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
            'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
            'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)',
            'linear-gradient(135deg, #a1c4fd 0%, #c2e9fb 100%)'
        ];
        
        const seed = titleOrIsbn ? titleOrIsbn.charCodeAt(0) : 0;
        return colors[seed % colors.length];
    },

    getBookInitials(title) {
        if (!title) return '?';
        const words = title.trim().split(' ');
        if (words.length === 1) {
            return words[0].substring(0, 2).toUpperCase();
        }
        return (words[0][0] + words[words.length - 1][0]).toUpperCase();
    },

    searchBooks() {
        this.loadBrowseBooks();
    },

    borrowBook(bookId) {
        const student = this.getCurrentStudent();
        const schoolId = this.getCurrentSchoolId();
        
        if (!student || !schoolId) {
            Toast.error('Authentication error');
            return;
        }
        
        Modal.confirm({
            title: 'Borrow Book',
            message: 'Are you sure you want to borrow this book? You will be responsible for any overdue fines.',
            onConfirm: () => {
                try {
                    Storage.borrowBook(bookId, student.id, student.name, schoolId);
                    Toast.success('Book borrowed successfully!');
                    this.loadBrowseBooks();
                    this.loadMyBooks(); // Refresh my books if tab is open
                } catch (error) {
                    Toast.error('Failed to borrow book: ' + error.message);
                }
            }
        });
    },

    loadMyBooks() {
        const student = this.getCurrentStudent();
        const schoolId = this.getCurrentSchoolId();
        
        if (!student || !schoolId) {
            this.showError('Student not found');
            return;
        }
        
        const loans = Storage.getStudentLoans(student.id, schoolId);
        this.renderMyBooksTable(loans);
    },

    renderMyBooksTable(loans) {
        const tbody = document.getElementById('libraryMyBooksTable');
        if (!tbody) return;
        
        if (loans.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center">
                        <div class="empty-state">
                            <i class="fas fa-book-reader"></i>
                            <p>You haven't borrowed any books yet.</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }
        
        const today = new Date().toISOString().split('T')[0];
        
        let html = '';
        loans.forEach(loan => {
            const book = Storage.getData('library_books')?.find(b => b.id === loan.bookId);
            const dueDate = new Date(loan.dueDate).toLocaleDateString();
            const isOverdue = loan.status === 'borrowed' && loan.dueDate < today;
            const statusClass = loan.status === 'returned' ? 'success' : (isOverdue ? 'danger' : 'warning');
            const statusLabel = loan.status === 'returned' ? 'Returned' : (isOverdue ? 'Overdue' : 'Borrowed');
            
            html += `
                <tr style="${isOverdue ? 'background: var(--danger-light);' : ''}">
                    <td>
                        <strong>${book?.title || 'Unknown Book'}</strong>
                        <br><small class="text-muted">${book?.author || ''}</small>
                    </td>
                    <td>${new Date(loan.checkoutDate).toLocaleDateString()}</td>
                    <td>${dueDate} ${isOverdue ? '<br><small class="text-danger">Overdue!</small>' : ''}</td>
                    <td><span class="badge badge-${statusClass}">${statusLabel}</span></td>
                    <td>${loan.fineAmount > 0 ? '₦' + loan.fineAmount.toFixed(2) : '₦0.00'}</td>
                    <td>
                        ${loan.status === 'borrowed' ? `
                            <button class="btn btn-sm btn-success" onclick="StudentLibrary.returnBook('${loan.id}')">
                                Return
                            </button>
                        ` : '<span class="text-muted">-</span>'}
                    </td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
    },

    returnBook(loanId) {
        Modal.confirm({
            title: 'Return Book',
            message: 'Are you sure you want to return this book?',
            onConfirm: () => {
                try {
                    const loan = Storage.returnBook(loanId);
                    const fine = loan.fineAmount;
                    
                    if (fine > 0) {
                        Toast.success(`Book returned. Fine: ₦${fine.toFixed(2)}`);
                    } else {
                        Toast.success('Book returned successfully!');
                    }
                    
                    this.loadMyBooks();
                    this.loadBrowseBooks(); // Refresh browse tab availability
                } catch (error) {
                    Toast.error('Failed to return book: ' + error.message);
                }
            }
        });
    },

    showError(message) {
        // Show error in both tabs
        const browseContainer = document.getElementById('libraryBooksGrid');
        const myBooksContainer = document.getElementById('libraryMyBooksTable');
        
        if (browseContainer) {
            browseContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>${message}</p>
                </div>
            `;
        }
        if (myBooksContainer) {
            myBooksContainer.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger">
                        <p>${message}</p>
                    </td>
                </tr>
            `;
        }
    }
};

window.StudentLibrary = StudentLibrary;

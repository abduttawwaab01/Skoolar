const Accounting = {
    schoolId: null,
    chartOfAccounts: [],

    init() {
        this.schoolId = Auth.getCurrentSchoolId();
        this.loadChartOfAccounts();
        this.setupEventListeners();
        this.populateStudentSelect();

        // Populate account select when modal is shown
        const modal = document.getElementById('addTransactionModal');
        if (modal) {
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                        if (modal.classList.contains('active')) {
                            this.populateAccountSelect();
                            // Set default date to today
                            const dateInput = document.querySelector('#transactionForm input[name="date"]');
                            if (dateInput && !dateInput.value) {
                                dateInput.value = new Date().toISOString().split('T')[0];
                            }
                        }
                    }
                });
            });
            observer.observe(modal, { attributes: true });
        }

        // Smart account selection when student is chosen
        const studentSelect = document.getElementById('studentSelect');
        if (studentSelect) {
            studentSelect.addEventListener('change', (e) => {
                if (e.target.value) {
                    // Student selected, default to Tuition Fees account
                    const accountSelect = document.getElementById('accountSelect');
                    const tuitionAccount = this.chartOfAccounts.find(acc => acc.account_code === '4000');
                    if (tuitionAccount && accountSelect) {
                        accountSelect.value = tuitionAccount.id;
                    }
                }
            });
        }
    },

    setupEventListeners() {
        // Listen for section changes to load appropriate data
        document.addEventListener('sectionChange', (e) => {
            if (e.detail.section === 'chart-of-accounts') {
                this.renderChartOfAccounts();
            } else if (e.detail.section === 'budgets') {
                this.renderBudgets();
            } else if (e.detail.section === 'accounts-receivable') {
                this.renderAccountsReceivable();
            } else if (e.detail.section === 'tax-settings') {
                this.renderTaxSettings();
            }
        });
    },

    // Populate the account select dropdown in the transaction form
    populateAccountSelect() {
        const select = document.getElementById('accountSelect');
        if (!select) return;
        this.populateAccountDropdown(select, '', true);
    },

    // Populate student select dropdown
    populateStudentSelect() {
        const select = document.getElementById('studentSelect');
        if (!select) return;

        const students = Storage.getStudents(this.schoolId);
        select.innerHTML = '<option value="">-- Not linked --</option>';

        students.forEach(s => {
            const option = document.createElement('option');
            option.value = s.id;
            option.textContent = `${s.name} (${s.student_id || s.id}) - ${s.class || 'No class'}`;
            select.appendChild(option);
        });
    },

    // Toggle tax fields visibility based on transaction type
    toggleTax(type) {
        const taxRow = document.getElementById('taxAmountRow');
        const taxCheckbox = document.getElementById('applyTaxCheck');
        const taxRateDisplay = document.getElementById('taxRateDisplay');
        const accountSelect = document.getElementById('accountSelect');
        const selectedAccountId = accountSelect?.value;

        const settings = Storage.getTaxSettings(this.schoolId);
        if (settings.length === 0) {
            taxRow.style.display = 'none';
            taxCheckbox.checked = false;
            taxRateDisplay.textContent = '0%';
            return;
        }

        // Find applicable tax based on selected account
        let applicableTax = null;

        if (selectedAccountId && type === 'income') {
            const account = this.getAccountById(selectedAccountId);
            if (account) {
                applicableTax = settings.find(t => {
                    if (t.applies_to_categories.length === 0) return true;
                    return t.applies_to_categories.some(cat => 
                        account.account_name.toLowerCase().includes(cat.toLowerCase()) ||
                        cat.toLowerCase().includes(account.account_name.toLowerCase())
                    );
                });
            }
        }

        // Fallback: if no match but rules exist, use first rule
        if (!applicableTax && settings.length > 0) {
            applicableTax = settings[0];
        }

        if (applicableTax) {
            taxRateDisplay.textContent = applicableTax.tax_rate + '%';
            taxRow.style.display = 'grid';
        } else {
            taxRow.style.display = 'none';
            taxCheckbox.checked = false;
            taxRateDisplay.textContent = '0%';
        }
    },

    // Toggle tax amount calculation
    toggleTaxAmount() {
        const checkbox = document.getElementById('applyTaxCheck');
        const taxAmountInput = document.getElementById('taxAmount');
        const totalAmountInput = document.getElementById('totalAmount');
        const netAmountInput = document.getElementById('netAmount');

        if (checkbox.checked) {
            const netAmount = parseFloat(netAmountInput.value) || 0;
            // Find applicable tax based on current account selection
            const accountSelect = document.getElementById('accountSelect');
            const accountId = accountSelect?.value;
            const account = this.getAccountById(accountId);
            const settings = Storage.getTaxSettings(this.schoolId);
            
            let tax = null;
            if (account && settings.length > 0) {
                tax = settings.find(t => {
                    if (t.applies_to_categories.length === 0) return true;
                    return t.applies_to_categories.some(cat => 
                        account.account_name.toLowerCase().includes(cat.toLowerCase()) ||
                        cat.toLowerCase().includes(account.account_name.toLowerCase())
                    );
                }) || settings[0];
            }

            if (tax) {
                const taxAmt = this.calculateTaxAmount(netAmount, tax);
                taxAmountInput.value = taxAmt.toFixed(2);
                totalAmountInput.value = (netAmount + taxAmt).toFixed(2);
            }
        } else {
            taxAmountInput.value = '';
            const netAmount = parseFloat(netAmountInput.value) || 0;
            totalAmountInput.value = netAmount.toFixed(2);
        }
    },

    // Add transaction with enhanced features
    addTransaction(formData) {
        const {
            type,
            amount: netAmount,
            description,
            account_id,
            date,
            payment_method,
            reference_number,
            student_id,
            tax_amount,
            attachment
        } = formData;

        if (!account_id || !netAmount || !description) {
            Toast.error('Please fill all required fields');
            return;
        }

        const parsedNetAmount = parseFloat(netAmount);
        const parsedTaxAmount = tax_amount ? parseFloat(tax_amount) : 0;
        const totalAmount = parsedNetAmount + parsedTaxAmount;

        // Get schoolId early for validation
        const schoolId = this.schoolId;

        // Large transaction alert (over ₦500,000)
        const LARGE_TRANSACTION_THRESHOLD = 500000;
        if (totalAmount >= LARGE_TRANSACTION_THRESHOLD) {
            const confirmLarge = confirm(`⚠️ Large Transaction Alert!\n\nYou are about to record ₦${totalAmount.toLocaleString()}.\n\nAre you sure you want to proceed?`);
            if (!confirmLarge) {
                Toast.info('Transaction cancelled');
                return;
            }
        }

        // Duplicate detection - check for similar transaction in last 24 hours
        const existingTransactions = Storage.getFinance(schoolId);
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        
        const duplicate = existingTransactions.find(t => {
            const tDate = new Date(t.date);
            return t.type === type && 
                   t.amount === totalAmount && 
                   t.description.toLowerCase() === description.toLowerCase() &&
                   tDate >= yesterday;
        });
        
        if (duplicate) {
            const confirmDuplicate = confirm(`⚠️ Possible Duplicate Transaction!\n\nA similar transaction was found:\n- Date: ${duplicate.date}\n- Amount: ₦${duplicate.amount.toLocaleString()}\n- Description: ${duplicate.description}\n\nDo you want to proceed anyway?`);
            if (!confirmDuplicate) {
                Toast.info('Transaction cancelled');
                return;
            }
        }

        // Get account info
        const account = this.getAccountById(account_id);
        if (!account) {
            Toast.error('Invalid account selected');
            return;
        }

        const user = Auth.getCurrentUser();

        // Auto-generate reference number if not provided
        const refNumber = reference_number || `TRX-${new Date().getFullYear()}-${Storage.generateId().slice(-6).toUpperCase()}`;

        // Create transaction
        const transaction = {
            id: Storage.generateId(),
            school_id: schoolId,
            type,
            category: account.account_name,
            account_id: account_id,
            amount: totalAmount,
            tax_amount: parsedTaxAmount,
            description,
            payment_method: payment_method || 'cash',
            reference_number: refNumber,
            related_student_id: student_id || null,
            term: this.getCurrentTerm(),
            year: new Date().getFullYear(),
            date: date || new Date().toISOString().split('T')[0],
            created_by: user.id,
            created_by_name: user.name,
            created_at: new Date().toISOString()
        };

        Storage.addItem('finance', transaction);

        // Note: Student-linked transactions do NOT auto-create AR invoices.
        // AR invoices should be created manually in the Accounts Receivable section.
        // When a payment is recorded against an AR, a corresponding transaction is created automatically.

        // Handle attachment
        if (attachment && attachment.size > 0) {
            this.uploadAttachment(transaction.id, attachment);
        }

        // Update budget actual amount
        this.updateBudgetActual(transaction);

        // Log activity
        Auth.logActivity(user.id, 'finance', `Added ${type}: ${Utils.formatCurrency(totalAmount)} - ${description}`);
        Auth.addNotification(user.id, `Transaction added: ${description}`, 'finance');

        if (typeof Storage.logAudit === 'function') {
            Storage.logAudit(user.id, schoolId, 'CREATE', 'finance', transaction.id, null, transaction);
        }

        Toast.success('Transaction added successfully');
        Modal.hide('addTransactionModal');
        Finance.loadDashboard();

        // Reset form explicitly
        document.getElementById('transactionForm').reset();
        document.getElementById('taxAmountRow').style.display = 'none';
        document.getElementById('totalAmount').value = '';
    },

    createOrUpdateReceivableFromTransaction(transaction, studentId) {
        const student = Storage.getItemById('students', studentId);
        if (!student) return;

        // Check if an AR already exists for this student + fee type (using description as proxy)
        const existingAr = Storage.getAccountsReceivable(this.schoolId).find(ar => 
            ar.student_id === studentId && 
            ar.fee_type === transaction.category &&
            ar.status !== 'paid'
        );

        if (existingAr) {
            // Add payment to existing AR
            Storage.recordPaymentToReceivable(existingAr.id, transaction.amount, transaction.date);
        } else {
            // Create new AR (invoice)
            const ar = {
                id: Storage.generateId(),
                school_id: this.schoolId,
                student_id: studentId,
                student_name: student.name,
                guardian_name: student.guardian_name,
                guardian_phone: student.guardian_phone,
                invoice_number: `INV-${new Date().getFullYear()}-${Storage.generateId().slice(-6).toUpperCase()}`,
                fee_type: transaction.category,
                amount: transaction.amount,
                paid_amount: 0,
                due_date: transaction.date,
                status: 'pending',
                description: transaction.description,
                created_by: transaction.created_by,
                created_at: new Date().toISOString()
            };
            Storage.addItem('accounts_receivable', ar);
        }
    },

    uploadAttachment(transactionId, file) {
        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            Toast.error('File size exceeds 5MB limit');
            return;
        }

        // Simple approach: read as DataURL and store in financial_attachments
        const reader = new FileReader();
        reader.onload = (e) => {
            const attachment = {
                id: Storage.generateId(),
                transaction_id: transactionId,
                school_id: this.schoolId,
                file_name: file.name,
                file_type: file.type,
                file_size: file.size,
                file_url: e.target.result, // base64 data URL
                uploaded_by: Auth.getCurrentUser().id,
                uploaded_at: new Date().toISOString()
            };
            Storage.addItem('financial_attachments', attachment);
            Toast.success('Attachment uploaded');
        };
        reader.onerror = () => {
            Toast.error('Failed to read file');
        };
        reader.readAsDataURL(file);
    },

    // ========================================
    // CHART OF ACCOUNTS
    // ========================================
    loadChartOfAccounts() {
        this.chartOfAccounts = Storage.getChartOfAccounts(this.schoolId);
    },

    getAccountsByType(type) {
        return this.chartOfAccounts.filter(acc => acc.account_type === type);
    },

    getAccountById(id) {
        return this.chartOfAccounts.find(acc => acc.id === id);
    },

    getAccountByCode(code) {
        return this.chartOfAccounts.find(acc => acc.account_code === code);
    },

    renderChartOfAccounts() {
        const container = document.getElementById('chartOfAccountsList');
        if (!container) return;

        const grouped = {};
        const order = ['asset', 'liability', 'equity', 'income', 'expense'];

        this.chartOfAccounts.forEach(acc => {
            if (!grouped[acc.account_type]) grouped[acc.account_type] = [];
            grouped[acc.account_type].push(acc);
        });

        let html = '<div class="table-container"><table class="table"><thead><tr>';
        html += '<th>Code</th><th>Account Name</th><th>Type</th><th>Sub-Type</th><th>Actions</th>';
        html += '</tr></thead><tbody>';

        order.forEach(type => {
            if (grouped[type]) {
                grouped[type].forEach(acc => {
                    html += `
                        <tr>
                            <td><strong>${acc.account_code}</strong></td>
                            <td>${acc.account_name}</td>
                            <td>${this.formatAccountType(acc.account_type)}</td>
                            <td>${acc.sub_type || '-'}</td>
                            <td>
                                <button class="btn btn-outline btn-sm" onclick="Accounting.editAccount('${acc.id}')">Edit</button>
                                ${!acc.is_default ? `<button class="btn btn-danger btn-sm" onclick="Accounting.deleteAccount('${acc.id}')">Delete</button>` : ''}
                            </td>
                        </tr>
                    `;
                });
            }
        });

        html += '</tbody></table></div>';
        container.innerHTML = html;
    },

     formatAccountType(type) {
        const types = {
            asset: 'Asset',
            liability: 'Liability',
            equity: 'Equity',
            income: 'Income',
            expense: 'Expense'
        };
        return types[type] || type;
    },

    editAccount(accountId) {
        const account = this.getAccountById(accountId);
        if (!account) return;

        if (account.is_default) {
            Toast.error('Cannot edit default accounts');
            return;
        }

        const modalHtml = `
            <div id="editAccountModal" class="modal-overlay">
                <div class="modal" style="max-width: 500px;">
                    <div class="modal-header">
                        <h3 class="modal-title">Edit Account</h3>
                        <button class="modal-close" onclick="Modal.hide('editAccountModal')"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <form id="editAccountForm">
                            <div class="form-group">
                                <label class="form-label">Account Code</label>
                                <input type="text" name="account_code" class="form-control" value="${account.account_code}" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Account Name</label>
                                <input type="text" name="account_name" class="form-control" value="${account.account_name}" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Account Type</label>
                                <select name="account_type" class="form-control" required>
                                    <option value="asset" ${account.account_type === 'asset' ? 'selected' : ''}>Asset</option>
                                    <option value="liability" ${account.account_type === 'liability' ? 'selected' : ''}>Liability</option>
                                    <option value="equity" ${account.account_type === 'equity' ? 'selected' : ''}>Equity</option>
                                    <option value="income" ${account.account_type === 'income' ? 'selected' : ''}>Income</option>
                                    <option value="expense" ${account.account_type === 'expense' ? 'selected' : ''}>Expense</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Sub-Type</label>
                                <input type="text" name="sub_type" class="form-control" value="${account.sub_type || ''}">
                            </div>
                            <div class="form-group">
                                <label class="form-check">
                                    <input type="checkbox" name="is_active" ${account.is_active ? 'checked' : ''}> Active
                                </label>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" onclick="Modal.hide('editAccountModal')">Cancel</button>
                        <button class="btn btn-primary" onclick="Accounting.saveAccount('${accountId}')">Save</button>
                    </div>
                </div>
            </div>
        `;

        Modal.showCustom(modalHtml);
    },

    saveAccount(accountId) {
        const data = Form.getData('editAccountForm');
        if (!data.account_code || !data.account_name || !data.account_type) {
            Toast.error('Please fill required fields');
            return;
        }

        const updates = {
            account_code: data.account_code,
            account_name: data.account_name,
            account_type: data.account_type,
            sub_type: data.sub_type || '',
            is_active: data.is_active || false
        };

        // Check for duplicate code
        const existing = this.chartOfAccounts.find(a => a.account_code === data.account_code && a.id !== accountId);
        if (existing) {
            Toast.error('Account code already exists');
            return;
        }

        Storage.updateChartOfAccount(accountId, updates);
        Toast.success('Account updated');
        Modal.hide('editAccountModal');
        this.loadChartOfAccounts();
    },

    deleteAccount(accountId) {
        const account = this.getAccountById(accountId);
        if (!account) return;

        if (account.is_default) {
            Toast.error('Cannot delete default accounts');
            return;
        }

        // Check if account is used in transactions
        const transactions = Storage.getFinance(this.schoolId).filter(t => t.account_id === accountId);
        if (transactions.length > 0) {
            Toast.error(`Cannot delete account used in ${transactions.length} transaction(s). Deactivate instead.`);
            return;
        }

        Modal.confirm({
            title: 'Delete Account',
            message: `Delete account "${account.account_name}"? This cannot be undone.`,
            onConfirm: () => {
                Storage.deleteChartOfAccount(accountId);
                Toast.success('Account deleted');
                this.loadChartOfAccounts();
            }
        });
    },

    populateAccountDropdown(selectElement, selectedAccountId = '', includeCategoryOption = false) {
        // Clear existing options except first if any
        selectElement.innerHTML = '';

        if (includeCategoryOption) {
            const opt = document.createElement('option');
            opt.value = '';
            opt.textContent = '-- Select Account --';
            selectElement.appendChild(opt);
        }

        const order = ['asset', 'liability', 'equity', 'income', 'expense'];
        let defaultAccount = '';

        order.forEach(type => {
            const accounts = this.chartOfAccounts.filter(acc => acc.account_type === type);
            if (accounts.length > 0) {
                const optgroup = document.createElement('optgroup');
                optgroup.label = this.formatAccountType(type);
                accounts.forEach(acc => {
                    const option = document.createElement('option');
                    option.value = acc.id;
                    option.textContent = `${acc.account_code} - ${acc.account_name}`;
                    if (acc.id === selectedAccountId) option.selected = true;
                    optgroup.appendChild(option);
                });
                selectElement.appendChild(optgroup);
            }
        });
    },

    // ========================================
    // BUDGETS
    // ========================================
    renderBudgets() {
        const container = document.getElementById('budgetsList');
        if (!container) return;

        const currentYear = new Date().getFullYear();
        const currentTerm = this.getCurrentTerm();
        const academicYear = `${currentYear}/${currentYear + 1}`;
        const budgets = Storage.getBudgets(this.schoolId, academicYear, currentTerm);

        if (budgets.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-chart-line"></i>
                    <h3>No Budgets Set</h3>
                    <p>Set up your first budget for this term.</p>
                    <button class="btn btn-primary mt-2" onclick="Accounting.showBudgetModal()">Set Budget</button>
                </div>
            `;
            return;
        }

        // Group by category and calculate totals
        const grouped = {};
        budgets.forEach(b => {
            const key = b.category + (b.subcategory ? ' > ' + b.subcategory : '');
            if (!grouped[key]) {
                grouped[key] = {
                    allocated: 0,
                    actual: 0,
                    category: b.category,
                    subcategory: b.subcategory
                };
            }
            grouped[key].allocated += b.allocated_amount;
            grouped[key].actual += b.actual_amount;
        });

        let html = '<div class="table-container"><table class="table"><thead><tr>';
        html += '<th>Category</th><th>Allocated</th><th>Actual</th><th>Variance</th><th>% Used</th><th>Actions</th>';
        html += '</tr></thead><tbody>';

        Object.values(grouped).forEach(g => {
            const variance = g.allocated - g.actual;
            const percentUsed = g.allocated > 0 ? (g.actual / g.allocated * 100).toFixed(1) : 0;
            const varianceClass = variance >= 0 ? 'text-success' : 'text-danger';
            const percentClass = percentUsed > 90 ? 'text-warning' : '';

            html += `
                <tr>
                    <td>${g.subcategory ? g.category + ' > ' + g.subcategory : g.category}</td>
                    <td>${Utils.formatCurrency(g.allocated)}</td>
                    <td>${Utils.formatCurrency(g.actual)}</td>
                    <td class="${varianceClass}">${Utils.formatCurrency(variance)}</td>
                    <td class="${percentClass}">${percentUsed}%</td>
                    <td>
                        <button class="btn btn-outline btn-sm" onclick="Accounting.showBudgetModal('${g.category}', '${g.subcategory || ''}')">Edit</button>
                    </td>
                </tr>
            `;
        });

        html += '</tbody></table></div>';
        container.innerHTML = html;
    },

    getCurrentTerm() {
        const month = new Date().getMonth() + 1;
        if (month >= 9 && month <= 11) return 'First';
        if (month >= 12 || month <= 3) return 'Second';
        return 'Third';
    },

    showBudgetModal(category = '', subcategory = '') {
        const modalHtml = `
            <div id="budgetModal" class="modal-overlay">
                <div class="modal" style="max-width: 500px;">
                    <div class="modal-header">
                        <h3 class="modal-title">${category ? 'Edit Budget' : 'Set Budget'}</h3>
                        <button class="modal-close" onclick="Modal.hide('budgetModal')"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <form id="budgetForm">
                            <div class="form-group">
                                <label class="form-label">Category</label>
                                <select name="category" class="form-control" required>
                                    <option value="">Select Category</option>
                                    <option value="Tuition Fees" ${category === 'Tuition Fees' ? 'selected' : ''}>Tuition Fees</option>
                                    <option value="Registration Fees" ${category === 'Registration Fees' ? 'selected' : ''}>Registration Fees</option>
                                    <option value="Salaries" ${category === 'Salaries' ? 'selected' : ''}>Salaries</option>
                                    <option value="Utilities" ${category === 'Utilities' ? 'selected' : ''}>Utilities</option>
                                    <option value="Maintenance" ${category === 'Maintenance' ? 'selected' : ''}>Maintenance</option>
                                    <option value="Supplies" ${category === 'Supplies' ? 'selected' : ''}>Supplies</option>
                                    <option value="Transportation" ${category === 'Transportation' ? 'selected' : ''}>Transportation</option>
                                    <option value="Rent" ${category === 'Rent' ? 'selected' : ''}>Rent</option>
                                    <option value="Donations" ${category === 'Donations' ? 'selected' : ''}>Donations</option>
                                    <option value="Other Income" ${category === 'Other Income' ? 'selected' : ''}>Other Income</option>
                                    <option value="Other Expense" ${category === 'Other Expense' ? 'selected' : ''}>Other Expense</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Subcategory (optional)</label>
                                <input type="text" name="subcategory" class="form-control" value="${subcategory}" placeholder="e.g., Electricity, Water">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Allocated Amount</label>
                                <input type="number" name="allocated_amount" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Period</label>
                                <select name="period_type" class="form-control">
                                    <option value="termly">Termly</option>
                                    <option value="monthly">Monthly</option>
                                    <option value="annual">Annual</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="2"></textarea>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" onclick="Modal.hide('budgetModal')">Cancel</button>
                        <button class="btn btn-primary" onclick="Accounting.saveBudget()">Save</button>
                    </div>
                </div>
            </div>
        `;

        Modal.showCustom(modalHtml);
    },

    saveBudget() {
        const data = Form.getData('budgetForm');
        if (!data.category || !data.allocated_amount) {
            Toast.error('Please fill required fields');
            return;
        }

        const currentYear = new Date().getFullYear();
        const term = this.getCurrentTerm();
        const academicYear = `${currentYear}/${currentYear + 1}`;

        const budget = {
            id: Storage.generateId(),
            school_id: this.schoolId,
            academic_year: academicYear,
            term: term,
            category: data.category,
            subcategory: data.subcategory || null,
            period_type: data.period_type || 'termly',
            allocated_amount: parseFloat(data.allocated_amount),
            actual_amount: 0,
            notes: data.notes || '',
            created_by: Auth.getCurrentUser()?.id,
            created_at: new Date().toISOString()
        };

        Storage.addItem('budgets', budget);
        Toast.success('Budget saved successfully');
        Modal.hide('budgetModal');
        this.renderBudgets();
    },

    // ========================================
    // ACCOUNTS RECEIVABLE (Student Fees)
    // ========================================
    renderAccountsReceivable(filterStatus = '') {
        const container = document.getElementById('accountsReceivableList');
        if (!container) return;

        let ar = Storage.getAccountsReceivable(this.schoolId);
        if (filterStatus) {
            ar = ar.filter(a => a.status === filterStatus);
        }

        // Sort by due date (overdue first)
        ar.sort((a, b) => new Date(a.due_date) - new Date(b.due_date));

        if (ar.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <h3>No Receivables</h3>
                    <p>All accounts are settled!</p>
                </div>
            `;
            return;
        }

        // Summary stats
        const total = ar.reduce((sum, a) => sum + a.amount, 0);
        const totalPaid = ar.reduce((sum, a) => sum + (a.paid_amount || 0), 0);
        const totalOutstanding = total - totalPaid;

        let html = `
            <div class="stats-grid mb-3">
                <div class="stat-card">
                    <div class="stat-label">Total Invoices</div>
                    <div class="stat-value">${ar.length}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Total Amount</div>
                    <div class="stat-value">${Utils.formatCurrency(total)}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Outstanding</div>
                    <div class="stat-value text-danger">${Utils.formatCurrency(totalOutstanding)}</div>
                </div>
            </div>
            <div class="table-container"><table class="table"><thead><tr>
                <th>Invoice #</th>
                <th>Student</th>
                <th>Guardian</th>
                <th>Fee Type</th>
                <th>Amount</th>
                <th>Paid</th>
                <th>Due Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr></thead><tbody>
        `;

        ar.forEach(item => {
            const outstanding = item.amount - (item.paid_amount || 0);
            const isOverdue = new Date(item.due_date) < new Date() && item.status !== 'paid';
            const statusClass = {
                pending: 'text-warning',
                partial: 'text-info',
                paid: 'text-success',
                overdue: 'text-danger',
                waived: 'text-muted'
            }[item.status] || '';

            html += `
                <tr class="${isOverdue ? 'table-danger' : ''}">
                    <td><strong>${item.invoice_number || '-'}</strong></td>
                    <td>${item.student_name}</td>
                    <td>${item.guardian_name || '-'}<br><small>${item.guardian_phone || ''}</small></td>
                    <td>${item.fee_type}</td>
                    <td>${Utils.formatCurrency(item.amount)}</td>
                    <td>${Utils.formatCurrency(item.paid_amount || 0)}</td>
                    <td>${Utils.formatDate(item.due_date)}</td>
                    <td class="${statusClass}"><strong>${item.status.toUpperCase()}</strong></td>
                    <td>
                        <button class="btn btn-success btn-sm" onclick="Accounting.recordPayment('${item.id}')">Pay</button>
                        ${item.status !== 'paid' ? `<button class="btn btn-danger btn-sm" onclick="Accounting.waiveReceivable('${item.id}')">Waive</button>` : ''}
                    </td>
                </tr>
            `;
        });

        html += '</tbody></table></div>';
        container.innerHTML = html;
    },

    recordPayment(receivableId) {
        const receivable = Storage.getItemById('accounts_receivable', receivableId);
        if (!receivable) return;

        const outstanding = receivable.amount - (receivable.paid_amount || 0);

        const modalHtml = `
            <div id="paymentModal" class="modal-overlay">
                <div class="modal" style="max-width: 450px;">
                    <div class="modal-header">
                        <h3 class="modal-title">Record Payment</h3>
                        <button class="modal-close" onclick="Modal.hide('paymentModal')"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <strong>Student:</strong> ${receivable.student_name}<br>
                            <strong>Fee Type:</strong> ${receivable.fee_type}<br>
                            <strong>Outstanding:</strong> <span class="text-danger">${Utils.formatCurrency(outstanding)}</span>
                        </div>
                        <form id="paymentForm">
                            <div class="form-group">
                                <label class="form-label required">Payment Amount</label>
                                <input type="number" name="amount" class="form-control" max="${outstanding}" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Payment Date</label>
                                <input type="date" name="payment_date" class="form-control" value="${new Date().toISOString().split('T')[0]}">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Payment Method</label>
                                <select name="payment_method" class="form-control">
                                    <option value="cash">Cash</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                    <option value="pos">POS</option>
                                    <option value="online">Online</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="2"></textarea>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" onclick="Modal.hide('paymentModal')">Cancel</button>
                        <button class="btn btn-primary" onclick="Accounting.confirmPayment('${receivableId}')">Record Payment</button>
                    </div>
                </div>
            </div>
        `;

        Modal.showCustom(modalHtml);
    },

    confirmPayment(receivableId) {
        const data = Form.getData('paymentForm');
        const amount = parseFloat(data.amount);
        const max = parseFloat(document.querySelector('input[name="amount"]').max);

        if (isNaN(amount) || amount <= 0) {
            Toast.error('Please enter a valid amount');
            return;
        }

        if (amount > max) {
            Toast.error('Payment cannot exceed outstanding balance');
            return;
        }

        Storage.recordPaymentToReceivable(receivableId, amount, data.payment_date);

        // Also create a finance income transaction automatically
        const receivable = Storage.getItemById('accounts_receivable', receivableId);
        const school = Auth.getSchool();
        const user = Auth.getCurrentUser();

        // Get the income account for fees (CoA: 4000 Tuition Fees)
        const tuitionAccount = this.chartOfAccounts.find(acc => acc.account_code === '4000' && acc.account_type === 'income');
        const accountId = tuitionAccount ? tuitionAccount.id : null;

        const transaction = {
            type: 'income',
            amount: amount,
            description: `Payment received from ${receivable.student_name} - ${receivable.fee_type}`,
            category: receivable.fee_type,
            account_id: accountId,
            payment_method: data.payment_method,
            reference_number: `PAY-${receivableId.slice(-6).toUpperCase()}`,
            related_student_id: receivable.student_id,
            date: data.payment_date,
            school_id: this.schoolId,
            created_by: user.id,
            createdAt: new Date().toISOString()
        };

        Storage.addItem('finance', transaction);

        // Generate receipt automatically
        const receipt = {
            id: Storage.generateId(),
            school_id: this.schoolId,
            receipt_number: `RCPT-${new Date().getFullYear()}-${Storage.generateId().slice(-6).toUpperCase()}`,
            transaction_id: transaction.id,
            payment_type: receivable.fee_type,
            payer_name: receivable.student_name,
            payer_id: receivable.student_id,
            receiver_name: user.name,
            receiver_id: user.id,
            amount: amount,
            description: `Payment for ${receivable.fee_type}`,
            format: 'pdf',
            generated_by: user.id,
            createdAt: new Date().toISOString()
        };
        Storage.addItem('receipts', receipt);

        Toast.success('Payment recorded, transaction added, and receipt generated');
        Modal.hide('paymentModal');
        this.renderAccountsReceivable();
        Finance.loadDashboard(); // Refresh dashboard stats
    },

    waiveReceivable(receivableId) {
        Modal.confirm({
            title: 'Waive Receivable',
            message: 'Are you sure you want to waive this outstanding amount? This cannot be undone.',
            onConfirm: () => {
                Storage.updateItem('accounts_receivable', receivableId, {
                    status: 'waived',
                    paid_amount: 0
                });
                Toast.success('Receivable waived');
                this.renderAccountsReceivable();
            }
        });
    },

    // ========================================
    // TAX SETTINGS
    // ========================================
    renderTaxSettings() {
        const container = document.getElementById('taxSettingsContainer');
        if (!container) return;

        const settings = Storage.getTaxSettings(this.schoolId);

        let html = `
            <div class="card mb-3">
                <div class="card-body">
                    <h4>Tax Configuration</h4>
                    <p class="text-muted">Configure tax rates for your income and expense items.</p>
                    <button class="btn btn-primary mb-3" onclick="Accounting.showTaxModal()">Add Tax Rule</button>
                    <div class="table-container"><table class="table"><thead><tr>
                        <th>Tax Name</th>
                        <th>Rate</th>
                        <th>Inclusive</th>
                        <th>Applies To</th>
                        <th>Actions</th>
                    </tr></thead><tbody>
        `;

        if (settings.length === 0) {
            html += `<tr><td colspan="5" class="text-center">No tax rules configured.</td></tr>`;
        } else {
            settings.forEach(s => {
                html += `
                    <tr>
                        <td>${s.tax_name}</td>
                        <td>${s.tax_rate}%</td>
                        <td>${s.is_inclusive ? 'Yes' : 'No'}</td>
                        <td>${s.applies_to_categories ? s.applies_to_categories.join(', ') : 'All'}</td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick="Accounting.showTaxModal('${s.id}')">Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="Accounting.deleteTax('${s.id}')">Delete</button>
                        </td>
                    </tr>
                `;
            });
        }

        html += '</tbody></table></div></div></div>';
        container.innerHTML = html;
    },

    showTaxModal(taxId = '') {
        const settings = Storage.getTaxSettings(this.schoolId);
        const tax = taxId ? settings.find(t => t.id === taxId) : null;

        const modalHtml = `
            <div id="taxModal" class="modal-overlay">
                <div class="modal" style="max-width: 500px;">
                    <div class="modal-header">
                        <h3 class="modal-title">${tax ? 'Edit Tax Rule' : 'Add Tax Rule'}</h3>
                        <button class="modal-close" onclick="Modal.hide('taxModal')"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <form id="taxForm">
                            ${tax ? `<input type="hidden" name="tax_id" value="${tax.id}">` : ''}
                            <div class="form-group">
                                <label class="form-label required">Tax Name</label>
                                <input type="text" name="tax_name" class="form-control" required value="${tax?.tax_name || ''}" placeholder="e.g., VAT">
                            </div>
                            <div class="form-group">
                                <label class="form-label required">Tax Rate (%)</label>
                                <input type="number" name="tax_rate" class="form-control" required min="0" max="100" step="0.01" value="${tax?.tax_rate || ''}">
                            </div>
                            <div class="form-group">
                                <label class="form-check">
                                    <input type="checkbox" name="is_inclusive" ${tax?.is_inclusive ? 'checked' : ''}> Price includes tax
                                </label>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Applies To Categories (comma separated, leave blank for all)</label>
                                <input type="text" name="applies_to_categories" class="form-control" value="${tax?.applies_to_categories?.join(', ') || ''}" placeholder="e.g., Tuition, Supplies">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" onclick="Modal.hide('taxModal')">Cancel</button>
                        <button class="btn btn-primary" onclick="Accounting.saveTax()">Save</button>
                    </div>
                </div>
            </div>
        `;

        Modal.showCustom(modalHtml);
    },

    saveTax() {
        const data = Form.getData('taxForm');
        if (!data.tax_name || !data.tax_rate) {
            Toast.error('Please fill required fields');
            return;
        }

        const appliesTo = data.applies_to_categories ? data.applies_to_categories.split(',').map(s => s.trim()).filter(Boolean) : [];

        const taxSetting = {
            tax_name: data.tax_name,
            tax_rate: parseFloat(data.tax_rate),
            is_inclusive: data.is_inclusive || false,
            applies_to_categories: appliesTo
        };

        // Get existing settings
        let settings = Storage.getTaxSettings(this.schoolId);
        const editingId = document.querySelector('#taxForm input[name="tax_id"]')?.value;

        if (editingId) {
            // Update existing
            const index = settings.findIndex(s => s.id === editingId);
            if (index !== -1) {
                settings[index] = { ...settings[index], ...taxSetting };
            }
        } else {
            // Add new
            taxSetting.id = Storage.generateId();
            settings.push(taxSetting);
        }

        Storage.saveTaxSettings(this.schoolId, settings);
        Toast.success('Tax rule saved');
        Modal.hide('taxModal');
        this.renderTaxSettings();
    },

    deleteTax(taxId) {
        Modal.confirm({
            title: 'Delete Tax Rule',
            message: 'Delete this tax rule?',
            onConfirm: () => {
                let settings = Storage.getTaxSettings(this.schoolId);
                settings = settings.filter(s => s.id !== taxId);
                Storage.saveTaxSettings(this.schoolId, settings);
                Toast.success('Tax rule deleted');
                this.renderTaxSettings();
            }
        });
    },

    calculateTaxAmount(amount, taxSetting) {
        if (!taxSetting) return 0;

        if (taxSetting.is_inclusive) {
            // Amount includes tax, extract tax
            const taxMultiplier = taxSetting.tax_rate / 100;
            return amount * (taxMultiplier / (1 + taxMultiplier));
        } else {
            // Amount excludes tax, add it
            return amount * (taxSetting.tax_rate / 100);
        }
    },

    // ========================================
    // FINANCIAL STATEMENTS
    // ========================================
    generateProfitLoss(startDate, endDate) {
        const transactions = Storage.getFinance(this.schoolId);
        const filtered = transactions.filter(t => {
            const d = new Date(t.date);
            return d >= new Date(startDate) && d <= new Date(endDate);
        });

        const income = filtered.filter(t => t.type === 'income');
        const expenses = filtered.filter(t => t.type === 'expense');

        const incomeByAccount = {};
        const expenseByAccount = {};

        income.forEach(t => {
            const accountName = t.account_id ? this.getAccountById(t.account_id)?.account_name || t.category : t.category;
            incomeByAccount[accountName] = (incomeByAccount[accountName] || 0) + t.amount;
        });

        expenses.forEach(t => {
            const accountName = t.account_id ? this.getAccountById(t.account_id)?.account_name || t.category : t.category;
            expenseByAccount[accountName] = (expenseByAccount[accountName] || 0) + t.amount;
        });

        const totalIncome = Object.values(incomeByAccount).reduce((a, b) => a + b, 0);
        const totalExpenses = Object.values(expenseByAccount).reduce((a, b) => a + b, 0);
        const netIncome = totalIncome - totalExpenses;

        return {
            period: { startDate, endDate },
            income: incomeByAccount,
            expenses: expenseByAccount,
            totalIncome,
            totalExpenses,
            netIncome
        };
    },

    generateBalanceSheet(asOfDate) {
        const transactions = Storage.getFinance(this.schoolId);
        const upToDate = transactions.filter(t => new Date(t.date) <= new Date(asOfDate));

        // Simple calculation (not full double-entry)
        // Assets: Cash (sum of all income - expenses) + Receivables
        const income = upToDate.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
        const expenses = upToDate.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
        const cashBalance = income - expenses;

        const ar = Storage.getAccountsReceivable(this.schoolId);
        const arTotal = ar.reduce((sum, a) => sum + (a.amount - (a.paid_amount || 0)), 0);

        const liabilities = 0; // For now, no liability tracking
        const equity = cashBalance + arTotal - liabilities;

        return {
            asOfDate,
            assets: {
                cash: cashBalance,
                accounts_receivable: arTotal,
                total: cashBalance + arTotal
            },
            liabilities: {
                total: liabilities
            },
            equity: {
                total: equity
            },
            check: cashBalance + arTotal === equity
        };
    },

    // ========================================
    // HELPERS
    // ========================================
    getStudentSearchOptions() {
        const students = Storage.getStudents(this.schoolId);
        return students.map(s => ({
            id: s.id,
            name: s.name,
            class: s.class,
            text: `${s.name} (${s.student_id || s.id}) - ${s.class}`
        }));
    },

    checkBudgetAlerts() {
        const alerts = [];
        const currentYear = new Date().getFullYear();
        const currentTerm = this.getCurrentTerm();
        const budgets = Storage.getBudgets(this.schoolId, `${currentYear}/${currentYear + 1}`, currentTerm);

        budgets.forEach(budget => {
            if (budget.allocated_amount > 0) {
                const percentUsed = (budget.actual_amount / budget.allocated_amount) * 100;
                if (percentUsed >= 90) {
                    alerts.push({
                        category: budget.category,
                        subcategory: budget.subcategory,
                        allocated: budget.allocated_amount,
                        actual: budget.actual_amount,
                        percent: percentUsed.toFixed(1)
                    });
                }
            }
        });

        return alerts;
    },

    updateBudgetActual(transaction) {
        // Expanded mapping from transaction category to budget category
        const budgetCategoryMap = {
            // Income
            'Tuition Fees': 'Tuition Fees',
            'Registration Fees': 'Registration Fees',
            'Examination Fees': 'Other Income',
            'Hostel Fees': 'Other Income',
            'Transportation Fees': 'Transportation',
            'Donations': 'Donations',
            'Other Income': 'Other Income',
            
            // Expenses
            'Salaries - Teaching Staff': 'Salaries',
            'Salaries - Admin Staff': 'Salaries',
            'Salaries - Support Staff': 'Salaries',
            'Salaries': 'Salaries',
            'Utilities - Electricity': 'Utilities',
            'Utilities - Water': 'Utilities',
            'Utilities - Internet': 'Utilities',
            'Utilities': 'Utilities',
            'Maintenance': 'Maintenance',
            'Repairs': 'Maintenance',
            'Supplies - Office': 'Supplies',
            'Supplies - Teaching': 'Supplies',
            'Supplies': 'Supplies',
            'Transportation': 'Transportation',
            'Rent': 'Rent',
            'Insurance': 'Insurance',
            'Marketing': 'Marketing',
            'Professional Services': 'Professional Services',
            'Miscellaneous': 'Miscellaneous'
        };

        let budgetCategory = budgetCategoryMap[transaction.category];
        
        // Fallback: try to match by keywords
        if (!budgetCategory) {
            const lowerCat = transaction.category.toLowerCase();
            if (lowerCat.includes('salary')) budgetCategory = 'Salaries';
            else if (lowerCat.includes('utility') || lowerCat.includes('electric') || lowerCat.includes('water') || lowerCat.includes('internet')) budgetCategory = 'Utilities';
            else if (lowerCat.includes('supply') || lowerCat.includes('material')) budgetCategory = 'Supplies';
            else if (lowerCat.includes('maintain') || lowerCat.includes('repair')) budgetCategory = 'Maintenance';
            else if (lowerCat.includes('transport') || lowerCat.includes('fuel')) budgetCategory = 'Transportation';
        }

        if (!budgetCategory) return;

        const currentYear = new Date().getFullYear();
        const currentTerm = this.getCurrentTerm();
        const budgets = Storage.getBudgets(this.schoolId, `${currentYear}/${currentYear + 1}`, currentTerm);

        const matchingBudget = budgets.find(b => 
            b.category === budgetCategory && 
            (!b.subcategory || b.subcategory === '')
        );

        if (matchingBudget) {
            const newActual = matchingBudget.actual_amount + transaction.amount;
            Storage.updateBudget(matchingBudget.id, { actual_amount: newActual });
        }
    },

    // ========================================
    // FINANCIAL STATEMENTS
    // ========================================
    showStatementModal() {
        const today = new Date().toISOString().split('T')[0];
        const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

        const modalHtml = `
            <div id="statementModal" class="modal-overlay">
                <div class="modal" style="max-width: 500px;">
                    <div class="modal-header">
                        <h3 class="modal-title">Generate Financial Statement</h3>
                        <button class="modal-close" onclick="Modal.hide('statementModal')"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <form id="statementForm">
                            <div class="form-group">
                                <label class="form-label required">Statement Type</label>
                                <select name="statement_type" class="form-control" required>
                                    <option value="pl">Profit & Loss</option>
                                    <option value="balance">Balance Sheet</option>
                                    <option value="cashflow">Cash Flow Statement</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label required">Start Date</label>
                                <input type="date" name="start_date" class="form-control" required value="${monthAgo}">
                            </div>
                            <div class="form-group">
                                <label class="form-label required">End Date</label>
                                <input type="date" name="end_date" class="form-control" required value="${today}">
                            </div>
                            <div class="form-group">
                                <label class="form-check">
                                    <input type="checkbox" name="compare_period" value="1"> Include prior period comparison
                                </label>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" onclick="Modal.hide('statementModal')">Cancel</button>
                        <button class="btn btn-primary" onclick="Accounting.generateStatementFromForm()">Generate</button>
                    </div>
                </div>
            </div>
        `;

        Modal.showCustom(modalHtml);
    },

    generateStatementFromForm() {
        const data = Form.getData('statementForm');
        if (!data.statement_type || !data.start_date || !data.end_date) {
            Toast.error('Please fill required fields');
            return;
        }

        Modal.hide('statementModal');
        this.showStatement(data.statement_type, data.start_date, data.end_date, data.compare_period);
    },

    showStatement(type, startDate, endDate, comparePeriod = false) {
        let html = '';
        let school = Auth.getSchool();

        if (type === 'pl') {
            const statement = this.generateProfitLoss(startDate, endDate);
            const prevStart = new Date(new Date(startDate).setFullYear(new Date(startDate).getFullYear() - 1)).toISOString().split('T')[0];
            const prevEnd = new Date(new Date(endDate).setFullYear(new Date(endDate).getFullYear() - 1)).toISOString().split('T')[0];
            const prevStatement = comparePeriod ? this.generateProfitLoss(prevStart, prevEnd) : null;

            html = this.renderProfitLossStatement(statement, prevStatement, school);
        } else if (type === 'balance') {
            const statement = this.generateBalanceSheet(endDate);
            html = this.renderBalanceSheetStatement(statement, school);
        } else if (type === 'cashflow') {
            const statement = this.generateCashFlow(startDate, endDate);
            html = this.renderCashFlowStatement(statement, school);
        }

        document.getElementById('statementContent').innerHTML = html;
    },

    renderProfitLossStatement(statement, prevStatement, school) {
        const formatCurrency = (amount) => '₦' + parseFloat(amount).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        // Prepare chart data
        const incomeLabels = Object.keys(statement.income);
        const incomeValues = Object.values(statement.income);
        const expenseLabels = Object.keys(statement.expenses);
        const expenseValues = Object.values(statement.expenses);

        let html = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h3>Profit & Loss Statement</h3>
                    <p class="text-muted">${Utils.formatDate(statement.period.startDate)} - ${Utils.formatDate(statement.period.endDate)}</p>
                </div>
                <div>
                    <button class="btn btn-outline btn-sm" onclick="Accounting.exportPLToPDF('${statement.period.startDate}', '${statement.period.endDate}')">
                        <i class="fas fa-file-pdf"></i> Export PDF
                    </button>
                </div>
            </div>

            <!-- Charts Section -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Income vs Expenses</h5>
                            <canvas id="plBarChart" height="200"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Expense Breakdown</h5>
                            <canvas id="plPieChart" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-body">
                    <h5>Income</h5>
                    <table class="table">
                        <thead><tr><th>Account</th><th>Amount</th></tr></thead>
                        <tbody>
        `;

        Object.entries(statement.income).forEach(([account, amount]) => {
            html += `<tr><td>${account}</td><td class="text-success">${formatCurrency(amount)}</td></tr>`;
        });

        html += `
                        <tr class="table-active"><th>Total Income</th><th class="text-success">${formatCurrency(statement.totalIncome)}</th></tr>
                    </tbody>
                    </table>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-body">
                    <h5>Expenses</h5>
                    <table class="table">
                        <thead><tr><th>Account</th><th>Amount</th></tr></thead>
                        <tbody>
        `;

        Object.entries(statement.expenses).forEach(([account, amount]) => {
            html += `<tr><td>${account}</td><td class="text-danger">${formatCurrency(amount)}</td></tr>`;
        });

        html += `
                        <tr class="table-active"><th>Total Expenses</th><th class="text-danger">${formatCurrency(statement.totalExpenses)}</th></tr>
                    </tbody>
                    </table>
                </div>
            </div>

            <div class="card" style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white;">
                <div class="card-body text-center">
                    <h4>Net ${statement.netIncome >= 0 ? 'Income' : 'Loss'}</h4>
                    <h2>${formatCurrency(Math.abs(statement.netIncome))}</h2>
                </div>
            </div>
        `;

        if (prevStatement) {
            html += `
                <div class="card mt-3">
                    <div class="card-body">
                        <h5>Prior Period Comparison (${Utils.formatDate(prevStart)} - ${Utils.formatDate(prevEnd)})</h5>
                        <p>Prior Net Income: ${formatCurrency(prevStatement.netIncome)}</p>
                        <p>Change: <span class="${statement.netIncome >= prevStatement.netIncome ? 'text-success' : 'text-danger'}">
                            ${formatCurrency(statement.netIncome - prevStatement.netIncome)} 
                            (${((statement.netIncome - prevStatement.netIncome) / Math.abs(prevStatement.netIncome) * 100).toFixed(1)}%)
                        </span></p>
                    </div>
                </div>
            `;
        }

        // Render charts after HTML is inserted
        setTimeout(() => {
            this.renderPLBarChart(incomeLabels, incomeValues, expenseLabels, expenseValues);
            this.renderPLPieChart(expenseLabels, expenseValues);
        }, 100);

        return html;
    },

    renderPLBarChart(incomeLabels, incomeValues, expenseLabels, expenseValues) {
        const canvas = document.getElementById('plBarChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        canvas.width = canvas.offsetWidth || 400;
        canvas.height = 200;
        
        const allLabels = [...incomeLabels, ...expenseLabels];
        const maxValue = Math.max(...incomeValues, ...expenseValues, 1);
        const chartHeight = 160;
        const chartWidth = canvas.width - 60;
        const barWidth = chartWidth / (allLabels.length || 1) - 10;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw bars
        const incomeTotal = incomeLabels.length;
        const expenseStart = incomeTotal;
        
        allLabels.forEach((label, i) => {
            const value = i < incomeTotal ? incomeValues[i] : expenseValues[i - incomeTotal];
            const barHeight = (value / maxValue) * chartHeight;
            const x = 40 + i * (barWidth + 10);
            const y = 30 + chartHeight - barHeight;
            
            // Color based on income or expense
            ctx.fillStyle = i < incomeTotal ? '#10b981' : '#ef4444';
            ctx.fillRect(x, y, barWidth, barHeight);
            
            // Label
            ctx.fillStyle = '#666';
            ctx.font = '10px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(label.substring(0, 8), x + barWidth/2, canvas.height - 5);
        });
        
        // Legend
        ctx.fillStyle = '#10b981';
        ctx.fillRect(10, 5, 15, 10);
        ctx.fillStyle = '#666';
        ctx.textAlign = 'left';
        ctx.fillText('Income', 30, 14);
        
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(90, 5, 15, 10);
        ctx.fillStyle = '#666';
        ctx.fillText('Expense', 110, 14);
    },

    renderPLPieChart(labels, values) {
        const canvas = document.getElementById('plPieChart');
        if (!canvas || values.length === 0) return;
        
        const ctx = canvas.getContext('2d');
        canvas.width = 200;
        canvas.height = 200;
        
        const colors = ['#3b82f6', '#ef4444', '#f59e0b', '#8b5cf6', '#10b981', '#ec4899', '#6366f1', '#14b8a6'];
        const total = values.reduce((a, b) => a + b, 0);
        let startAngle = 0;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        values.forEach((value, i) => {
            const sliceAngle = (value / total) * 2 * Math.PI;
            ctx.beginPath();
            ctx.moveTo(100, 100);
            ctx.arc(100, 100, 80, startAngle, startAngle + sliceAngle);
            ctx.closePath();
            ctx.fillStyle = colors[i % colors.length];
            ctx.fill();
            startAngle += sliceAngle;
        });
        
        // Center circle (donut)
        ctx.beginPath();
        ctx.arc(100, 100, 40, 0, 2 * Math.PI);
        ctx.fillStyle = '#fff';
        ctx.fill();
    },

    renderBalanceSheetStatement(statement, school) {
        const formatCurrency = (amount) => '₦' + parseFloat(amount).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        let html = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h3>Balance Sheet</h3>
                    <p class="text-muted">As of ${Utils.formatDate(statement.asOfDate)}</p>
                </div>
                <div>
                    <button class="btn btn-outline btn-sm" onclick="Accounting.exportBalanceSheetToPDF('${statement.asOfDate}')">
                        <i class="fas fa-file-pdf"></i> Export PDF
                    </button>
                </div>
            </div>

            <!-- Balance Sheet Chart -->
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Assets vs Liabilities + Equity</h5>
                    <canvas id="balanceBarChart" height="150"></canvas>
                </div>
            </div>

            <div class="grid-2">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-success">Assets</h5>
                        <table class="table">
                            <tr><td>Cash & Bank</td><td>${formatCurrency(statement.assets.cash)}</td></tr>
                            <tr><td>Accounts Receivable</td><td>${formatCurrency(statement.assets.accounts_receivable)}</td></tr>
                            <tr class="table-active"><th>Total Assets</th><th>${formatCurrency(statement.assets.total)}</th></tr>
                        </table>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <h5 class="text-danger">Liabilities & Equity</h5>
                        <table class="table">
                            <tr><td>Liabilities</td><td>${formatCurrency(statement.liabilities.total)}</td></tr>
                            <tr><td>Equity</td><td>${formatCurrency(statement.equity.total)}</td></tr>
                            <tr class="table-active"><th>Total L&E</th><th>${formatCurrency(statement.liabilities.total + statement.equity.total)}</th></tr>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card mt-3 ${statement.check ? 'bg-success text-white' : 'bg-warning'}">
                <div class="card-body text-center">
                    <h5>${statement.check ? '✓ Balanced' : '⚠ Unbalanced'}</h5>
                    <p>Assets (${formatCurrency(statement.assets.total)}) = Liabilities + Equity (${formatCurrency(statement.liabilities.total + statement.equity.total)})</p>
                </div>
            </div>
        `;

        // Render chart
        setTimeout(() => {
            this.renderBalanceBarChart(statement.assets.total, statement.liabilities.total, statement.equity.total);
        }, 100);

        return html;
    },

    renderBalanceBarChart(assets, liabilities, equity) {
        const canvas = document.getElementById('balanceBarChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        canvas.width = canvas.offsetWidth || 400;
        canvas.height = 150;
        
        const maxValue = Math.max(assets, liabilities + equity, 1);
        const chartHeight = 100;
        const barWidth = 80;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Assets bar
        const assetsHeight = (assets / maxValue) * chartHeight;
        ctx.fillStyle = '#10b981';
        ctx.fillRect(80, 30 + chartHeight - assetsHeight, barWidth, assetsHeight);
        ctx.fillStyle = '#666';
        ctx.textAlign = 'center';
        ctx.fillText('Assets', 120, canvas.height - 5);
        
        // Liabilities bar
        const liabHeight = (liabilities / maxValue) * chartHeight;
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(200, 30 + chartHeight - liabHeight, barWidth, liabHeight);
        ctx.fillStyle = '#666';
        ctx.fillText('Liabilities', 240, canvas.height - 5);
        
        // Equity bar
        const equityHeight = (equity / maxValue) * chartHeight;
        ctx.fillStyle = '#3b82f6';
        ctx.fillRect(320, 30 + chartHeight - equityHeight, barWidth, equityHeight);
        ctx.fillStyle = '#666';
        ctx.fillText('Equity', 360, canvas.height - 5);
    },

    renderCashFlowStatement(statement, school) {
        // Simple cash flow: Opening + Income - Expenses = Closing
        const formatCurrency = (amount) => '₦' + parseFloat(amount).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        let html = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h3>Cash Flow Statement</h3>
                    <p class="text-muted">${Utils.formatDate(statement.period.startDate)} - ${Utils.formatDate(statement.period.endDate)}</p>
                </div>
                <div>
                    <button class="btn btn-outline btn-sm" onclick="Accounting.exportCashFlowToPDF('${statement.period.startDate}', '${statement.period.endDate}')">
                        <i class="fas fa-file-pdf"></i> Export PDF
                    </button>
                </div>
            </div>

            <!-- Cash Flow Chart -->
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Cash Flow Overview</h5>
                    <canvas id="cashflowChart" height="150"></canvas>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-body">
                    <h5>Operating Activities</h5>
                    <table class="table">
                        <tr><td>Opening Cash Balance</td><td>${formatCurrency(statement.openingBalance)}</td></tr>
                        <tr><td>+ Total Income</td><td class="text-success">+${formatCurrency(statement.totalIncome)}</td></tr>
                        <tr><td>- Total Expenses</td><td class="text-danger">-${formatCurrency(statement.totalExpenses)}</td></tr>
                        <tr class="table-active"><th>Net Cash from Operations</th><th>${formatCurrency(statement.netCashFlow)}</th></tr>
                    </table>
                </div>
            </div>

            <div class="card">
                <div class="card-body text-center">
                    <h5>Closing Cash Balance</h5>
                    <h2 class="${statement.closingBalance >= 0 ? 'text-success' : 'text-danger'}">${formatCurrency(statement.closingBalance)}</h2>
                </div>
            </div>
        `;

        // Render chart
        setTimeout(() => {
            this.renderCashFlowBarChart(statement.openingBalance, statement.totalIncome, statement.totalExpenses, statement.closingBalance);
        }, 100);

        return html;
    },

    renderCashFlowBarChart(opening, income, expenses, closing) {
        const canvas = document.getElementById('cashflowChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        canvas.width = canvas.offsetWidth || 400;
        canvas.height = 150;
        
        const values = [opening, income, expenses, closing];
        const labels = ['Opening', 'Income', 'Expenses', 'Closing'];
        const maxValue = Math.max(...values.map(Math.abs), 1);
        const chartHeight = 100;
        const barWidth = 60;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        values.forEach((val, i) => {
            const barHeight = (Math.abs(val) / maxValue) * chartHeight;
            const x = 50 + i * (barWidth + 30);
            const y = 30 + chartHeight - barHeight;
            
            ctx.fillStyle = val >= 0 ? '#10b981' : '#ef4444';
            ctx.fillRect(x, y, barWidth, barHeight);
            
            ctx.fillStyle = '#666';
            ctx.textAlign = 'center';
            ctx.fillText(labels[i], x + barWidth/2, canvas.height - 5);
            
            // Value on top of bar
            ctx.font = '10px sans-serif';
            ctx.fillText('₦' + (val/1000).toFixed(0) + 'k', x + barWidth/2, y - 5);
        });
    },

    generateCashFlow(startDate, endDate) {
        const transactions = Storage.getFinance(this.schoolId);
        const filtered = transactions.filter(t => {
            const d = new Date(t.date);
            return d >= new Date(startDate) && d <= new Date(endDate);
        });

        const income = filtered.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
        const expenses = filtered.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);

        // Get opening balance from transactions before startDate
        const beforeStart = transactions.filter(t => new Date(t.date) < new Date(startDate));
        const openingIncome = beforeStart.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
        const openingExpenses = beforeStart.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
        const openingBalance = openingIncome - openingExpenses;

        const netCashFlow = income - expenses;
        const closingBalance = openingBalance + netCashFlow;

        return {
            period: { startDate, endDate },
            openingBalance,
            totalIncome: income,
            totalExpenses: expenses,
            netCashFlow,
            closingBalance
        };
    },

    exportStatement(format = 'pdf') {
        if (format === 'excel') {
            this.exportToExcel();
        } else {
            window.print();
        }
    },

    exportToExcel() {
        const school = Auth.getSchool();
        const transactions = Storage.getFinance(this.schoolId);
        
        // Create CSV content
        let csvContent = '\uFEFF'; // BOM for UTF-8
        csvContent += 'School Name,' + (school?.name || 'School') + '\n';
        csvContent += 'Export Date,' + new Date().toLocaleDateString() + '\n\n';
        
        // Transaction Summary
        csvContent += 'TRANSACTION SUMMARY\n';
        csvContent += 'Date,Type,Description,Amount,Category,Account\n';
        
        transactions.forEach(t => {
            const row = [
                t.date || '',
                t.type || '',
                (t.description || '').replace(/,/g, ';'),
                t.amount || 0,
                t.category || '',
                t.account_name || ''
            ];
            csvContent += row.join(',') + '\n';
        });
        
        // Summary by Type
        const income = transactions.filter(t => t.type === 'income').reduce((s, t) => s + (t.amount || 0), 0);
        const expenses = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + (t.amount || 0), 0);
        
        csvContent += '\nSUMMARY\n';
        csvContent += 'Total Income,' + income + '\n';
        csvContent += 'Total Expenses,' + expenses + '\n';
        csvContent += 'Net Balance,' + (income - expenses) + '\n';
        
        // Create and download file
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'financial_report_' + new Date().toISOString().split('T')[0] + '.csv';
        link.click();
        
        Toast.success('Financial report exported successfully!');
    },

    exportPLToPDF(startDate, endDate) {
        const statement = this.generateProfitLoss(startDate, endDate);
        const school = Auth.getSchool();
        const formatCurrency = (amount) => '₦' + parseFloat(amount).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        const content = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Profit & Loss Statement</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 40px; }
                    .header { text-align: center; margin-bottom: 30px; }
                    .school-name { font-size: 24px; font-weight: bold; }
                    .statement-title { font-size: 20px; margin: 10px 0; }
                    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
                    th { background-color: #f5f5f5; font-weight: bold; }
                    .text-success { color: #16a34a; }
                    .text-danger { color: #dc2626; }
                    .table-active { background-color: #f0f9ff; font-weight: bold; }
                    .net-income { background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white; padding: 20px; text-align: center; margin-top: 20px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="school-name">${school?.name || 'School'}</div>
                    <div>${school?.address || ''} | ${school?.phone || ''}</div>
                    <div class="statement-title">Profit & Loss Statement</div>
                    <div>${Utils.formatDate(startDate)} - ${Utils.formatDate(endDate)}</div>
                </div>

                <div class="section">
                    <h4>Income</h4>
                    <table>
                        <thead><tr><th>Account</th><th>Amount</th></tr></thead>
                        <tbody>
                            ${Object.entries(statement.income).map(([acc, amt]) => 
                                `<tr><td>${acc}</td><td class="text-success">${formatCurrency(amt)}</td></tr>`
                            ).join('')}
                            <tr class="table-active"><th>Total Income</th><th class="text-success">${formatCurrency(statement.totalIncome)}</th></tr>
                        </tbody>
                    </table>
                </div>

                <div class="section">
                    <h4>Expenses</h4>
                    <table>
                        <thead><tr><th>Account</th><th>Amount</th></tr></thead>
                        <tbody>
                            ${Object.entries(statement.expenses).map(([acc, amt]) => 
                                `<tr><td>${acc}</td><td class="text-danger">${formatCurrency(amt)}</td></tr>`
                            ).join('')}
                            <tr class="table-active"><th>Total Expenses</th><th class="text-danger">${formatCurrency(statement.totalExpenses)}</th></tr>
                        </tbody>
                    </table>
                </div>

                <div class="net-income">
                    <h4>Net ${statement.netIncome >= 0 ? 'Income' : 'Loss'}</h4>
                    <h2>${formatCurrency(Math.abs(statement.netIncome))}</h2>
                </div>

                <div style="margin-top: 30px; text-align: center; font-size: 12px; color: #999;">
                    Generated on ${new Date().toLocaleString()} | Skoolar System
                </div>
            </body>
            </html>
        `;

        const printWindow = window.open('', '_blank');
        printWindow.document.write(content);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            printWindow.print();
        }, 500);
        Toast.success('Statement ready for printing/saving as PDF');
    },

    exportBalanceSheetToPDF(asOfDate) {
        const statement = this.generateBalanceSheet(asOfDate);
        const school = Auth.getSchool();
        const formatCurrency = (amount) => '₦' + parseFloat(amount).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        const content = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Balance Sheet</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 40px; }
                    .header { text-align: center; margin-bottom: 30px; }
                    .school-name { font-size: 24px; font-weight: bold; }
                    .statement-title { font-size: 20px; margin: 10px 0; }
                    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
                    th { background-color: #f5f5f5; font-weight: bold; }
                    .text-success { color: #16a34a; }
                    .text-danger { color: #dc2626; }
                    .table-active { background-color: #f0f9ff; font-weight: bold; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="school-name">${school?.name || 'School'}</div>
                    <div>${school?.address || ''} | ${school?.phone || ''}</div>
                    <div class="statement-title">Balance Sheet</div>
                    <div>As of ${Utils.formatDate(asOfDate)}</div>
                </div>

                <div class="grid-2" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="section">
                        <h4 class="text-success">Assets</h4>
                        <table>
                            <tr><td>Cash & Bank</td><td>${formatCurrency(statement.assets.cash)}</td></tr>
                            <tr><td>Accounts Receivable</td><td>${formatCurrency(statement.assets.accounts_receivable)}</td></tr>
                            <tr class="table-active"><th>Total Assets</th><th>${formatCurrency(statement.assets.total)}</th></tr>
                        </table>
                    </div>

                    <div class="section">
                        <h4 class="text-danger">Liabilities & Equity</h4>
                        <table>
                            <tr><td>Liabilities</td><td>${formatCurrency(statement.liabilities.total)}</td></tr>
                            <tr><td>Equity</td><td>${formatCurrency(statement.equity.total)}</td></tr>
                            <tr class="table-active"><th>Total L&E</th><th>${formatCurrency(statement.liabilities.total + statement.equity.total)}</th></tr>
                        </table>
                    </div>
                </div>

                <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                    Generated on ${new Date().toLocaleString()} | Skoolar System
                </div>
            </body>
            </html>
        `;

        const printWindow = window.open('', '_blank');
        printWindow.document.write(content);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            printWindow.print();
        }, 500);
        Toast.success('Statement ready for printing/saving as PDF');
    },

    exportCashFlowToPDF(startDate, endDate) {
        const statement = this.generateCashFlow(startDate, endDate);
        const school = Auth.getSchool();
        const formatCurrency = (amount) => '₦' + parseFloat(amount).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        const content = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Cash Flow Statement</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 40px; }
                    .header { text-align: center; margin-bottom: 30px; }
                    .school-name { font-size: 24px; font-weight: bold; }
                    .statement-title { font-size: 20px; margin: 10px 0; }
                    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
                    th { background-color: #f5f5f5; font-weight: bold; }
                    .text-success { color: #16a34a; }
                    .text-danger { color: #dc2626; }
                    .table-active { background-color: #f0f9ff; font-weight: bold; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="school-name">${school?.name || 'School'}</div>
                    <div>${school?.address || ''} | ${school?.phone || ''}</div>
                    <div class="statement-title">Cash Flow Statement</div>
                    <div>${Utils.formatDate(startDate)} - ${Utils.formatDate(endDate)}</div>
                </div>

                <table>
                    <tr><td>Opening Cash Balance</td><td>${formatCurrency(statement.openingBalance)}</td></tr>
                    <tr><td>+ Total Income</td><td class="text-success">+${formatCurrency(statement.totalIncome)}</td></tr>
                    <tr><td>- Total Expenses</td><td class="text-danger">-${formatCurrency(statement.totalExpenses)}</td></tr>
                    <tr class="table-active"><th>Net Cash Flow</th><th>${formatCurrency(statement.netCashFlow)}</th></tr>
                </table>

                <div style="margin-top: 20px; padding: 15px; background: #f0f9ff; text-align: center; border-radius: 8px;">
                    <h4>Closing Cash Balance</h4>
                    <h2>${formatCurrency(statement.closingBalance)}</h2>
                </div>

                <div style="margin-top: 30px; text-align: center; font-size: 12px; color: #999;">
                    Generated on ${new Date().toLocaleString()} | Skoolar System
                </div>
            </body>
            </html>
        `;

        const printWindow = window.open('', '_blank');
        printWindow.document.write(content);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            printWindow.print();
        }, 500);
        Toast.success('Statement ready for printing/saving as PDF');
    }
};

// Expose globally
window.Accounting = Accounting;

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('accountingApp')) {
        Accounting.init();
    }
});
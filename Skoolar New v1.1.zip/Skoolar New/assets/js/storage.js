const Storage = {
    DB_NAME: 'mySchoolDB',
    useCloudSync: false,
    cloudSyncReady: false,
    
    // Enable cloud sync when Supabase is available
    enableCloudSync() {
        this.useCloudSync = true;
        this.cloudSyncReady = true;
        console.log('Cloud sync enabled for Storage module');
    },

    init() {
        console.log('Storage initializing...');

        // Initialize localStorage
         if (!localStorage.getItem(this.DB_NAME)) {
            const initialData = {
                systemSettings: {
                    theme: 'light',
                    primaryColor: '#16a34a',
                    secondaryColor: '#10b981',
                    fontFamily: 'Inter',
                    borderRadius: '12',
                    shadowIntensity: 'medium',
                    darkMode: false,
                    darkModeSystem: false
                },
                activationCodes: [],
                schools: [],
                users: [],
                students: [],
                teachers: [],
                attendance: [],
                scores: [],
                domainScores: [],
                finance: [],
                chart_of_accounts: [],
                budgets: [],
                accounts_receivable: [],
                tax_settings: [],
                financial_attachments: [],
                receipts: [],
                chats: [],
                messages: [],
                studentMessages: [],
                parentMessages: [],
                notifications: [],
                reports: [],
                helpContent: null,
                questions: [],
                tests: [],
                testResults: [],
                testAttempts: [],
                testQuestions: [],
                calendarEvents: [],
                adverts: [],
                staffAttendance: [],
                scoreSessions: [],
                library_books: [],
                bookLoans: [],
                homework: [],
                homeworkSubmissions: [],
                timetable: [],
                exams: [],
                examQuestions: [],
                examResults: [],
                examSessions: [],
                examLogs: [],
                violationReports: [],
                auditLog: [],
                syncLog: [],
                blogPosts: [],
                resources: [],
                pricing: null,
                pages: {}
            };
            localStorage.setItem(this.DB_NAME, JSON.stringify(initialData));
        }

          // Always ensure Super Admin user exists and is up to date
          this.seedSuperAdmin();
          this.seedDefaultHelpContent();
          
          // Migrate user roles to canonical format
          this.migrateUserRoles();
          
          // Ensure all new tables exist
          this.ensureTables();
          
          // Normalize data from old structures to new normalized forms
          this.normalizeAllData();
  
          console.log('Storage initialized successfully');
    },

    saveDBLocal(data) {
        localStorage.setItem(this.DB_NAME, JSON.stringify(data));
    },

    DEFAULT_CLASSES: [
        'Nursery 1', 'Nursery 2',
        'Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6',
        'JSS 1', 'JSS 2', 'JSS 3',
        'SS 1', 'SS 2', 'SS 3'
    ],

    DEFAULT_SUBJECTS: {
        'Nursery': ['Mathematics', 'English', 'Writing', 'Science', 'Art', 'Music', 'Physical Education'],
        'Primary': ['Mathematics', 'English', 'Basic Science', 'Social Studies', 'Religious Studies', 'Computer', 'Physical Education', 'French', 'Civic Education', 'Security Education'],
        'JSS': ['Mathematics', 'English', 'Basic Science', 'Social Studies', 'Religious Studies', 'Computer', 'Physical Education', 'French', 'Civic Education', 'Security Education', 'Home Economics', 'Agricultural Science'],
        'SS': ['Mathematics', 'English', 'Physics', 'Chemistry', 'Biology', 'Geography', 'Government', 'Economics', 'Literature', 'History', 'Religious Studies', 'Computer', 'Physical Education', 'French', 'Civic Education', 'Commerce', 'Accounting', 'Technical Drawing', 'Food & Nutrition']
    },

    SCORE_TYPES: ['Daily', 'Weekly', 'Mid-term', 'Exam'],

    DEFAULT_SCORE_RANGES: {
        'Daily': 100,
        'Weekly': 100,
        'Mid-term': 30,
        'Exam': 70
    },

    getSubjectsBySchoolType(schoolType) {
        const subjects = {};
        if (schoolType === 'primary') {
            subjects['Nursery'] = [...this.DEFAULT_SUBJECTS['Nursery']];
            subjects['Primary'] = [...this.DEFAULT_SUBJECTS['Primary']];
            subjects['JSS'] = [...this.DEFAULT_SUBJECTS['JSS']];
        } else if (schoolType === 'secondary') {
            subjects['JSS'] = [...this.DEFAULT_SUBJECTS['JSS']];
            subjects['SS'] = [...this.DEFAULT_SUBJECTS['SS']];
        } else if (schoolType === 'both') {
            subjects['Nursery'] = [...this.DEFAULT_SUBJECTS['Nursery']];
            subjects['Primary'] = [...this.DEFAULT_SUBJECTS['Primary']];
            subjects['JSS'] = [...this.DEFAULT_SUBJECTS['JSS']];
            subjects['SS'] = [...this.DEFAULT_SUBJECTS['SS']];
        }
        return subjects;
    },

    getClassesBySchoolType(schoolType) {
        const classes = [];
        if (schoolType === 'primary') {
            classes.push('Nursery 1', 'Nursery 2');
            for (let i = 1; i <= 6; i++) classes.push(`Primary ${i}`);
            for (let i = 1; i <= 3; i++) classes.push(`JSS ${i}`);
        } else if (schoolType === 'secondary') {
            for (let i = 1; i <= 3; i++) classes.push(`JSS ${i}`);
            for (let i = 1; i <= 3; i++) classes.push(`SS ${i}`);
        } else if (schoolType === 'both') {
            classes.push('Nursery 1', 'Nursery 2');
            for (let i = 1; i <= 6; i++) classes.push(`Primary ${i}`);
            for (let i = 1; i <= 3; i++) classes.push(`JSS ${i}`);
            for (let i = 1; i <= 3; i++) classes.push(`SS ${i}`);
        }
        return classes;
    },

    DEFAULT_HELP_CONTENT: {
        super_admin: {
            title: 'Super Admin Guide',
            sections: [
                {
                    title: 'Getting Started',
                    icon: 'fa-rocket',
                    content: '<h4>Welcome to Super Admin Dashboard</h4><p>As a Super Admin, you have full control over the entire Skoolar system. You can manage schools, activation codes, system settings, and help content.</p><h5>Key Responsibilities:</h5><ul><li>Generate and manage activation codes for schools</li><li>Approve and manage all registered schools</li><li>Configure global theme and system settings</li><li>Edit help content for all user roles</li><li>Monitor system-wide statistics</li></ul>'
                },
                {
                    title: 'Managing Schools',
                    icon: 'fa-school',
                    content: '<h4>School Management</h4><p>You can view all registered schools, monitor their subscription status, and manage their details.</p><h5>Actions Available:</h5><ul><li><strong>View Schools:</strong> See all registered schools and their details</li><li><strong>Renew Subscription:</strong> Extend school subscription periods</li><li><strong>Delete School:</strong> Remove a school and all its data (use with caution)</li></ul><p>School subscriptions are managed through activation codes. Each code has a specific validity period.</p>'
                },
                {
                    title: 'Activation Codes',
                    icon: 'fa-key',
                    content: '<h4>Activation Code Management</h4><p>Activation codes are required for schools to register on the platform.</p><h5>Code Features:</h5><ul><li>Each code has a unique identifier</li><li>Codes can be set with custom subscription days</li><li>Codes expire after the specified period</li><li>Used codes are marked and linked to schools</li></ul><h5>Best Practices:</h5><ul><li>Generate codes only when needed</li><li>Keep track of issued codes</li><li>Clear unused codes periodically</li></ul>'
                },
                {
                    title: 'Theme Settings',
                    icon: 'fa-palette',
                    content: '<h4>Global Theme Configuration</h4><p>Customize the look and feel of the entire system.</p><h5>Available Options:</h5><ul><li><strong>Primary Color:</strong> Main color for buttons and highlights</li><li><strong>Font Family:</strong> Choose from available fonts</li><li><strong>Border Radius:</strong> Adjust corner roundness</li><li><strong>Dark Mode:</strong> Toggle dark theme</li></ul><p>Changes apply globally across all user dashboards.</p>'
                }
            ]
        },
        school_admin: {
            title: 'School Admin Guide',
            sections: [
                {
                    title: 'Dashboard Overview',
                    icon: 'fa-tachometer-alt',
                    content: '<h4>Welcome to Your School Dashboard</h4><p>As a School Admin, you manage all aspects of your school including students, staff, attendance, scores, and finances.</p><h5>Quick Stats:</h5><ul><li><strong>Students:</strong> Total enrolled students</li><li><strong>Teachers:</strong> Active teaching staff</li><li><strong>Balance:</strong> Current financial status</li><li><strong>Attendance:</strong> Today\'s attendance rate</li></ul>'
                },
                {
                    title: 'Student Management',
                    icon: 'fa-users',
                    content: '<h4>Managing Students</h4><p>Add, edit, and manage student records efficiently.</p><h5>Features:</h5><ul><li><strong>Add Student:</strong> Manual entry of student details</li><li><strong>Import CSV:</strong> Bulk import students from CSV file</li><li><strong>Export:</strong> Download student data as CSV</li><li><strong>View Details:</strong> Access individual student information</li></ul><h5>CSV Format:</h5><p>Required columns: name, class<br>Optional: email, phone, gender, dob, parentname, parentphone</p>'
                },
                {
                    title: 'Staff Management',
                    icon: 'fa-user-tie',
                    content: '<h4>Managing Staff Members</h4><p>Create login accounts for teachers, accountants, and directors.</p><h5>Staff Roles:</h5><ul><li><strong>Teachers:</strong> Can take attendance, add scores, manage students</li><li><strong>Accountants:</strong> Manage financial transactions</li><li><strong>Directors:</strong> Full access to school data and reports</li></ul><h5>Creating Staff:</h5><p>Each staff member needs: Name, Username, Email, Phone, Password</p>'
                },
                {
                    title: 'Classes & Subjects',
                    icon: 'fa-book',
                    content: '<h4>Configuring Classes and Subjects</h4><p>Customize which classes and subjects your school offers.</p><h5>Available Classes:</h5><ul><li>Nursery 1-2</li><li>Primary 1-6</li><li>JSS 1-3</li><li>SS 1-3</li></ul><h5>Subjects:</h5><p>Nigerian curriculum subjects are pre-loaded. Enable only those your school teaches.</p>'
                },
                {
                    title: 'Score Settings',
                    icon: 'fa-cog',
                    content: '<h4>Score Types Configuration</h4><p>Choose which assessment types your school uses.</p><h5>Available Types:</h5><ul><li><strong>Daily:</strong> Daily class tests</li><li><strong>Weekly:</strong> Weekly tests (typically Friday)</li><li><strong>Mid-term:</strong> Mid-term examinations</li><li><strong>Exam:</strong> End of term examinations</li></ul><p>Enable only the types your school records.</p>'
                },
                {
                    title: 'Attendance',
                    icon: 'fa-qrcode',
                    content: '<h4>Attendance Management</h4><p>Track student attendance with multiple methods.</p><h5>Methods:</h5><ul><li><strong>Manual:</strong> Select class and mark students present/absent</li><li><strong>QR Scan:</strong> Scan student ID cards for quick attendance</li><li><strong>Mark All:</strong> Quickly mark entire class present</li></ul><h5>Best Practices:</h5><ul><li>Take attendance at the same time daily</li><li>Use QR scanning for efficiency</li><li>Review attendance summaries regularly</li></ul>'
                },
                {
                    title: 'Finance',
                    icon: 'fa-wallet',
                    content: '<h4>Financial Management</h4><p>Track school income and expenses.</p><h5>Features:</h5><ul><li><strong>Add Transaction:</strong> Record income or expenses</li><li><strong>Categories:</strong> Tuition, Books, Salary, Utilities, etc.</li><li><strong>Reports:</strong> View financial summaries</li></ul><h5>Categories:</h5><ul><li>Income: Tuition, Registration, Donations</li><li>Expenses: Salaries, Utilities, Maintenance</li></ul>'
                },
                {
                    title: 'ID Cards',
                    icon: 'fa-id-card',
                    content: '<h4>ID Card Generation</h4><p>Generate and print ID cards for students and staff.</p><h5>Features:</h5><ul><li>Auto-generated QR codes for attendance</li><li>Download as image</li><li>Print directly</li></ul><h5>Card Includes:</h5><ul><li>Name and photo placeholder</li><li>Unique ID number</li><li>QR code for scanning</li><li>Issue and expiry dates</li></ul>'
                }
            ]
        },
        teacher: {
            title: 'Teacher Guide',
            sections: [
                {
                    title: 'Dashboard Overview',
                    icon: 'fa-tachometer-alt',
                    content: '<h4>Welcome, Teacher!</h4><p>Your dashboard provides quick access to students, attendance, scores, and communication tools.</p><h5>Quick Actions:</h5><ul><li>View your assigned students</li><li>Take daily attendance</li><li>Record student scores</li><li>Chat with colleagues</li></ul>'
                },
                {
                    title: 'Managing Students',
                    icon: 'fa-users',
                    content: '<h4>Student Management</h4><p>View and add students to your classes.</p><h5>Features:</h5><ul><li><strong>View Students:</strong> See all students in your assigned class</li><li><strong>Add Student:</strong> Add new students manually</li><li><strong>Import CSV:</strong> Bulk import students</li></ul><h5>Student Details:</h5><p>Each student record includes: Name, Class, Contact info, Parent details</p>'
                },
                {
                    title: 'Taking Attendance',
                    icon: 'fa-clipboard-check',
                    content: '<h4>Attendance Procedures</h4><p>Mark student attendance daily.</p><h5>Steps:</h5><ol><li>Select your class from the dropdown</li><li>Choose today\'s date</li><li>Click "Load" to see student list</li><li>Click on each student to toggle present/absent</li><li>Use "Mark All Present" for quick marking</li></ol><h5>QR Scanning:</h5><p>Enter student ID or scan their ID card for quick attendance.</p>'
                },
                {
                    title: 'Recording Scores',
                    icon: 'fa-star',
                    content: '<h4>Score Entry</h4><p>Record student test and exam scores.</p><h5>Steps:</h5><ol><li>Select class and subject</li><li>Choose term and year</li><li>Click "Load" to see students</li><li>Click "Add Score" to enter marks</li></ol><h5>Score Types:</h5><p>Depending on school settings: Daily, Weekly, Mid-term, Exam</p>'
                },
                {
                    title: 'Communication',
                    icon: 'fa-comments',
                    content: '<h4>Chat System</h4><p>Communicate with other staff members.</p><h5>Features:</h5><ul><li>Direct messaging</li><li>Group chats</li><li>File sharing</li><li>Voice messages</li><li>Emoji support</li></ul>'
                }
            ]
        },
        director: {
            title: 'Director Guide',
            sections: [
                {
                    title: 'Dashboard Overview',
                    icon: 'fa-tachometer-alt',
                    content: '<h4>Welcome, Director!</h4><p>As a Director, you have comprehensive access to monitor and manage school operations.</p><h5>Overview Statistics:</h5><ul><li>Total students and teachers</li><li>Financial balance</li><li>Attendance rates</li></ul>'
                },
                {
                    title: 'Student Management',
                    icon: 'fa-users',
                    content: '<h4>Student Oversight</h4><p>View and manage all students in the school.</p><h5>Capabilities:</h5><ul><li>View all student records</li><li>Add new students</li><li>Import students via CSV</li><li>Export student data</li></ul>'
                },
                {
                    title: 'Staff Overview',
                    icon: 'fa-user-tie',
                    content: '<h4>Staff Management</h4><p>View all teaching and administrative staff.</p><h5>Information Available:</h5><ul><li>Staff names and roles</li><li>Contact information</li><li>Assignments</li></ul>'
                },
                {
                    title: 'Reports',
                    icon: 'fa-file-alt',
                    content: '<h4>Reports & Analytics</h4><p>Generate comprehensive school reports.</p><h5>Report Types:</h5><ul><li>Student performance reports</li><li>Attendance summaries</li><li>Financial reports</li><li>Term reports</li></ul>'
                },
                {
                    title: 'Finance Overview',
                    icon: 'fa-wallet',
                    content: '<h4>Financial Monitoring</h4><p>Monitor school financial status.</p><h5>View:</h5><ul><li>Total income</li><li>Total expenses</li><li>Current balance</li><li>Transaction history</li></ul>'
                }
            ]
        },
        accountant: {
            title: 'Accountant Guide',
            sections: [
                {
                    title: 'Dashboard Overview',
                    icon: 'fa-tachometer-alt',
                    content: '<h4>Welcome, Accountant!</h4><p>Your dashboard focuses on financial management and reporting.</p><h5>Key Metrics:</h5><ul><li>Total income</li><li>Total expenses</li><li>Current balance</li></ul>'
                },
                {
                    title: 'Finance Management',
                    icon: 'fa-wallet',
                    content: '<h4>Managing Finances</h4><p>Record and track all financial transactions.</p><h5>Transaction Types:</h5><ul><li><strong>Income:</strong> Tuition, Registration fees, Donations, Other income</li><li><strong>Expenses:</strong> Salaries, Utilities, Maintenance, Supplies, Other expenses</li></ul><h5>Adding Transactions:</h5><ol><li>Click "Add Transaction"</li><li>Select type (Income/Expense)</li><li>Enter amount and description</li><li>Choose category</li><li>Save</li></ol>'
                },
                {
                    title: 'Reports',
                    icon: 'fa-file-alt',
                    content: '<h4>Financial Reports</h4><p>Generate and export financial reports.</p><h5>Available Reports:</h5><ul><li>Income statements</li><li>Expense reports</li><li>Balance summaries</li><li>Transaction history</li></ul><h5>Export Options:</h5><ul><li>CSV format for spreadsheet analysis</li><li>PDF reports (coming soon)</li></ul>'
                }
            ]
        },
        parent: {
            title: 'Parent Portal Guide',
            sections: [
                {
                    title: 'Getting Started',
                    icon: 'fa-rocket',
                    content: '<h4>Welcome to Parent Portal!</h4><p>This portal allows you to monitor your child\'s academic progress, view report cards, check attendance, and communicate with teachers.</p><h5>What you can do:</h5><ul><li>View your child\'s report cards</li><li>Check attendance records</li><li>View academic performance</li><li>Contact teachers</li><li>Contact the principal</li><li>Download reports</li></ul>'
                },
                {
                    title: 'Viewing Report Cards',
                    icon: 'fa-file-alt',
                    content: '<h4>How to View Report Cards</h4><ol><li>Select your child from the dropdown on the dashboard</li><li>Click "Report Card" in the menu</li><li>Select the term and year</li><li>View the complete report card with all subjects and scores</li></ol><h5>Export Options:</h5><ul><li><strong>PDF:</strong> Click "Export PDF" to download a printable version</li><li><strong>CSV:</strong> Click "Export CSV" for spreadsheet format</li></ul>'
                },
                {
                    title: 'Checking Attendance',
                    icon: 'fa-calendar-check',
                    content: '<h4>View Attendance Records</h4><ol><li>Select your child from the dashboard</li><li>Click "Attendance" in the menu</li><li>View the attendance summary and daily records</li></ol><h5>Understanding the Data:</h5><ul><li>Shows total days, present days, and absent days</li><li>Displays attendance percentage</li><li>Recent attendance history is shown in the table</li></ul>'
                },
                {
                    title: 'Contacting School',
                    icon: 'fa-comments',
                    content: '<h4>Communicating with Teachers</h4><p>You can send messages to your child\'s teacher or the school principal.</p><ol><li>Click "Contact School" in the menu</li><li>Choose to contact the teacher or principal</li><li>Enter a subject and your message</li><li>Click "Send Message"</li></ol><p>Your message will be delivered to the appropriate staff member.</p>'
                },
                {
                    title: 'Troubleshooting',
                    icon: 'fa-question-circle',
                    content: '<h4>Common Issues and Solutions</h4><h5>Can\'t see my child:</h5><p>Contact the school admin to link your account to your child\'s profile.</p><h5>Can\'t login:</h5><p>Check your credentials and make sure you selected the correct school. Contact the school if you forgot your password.</p><h5>Report card shows no scores:</h5><p>Scores are entered by teachers. Contact the teacher or school if you have concerns about missing scores.</p>'
                }
            ]
        },
        student: {
            title: 'Student Portal Guide',
            sections: [
                {
                    title: 'Getting Started',
                    icon: 'fa-rocket',
                    content: '<h4>Welcome to Student Portal!</h4><p>This portal allows you to view your academic information, take online exams, check your scores, and more.</p><h5>What you can do:</h5><ul><li>View your profile and personal information</li><li>Check your scores and academic performance</li><li>Take online tests and exams</li><li>View your attendance record</li><li>Access your class schedule</li><li>View announcements from the school</li></ul>'
                },
                {
                    title: 'Taking Online Exams',
                    icon: 'fa-laptop',
                    content: '<h4>How to Take Online Tests</h4><ol><li>Go to "My Tests" from the menu</li><li>Find the test assigned to your class</li><li>Click "Start Test" to begin</li><li>Answer all questions before the time runs out</li><li>Click "Submit" when done</li></ol><h5>Important Notes:</h5><ul><li>Once submitted, you cannot retake the test</li><li>Make sure you have a stable internet connection</li><li>Do not switch tabs during the exam (it\'s monitored)</li><li>Use the calculator if needed (available in exam header)</li></ul>'
                },
                {
                    title: 'Viewing Your Scores',
                    icon: 'fa-chart-line',
                    content: '<h4>How to Check Your Scores</h4><ol><li>Go to "My Scores" from the menu</li><li>Select the term and year</li><li>View your scores by subject</li></ol><h5>Understanding Your Scores:</h5><ul><li><strong>CA (Continuous Assessment):</strong> Class scores and homework</li><li><strong>Exam:</strong> Terminal exam scores</li><li><strong>Total:</strong> Combined score</li><li><strong>Grade:</strong> Your letter grade (A-F)</li></ul>'
                },
                {
                    title: 'Attendance',
                    icon: 'fa-calendar-check',
                    content: '<h4>Checking Your Attendance</h4><p>You can view your attendance record to ensure you\'re marked present every day.</p><ol><li>Click "My Attendance" in the menu</li><li>View your attendance summary</li><li>Check daily records</li></ol><h5>Tip:</h5><p>Scan the QR code at school entrance daily to mark your attendance automatically!</p>'
                },
                {
                    title: 'Profile & Settings',
                    icon: 'fa-user-cog',
                    content: '<h4>Managing Your Profile</h4><p>Keep your profile information up to date.</p><h5>Update Your Profile:</h5><ol><li>Click "Profile" in the menu</li><li>Edit your name, phone, or email</li><li>Change your password</li><li>Click "Save Changes"</li></ol><h5>Security Tips:</h5><ul><li>Use a strong password</li><li>Don\'t share your login with others</li><li>Log out when using shared devices</li></ul>'
                },
                {
                    title: 'Troubleshooting',
                    icon: 'fa-question-circle',
                    content: '<h4>Common Issues and Solutions</h4><h5>Can\'t start my test:</h5><p>Contact your teacher - the test may not be available yet or may have expired.</p><h5>My score doesn\'t show:</h5><p>Scores are entered by teachers. Contact your teacher if you have concerns.</p><h5>Can\'t login:</h5><p>Check your Student ID and password. Contact the school admin if you forgot your credentials.</p><h5>Technical issues during exam:</h5><p>Contact your teacher immediately. They can reset your test if there are genuine technical issues.</p>'
                }
            ]
        }
    },

    seedDefaultHelpContent() {
        const db = this.getDB();
        db.helpContent = this.DEFAULT_HELP_CONTENT;
        this.saveDB(db);
    },

    getHelpContent(role) {
        const db = this.getDB();
        if (!db.helpContent) {
            db.helpContent = this.DEFAULT_HELP_CONTENT;
            this.saveDB(db);
        }
        return db.helpContent[role] || this.DEFAULT_HELP_CONTENT[role];
    },

    getAllHelpContent() {
        const db = this.getDB();
        if (!db.helpContent) {
            db.helpContent = this.DEFAULT_HELP_CONTENT;
            this.saveDB(db);
        }
        return db.helpContent;
    },

    updateHelpContent(role, content) {
        const db = this.getDB();
        if (!db.helpContent) {
            db.helpContent = this.DEFAULT_HELP_CONTENT;
        }
        db.helpContent[role] = content;
        this.saveDB(db);
        return true;
    },

    updateHelpSection(role, sectionIndex, sectionData) {
        const db = this.getDB();
        if (!db.helpContent) {
            db.helpContent = this.DEFAULT_HELP_CONTENT;
        }
        if (db.helpContent[role] && db.helpContent[role].sections[sectionIndex]) {
            db.helpContent[role].sections[sectionIndex] = sectionData;
            this.saveDB(db);
            return true;
        }
        return false;
    },

    addHelpSection(role, sectionData) {
        const db = this.getDB();
        if (!db.helpContent) {
            db.helpContent = this.DEFAULT_HELP_CONTENT;
        }
        if (db.helpContent[role]) {
            db.helpContent[role].sections.push(sectionData);
            this.saveDB(db);
            return true;
        }
        return false;
    },

    deleteHelpSection(role, sectionIndex) {
        const db = this.getDB();
        if (!db.helpContent) {
            db.helpContent = this.DEFAULT_HELP_CONTENT;
        }
        if (db.helpContent[role] && db.helpContent[role].sections.length > sectionIndex) {
            db.helpContent[role].sections.splice(sectionIndex, 1);
            this.saveDB(db);
            return true;
        }
        return false;
    },

    getDB() {
        return JSON.parse(localStorage.getItem(this.DB_NAME) || '{}');
    },

    saveDB(data) {
        this.saveDBLocal(data);
    },

    getData(key) {
        const db = this.getDB();
        return db[key] || [];
    },

    setData(key, value) {
        const db = this.getDB();
        db[key] = value;
        this.saveDBLocal(db);

        // Notify UI of data update
        window.dispatchEvent(new CustomEvent('skoolar_data_updated', {
            detail: { key, data: value }
        }));
    },

    async setDataAndSync(key, value) {
        // Update local data first
        this.setData(key, value);
        
        // Trigger Supabase sync if enabled
        if (this.useCloudSync && typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
            try {
                await SupabaseSync.syncAllToCloud();
            } catch (e) {
                console.warn('Background sync failed:', e);
            }
        }
        
        return true;
    },

    // In storage.js, modify addItem:
    addItem(key, item) {
        if (key === 'attendance' || key === 'scores') {
            // Update local state immediately for UI responsiveness
            const data = this.getData(key);
            if (!item.id) item.id = this.generateId();
            if (!item.createdAt) item.createdAt = new Date().toISOString();
            item.updatedAt = new Date().toISOString();
            data.push(item);
            this.setData(key, data); // This triggers UI update event via skoolar_data_updated

            // Still use batch processor for cloud sync
            BatchProcessor.add(key, item);
            return item;
        }

        // Regular save for other types
        const data = this.getData(key);
        if (!item.id) {
            item.id = this.generateId();
        }
        if (!item.createdAt) {
            item.createdAt = new Date().toISOString();
        }
        item.updatedAt = new Date().toISOString();
        data.push(item);
        this.setData(key, data);

        // Background sync if enabled - don't await
        // uploadItem now handles waiting for Supabase readiness internally
        if (typeof SupabaseSync !== 'undefined') {
            SupabaseSync.uploadItem(key, item).catch(e => console.warn('Background sync failed:', e));
        }

        return item;
    },

    updateItem(key, id, updates) {
        const data = this.getData(key);
        const index = data.findIndex(item => item.id === id);
        if (index !== -1) {
            data[index] = { ...data[index], ...updates, updatedAt: new Date().toISOString() };
            this.setData(key, data);

            // Background sync update if enabled - don't await
            if (typeof SupabaseSync !== 'undefined') {
                SupabaseSync.uploadItem(key, data[index]).catch(e => console.warn('Background sync failed:', e));
            }

            return data[index];
        }
        return null;
    },

    deleteItem(key, id) {
        const data = this.getData(key);
        const filtered = data.filter(item => item.id !== id);
        this.setData(key, filtered);

        // Background sync delete if enabled - don't await
        // deleteItem now handles waiting for Supabase readiness internally
        if (typeof SupabaseSync !== 'undefined') {
            SupabaseSync.deleteItem(key, id).catch(e => console.warn('Background sync delete failed:', e));
        }
    },

    getItemById(key, id) {
        const data = this.getData(key);
        return data.find(item => item.id === id);
    },

    generateId() {
        return 'id_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
    },

    generateUniqueId(prefix = 'ID') {
        const timestamp = Date.now().toString(36).toUpperCase();
        const random = Math.random().toString(36).substr(2, 5).toUpperCase();
        return `${prefix}-${timestamp}-${random}`;
    },

    seedSuperAdmin() {
        const superAdmin = {
            id: 'sa_001',
            name: 'Odebunmi Tawwāb',
            email: 'odebunmitawwab123@gmail.com',
            phone: '+2349033460322',
            username: 'abduttawwab',
            password: this.hashPassword('Successor1*'),
            role: 'super_admin',
            schoolId: null,
            status: 'active',
            createdAt: new Date().toISOString(),
            avatar: null,
            settings: {
                darkMode: false,
                darkModeSystem: false
            }
        };

        const db = this.getDB();
        if (!db.users) db.users = [];

        const index = db.users.findIndex(u => u.username === superAdmin.username || u.id === superAdmin.id);
        if (index === -1) {
            db.users.push(superAdmin);
            console.log('Super Admin account created');
        } else {
            // Only update if it's the same ID or same username
            db.users[index] = { ...db.users[index], ...superAdmin };
            console.log('Super Admin account updated');
        }

        this.saveDB(db);
    },

    // One-time migration to normalize user role strings
    migrateUserRoles() {
        const MIGRATION_KEY = 'user_roles_migrated_v1';
        if (localStorage.getItem(MIGRATION_KEY)) {
            return; // Already migrated
        }

        const users = this.getData('users') || [];
        if (!Array.isArray(users) || users.length === 0) {
            localStorage.setItem(MIGRATION_KEY, 'true');
            return;
        }

        let changed = false;
        const roleMap = {
            'admin': 'school_admin',
            'Admin': 'school_admin',
            'administrator': 'school_admin',
            'School Admin': 'school_admin',
            'school admin': 'school_admin',
            'Teacher': 'teacher',
            'TEACHER': 'teacher',
            'techer': 'teacher',
            'Class Teacher': 'teacher',
            'Accountant': 'accountant',
            'accountant': 'accountant',
            'Director': 'director',
            'director': 'director',
            'Parent': 'parent',
            'parent': 'parent',
            'Super Admin': 'super_admin',
            'super admin': 'super_admin',
            'SUPER_ADMIN': 'super_admin'
        };

        users.forEach(user => {
            if (user.role && typeof user.role === 'string') {
                const normalized = user.role.toLowerCase().trim();
                if (roleMap[normalized] || roleMap[user.role]) {
                    const newRole = roleMap[normalized] || roleMap[user.role];
                    if (user.role !== newRole) {
                        user.role = newRole;
                        changed = true;
                    }
                }
            }
        });

        if (changed) {
            this.setData('users', users);
            console.log('Storage: User roles migrated to canonical format');
        }

        localStorage.setItem(MIGRATION_KEY, 'true');
    },

    generateActivationCode() {
        const date = new Date();
        const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
        const random = Math.random().toString(36).substr(2, 4).toUpperCase();
        return `ACT-${dateStr}-${random}`;
    },

    generateMultipleCodes(count) {
        const codes = [];
        for (let i = 0; i < count; i++) {
            codes.push({
                id: this.generateId(),
                code: this.generateActivationCode(),
                schoolId: null,
                isUsed: false,
                isRevoked: false,
                expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
                createdAt: new Date().toISOString(),
                createdBy: Auth.getCurrentUser()?.id || 'sa_001',
                usedAt: null,
                usedBySchool: null
            });
        }

        const existing = this.getData('activationCodes');
        const all = [...existing, ...codes];
        this.setData('activationCodes', all);

        return codes;
    },

    hashPassword(password) {
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return hash.toString(16);
    },

    encryptData(data) {
        const jsonString = JSON.stringify(data);
        return btoa(unescape(encodeURIComponent(jsonString)));
    },

    decryptData(encryptedData) {
        try {
            return JSON.parse(decodeURIComponent(escape(atob(encryptedData))));
        } catch (e) {
            return null;
        }
    },

    filterData(key, filters) {
        const data = this.getData(key);
        return data.filter(item => {
            for (const [key, value] of Object.entries(filters)) {
                if (value && item[key] !== value) {
                    return false;
                }
            }
            return true;
        });
    },

    searchData(key, query, searchFields = ['name', 'email']) {
        const data = this.getData(key);
        const lowerQuery = query.toLowerCase();
        return data.filter(item => {
            return searchFields.some(field => {
                const value = item[field];
                return value && value.toString().toLowerCase().includes(lowerQuery);
            });
        });
    },

    paginateData(data, page = 1, limit = 20) {
        const start = (page - 1) * limit;
        const end = start + limit;
        return {
            data: data.slice(start, end),
            total: data.length,
            page,
            limit,
            totalPages: Math.ceil(data.length / limit)
        };
    },

    getSystemSettings() {
        const db = this.getDB();
        return db.systemSettings || {};
    },

    getSystemConfig() {
        return this.getSystemSettings();
    },

    updateSystemSettings(settings) {
        const db = this.getDB();
        db.systemSettings = { ...db.systemSettings, ...settings };
        this.setData('systemSettings', db.systemSettings);
    },

    getAnnouncement() {
        const settings = this.getSystemSettings();
        return settings.announcement || null;
    },

    setAnnouncement(message, isActive = true) {
        const settings = this.getSystemSettings();
        settings.announcement = {
            message: message,
            isActive: isActive,
            updatedAt: new Date().toISOString()
        };
        this.updateSystemSettings(settings);
    },

    clearAnnouncement() {
        const settings = this.getSystemSettings();
        settings.announcement = null;
        this.updateSystemSettings(settings);
    },

    getParentAnnouncements(schoolId) {
        const announcements = this.getData('parentAnnouncements') || [];
        if (schoolId) {
            const target = String(schoolId);
            return announcements.filter(a => String(a.schoolId) === target && a.isActive);
        }
        return announcements.filter(a => a.isActive);
    },

    addParentAnnouncement(message, schoolId, createdBy) {
        const announcements = this.getData('parentAnnouncements') || [];
        const announcement = {
            id: 'pann_' + this.generateId(),
            message: message,
            schoolId: schoolId,
            createdBy: createdBy,
            createdAt: new Date().toISOString(),
            isActive: true
        };
        announcements.push(announcement);
        this.setData('parentAnnouncements', announcements);
        return announcement;
    },

    deleteParentAnnouncement(announcementId) {
        const announcements = this.getData('parentAnnouncements') || [];
        const index = announcements.findIndex(a => a.id === announcementId);
        if (index !== -1) {
            announcements[index].isActive = false;
            this.setData('parentAnnouncements', announcements);
        }
    },

    // Student Messages to School
    getStudentMessages(schoolId) {
        const messages = this.getData('studentMessages') || [];
        if (schoolId) {
            const target = String(schoolId);
            return messages.filter(m => String(m.schoolId) === target).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        }
        return messages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },

    getStudentMessageById(messageId) {
        const messages = this.getData('studentMessages') || [];
        return messages.find(m => m.id === messageId);
    },

    saveStudentMessage(messageData) {
        const messages = this.getData('studentMessages') || [];
        const message = {
            id: 'msg_' + this.generateId(),
            studentId: messageData.studentId,
            studentName: messageData.studentName,
            studentClass: messageData.studentClass,
            schoolId: messageData.schoolId,
            subject: messageData.subject,
            message: messageData.message,
            status: 'unread',
            createdAt: new Date().toISOString(),
            reply: null
        };
        messages.push(message);
        this.setData('studentMessages', messages);
        return message;
    },

    // Parent Messages (Parents contacting school administration)
    getParentMessages(schoolId) {
        const messages = this.getData('parentMessages') || [];
        if (schoolId) {
            const target = String(schoolId);
            return messages.filter(m => String(m.schoolId) === target).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        }
        return messages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },

    getParentMessageById(messageId) {
        const messages = this.getData('parentMessages') || [];
        return messages.find(m => m.id === messageId);
    },

    saveParentMessage(messageData) {
        const messages = this.getData('parentMessages') || [];
        const message = {
            id: 'msg_' + this.generateId(),
            parentId: messageData.parentId,
            parentName: messageData.parentName,
            studentId: messageData.studentId,
            studentName: messageData.studentName,
            schoolId: messageData.schoolId,
            subject: messageData.subject,
            message: messageData.message,
            status: 'unread',
            createdAt: new Date().toISOString(),
            reply: null
        };
        messages.push(message);
        this.setData('parentMessages', messages);
        return message;
    },

    replyToParentMessage(messageId, replyData) {
        const messages = this.getData('parentMessages') || [];
        const message = messages.find(m => m.id === messageId);
        if (message) {
            message.reply = {
                message: replyData.message,
                repliedAt: new Date().toISOString(),
                repliedBy: replyData.repliedBy
            };
            message.status = 'replied';
            this.setData('parentMessages', messages);
            return true;
        }
        return false;
    },

    deleteParentMessage(messageId) {
        const messages = this.getData('parentMessages') || [];
        const filtered = messages.filter(m => m.id !== messageId);
        this.setData('parentMessages', filtered);
        return true;
    },

    markStudentMessageRead(messageId) {
        const messages = this.getData('studentMessages') || [];
        const index = messages.findIndex(m => m.id === messageId);
        if (index !== -1) {
            messages[index].status = 'read';
            this.setData('studentMessages', messages);
            return messages[index];
        }
        return null;
    },

    replyToStudentMessage(messageId, replyData) {
        const messages = this.getData('studentMessages') || [];
        const index = messages.findIndex(m => m.id === messageId);
        if (index !== -1) {
            messages[index].reply = {
                message: replyData.message,
                repliedAt: new Date().toISOString(),
                repliedBy: replyData.repliedBy
            };
            messages[index].status = 'replied';
            this.setData('studentMessages', messages);
            return messages[index];
        }
        return null;
    },

    deleteStudentMessage(messageId) {
        const messages = this.getData('studentMessages') || [];
        const index = messages.findIndex(m => m.id === messageId);
        if (index !== -1) {
            messages.splice(index, 1);
            this.setData('studentMessages', messages);
            return true;
        }
        return false;
    },

    // Super Admin Adverts
    getAdverts() {
        return this.getData('adverts') || [];
    },

    getActiveAdverts() {
        const adverts = this.getAdverts();
        const now = new Date().toISOString();
        return adverts.filter(a => {
            // Check if active
            if (!a.isActive) return false;
            // Check expiration
            if (a.expiresAt && new Date(a.expiresAt) < new Date(now)) return false;
            return true;
        });
    },

    getAdvertsForSchool(schoolId, userRole) {
        const adverts = this.getActiveAdverts();
        return adverts.filter(a => {
            // Check school targeting
            if (a.targetSchools && a.targetSchools.length > 0) {
                if (a.targetSchools.includes('all')) return true;
                if (!a.targetSchools.includes(schoolId)) return false;
            }
            // Check role targeting
            if (a.targetRoles && a.targetRoles.length > 0) {
                if (a.targetRoles.includes('all')) return true;
                if (!a.targetRoles.includes(userRole)) return false;
            }
            return true;
        });
    },

    saveAdvert(advertData) {
        const adverts = this.getAdverts();
        const advert = {
            id: 'adv_' + this.generateId(),
            title: advertData.title || '',
            content: advertData.content || '',
            mediaType: advertData.mediaType || 'text',
            mediaUrl: advertData.mediaUrl || '',
            buttonText: advertData.buttonText || '',
            buttonLink: advertData.buttonLink || '',
            targetSchools: advertData.targetSchools || ['all'],
            targetRoles: advertData.targetRoles || ['all'],
            expiresAt: advertData.expiresAt || null,
            isActive: true,
            createdBy: 'superadmin',
            createdAt: new Date().toISOString(),
            displayOrder: advertData.displayOrder || 0
        };
        adverts.push(advert);
        this.setData('adverts', adverts);
        return advert;
    },

    updateAdvert(advertId, advertData) {
        const adverts = this.getAdverts();
        const index = adverts.findIndex(a => a.id === advertId);
        if (index !== -1) {
            adverts[index] = { ...adverts[index], ...advertData, updatedAt: new Date().toISOString() };
            this.setData('adverts', adverts);
            return adverts[index];
        }
        return null;
    },

    deleteAdvert(advertId) {
        const adverts = this.getAdverts();
        const index = adverts.findIndex(a => a.id === advertId);
        if (index !== -1) {
            adverts.splice(index, 1);
            this.setData('adverts', adverts);
            return true;
        }
        return false;
    },

    toggleAdvertActive(advertId) {
        const adverts = this.getAdverts();
        const index = adverts.findIndex(a => a.id === advertId);
        if (index !== -1) {
            adverts[index].isActive = !adverts[index].isActive;
            this.setData('adverts', adverts);
            return adverts[index];
        }
        return null;
    },

    // ============================================
    // SUPER ADMIN GLOBAL DATA METHODS
    // ============================================

    // Blog Posts
    getBlogPosts() {
        return this.getData('blogPosts') || [];
    },

    getBlogPostById(id) {
        const posts = this.getBlogPosts();
        return posts.find(p => p.id === id);
    },

    getBlogPostBySlug(slug) {
        const posts = this.getBlogPosts();
        return posts.find(p => p.slug === slug);
    },

    saveBlogPost(post) {
        const posts = this.getBlogPosts();
        const index = posts.findIndex(p => p.id === post.id);
        if (index !== -1) {
            posts[index] = { ...posts[index], ...post, updatedAt: new Date().toISOString() };
        } else {
            post.id = post.id || 'bp_' + this.generateId();
            post.createdAt = post.createdAt || new Date().toISOString();
            post.updatedAt = new Date().toISOString();
            posts.push(post);
        }
        this.setData('blogPosts', posts);
        return post;
    },

    deleteBlogPost(id) {
        const posts = this.getBlogPosts();
        const filtered = posts.filter(p => p.id !== id);
        this.setData('blogPosts', filtered);
    },

    // Resources
    getResources() {
        return this.getData('resources') || [];
    },

    getResourceById(id) {
        const resources = this.getResources();
        return resources.find(r => r.id === id);
    },

    saveResource(resource) {
        const resources = this.getResources();
        const index = resources.findIndex(r => r.id === resource.id);
        if (index !== -1) {
            resources[index] = { ...resources[index], ...resource, updatedAt: new Date().toISOString() };
        } else {
            resource.id = resource.id || 'res_' + this.generateId();
            resource.createdAt = resource.createdAt || new Date().toISOString();
            resource.updatedAt = new Date().toISOString();
            resources.push(resource);
        }
        this.setData('resources', resources);
        return resource;
    },

    deleteResource(id) {
        const resources = this.getResources();
        const filtered = resources.filter(r => r.id !== id);
        this.setData('resources', filtered);
    },

    // Pricing
    getPricing() {
        return this.getData('pricing');
    },

    savePricing(pricing) {
        this.setData('pricing', pricing);
        return pricing;
    },

    // Static Pages
    getPages() {
        return this.getData('pages') || {};
    },

    getPage(pageName) {
        const pages = this.getPages();
        return pages[pageName] || null;
    },

    savePage(pageName, pageData) {
        const pages = this.getPages();
        pages[pageName] = {
            ...pageData,
            updatedAt: new Date().toISOString()
        };
        this.setData('pages', pages);
        return pages[pageName];
    },

    // ============================================
    // ACTIVATION CODE CLOUD VALIDATION
    // ============================================

    async validateActivationCodeFromCloud(code) {
        if (typeof getSupabase !== 'function' || typeof isSupabaseEnabled !== 'function' || !isSupabaseEnabled()) {
            return null;
        }

        try {
            const supabase = getSupabase();
            const { data, error } = await supabase
                .from('activation_codes')
                .select('*')
                .eq('code', code)
                .eq('is_used', false)
                .single();

            if (error || !data) return null;

            // Check expiration
            if (new Date(data.expires_at) < new Date()) {
                return null;
            }

            return {
                valid: true,
                code: {
                    id: data.id,
                    code: data.code,
                    isUsed: data.is_used,
                    schoolId: data.school_id,
                    subscriptionDays: data.subscription_days,
                    expiresAt: data.expires_at,
                    createdAt: data.created_at
                }
            };
        } catch (error) {
            console.error('Error checking Supabase for code:', error);
            return null;
        }
    },

    validateActivationCode(code) {
        // First check local storage
        const codes = this.getData('activationCodes');
        const validCode = codes.find(c => c.code === code && !c.isUsed && !c.isRevoked);

        if (validCode) {
            if (new Date(validCode.expiresAt) < new Date()) {
                return { valid: false, message: 'Activation code has expired' };
            }
            return { valid: true, code: validCode };
        }

        // If not found locally and Supabase is available, check cloud
        if (typeof isSupabaseEnabled === 'function' && isSupabaseEnabled()) {
            // Return a promise that resolves with cloud validation
            // This is handled asynchronously in the registration flow
            console.log('Code not found locally, checking Supabase...');
        }

        return { valid: false, message: 'Invalid or already used activation code' };
    },

    useActivationCode(codeId, schoolId) {
        const codes = this.getData('activationCodes');
        const index = codes.findIndex(c => c.id === codeId);

        if (index !== -1) {
            codes[index].isUsed = true;
            codes[index].schoolId = schoolId;
            codes[index].usedAt = new Date().toISOString();
            codes[index].usedBySchool = schoolId;
            this.setData('activationCodes', codes);

            // Auto-sync to Supabase
            if (typeof SupabaseSync !== 'undefined') {
                SupabaseSync.uploadItem('activationCodes', codes[index]).catch(e => console.warn('Code sync failed:', e));
            }

            return true;
        }
        return false;
    },


    revokeActivationCode(codeId) {
        const codes = this.getData('activationCodes');
        const index = codes.findIndex(c => c.id === codeId);

        if (index !== -1) {
            codes[index].isRevoked = true;
            this.setData('activationCodes', codes);
            return true;
        }
        return false;
    },

    updateCodeExpiration(codeId, newExpiration) {
        const codes = this.getData('activationCodes');
        const index = codes.findIndex(c => c.id === codeId);

        if (index !== -1) {
            codes[index].expiresAt = newExpiration;
            this.setData('activationCodes', codes);
            return true;
        }
        return false;
    },

    getSchools() {
        return this.getData('schools');
    },

    updateSchool(id, updates) {
        return this.updateItem('schools', id, updates);
    },

    activateSchool(id, fromDate, toDate) {
        return this.updateItem('schools', id, {
            status: 'active',
            activationFrom: fromDate,
            activationTo: toDate
        });
    },

    deactivateSchool(id) {
        return this.updateItem('schools', id, { status: 'inactive' });
    },

    checkSchoolExpiration(id) {
        const school = this.getItemById('schools', id);
        if (!school || !school.activationTo) return { expired: false, daysLeft: null, school };
        const now = new Date();
        const expiry = new Date(school.activationTo);
        const daysLeft = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
        return { expired: daysLeft < 0, daysLeft, school };
    },

    autoDeactivateExpiredSchools() {
        const schools = this.getData('schools');
        schools.forEach(school => {
            const check = this.checkSchoolExpiration(school.id);
            if (check.expired && school.status !== 'inactive') {
                this.deactivateSchool(school.id);
            }
        });
    },

    getSchoolById(id) {
        return this.getItemById('schools', id);
    },

    getCurrentAcademicYear(schoolId) {
        const school = this.getSchoolById(schoolId);
        if (school && school.currentYear) {
            return school.currentYear;
        }
        return new Date().getFullYear().toString();
    },

    getCurrentAcademicTerm(schoolId) {
        const school = this.getSchoolById(schoolId);
        if (school && school.currentTerm) {
            return school.currentTerm;
        }
        const month = new Date().getMonth();
        if (month >= 0 && month < 4) return 'First Term';
        if (month >= 4 && month < 8) return 'Second Term';
        return 'Third Term';
    },

    updateSchoolSettings(schoolId, settings) {
        const schools = this.getData('schools');
        const index = schools.findIndex(s => s.id === schoolId);
        if (index !== -1) {
            schools[index].settings = { ...schools[index].settings, ...settings };
            this.setData('schools', schools);
            return schools[index];
        }
        return null;
    },

    getSchoolClasses(schoolId) {
        const school = this.getSchoolById(schoolId);
        if (school && school.settings && school.settings.classes) {
            return school.settings.classes;
        }
        return this.DEFAULT_CLASSES;
    },

    getSchoolSubjects(schoolId) {
        const school = this.getSchoolById(schoolId);
        if (school && school.settings && school.settings.subjects) {
            return school.settings.subjects;
        }
        return this.DEFAULT_SUBJECTS;
    },

    getSchoolScoreTypes(schoolId) {
        const school = this.getSchoolById(schoolId);
        if (school && school.settings && school.settings.scoreTypes) {
            return school.settings.scoreTypes;
        }
        return this.SCORE_TYPES;
    },

    getSchoolScoreRanges(schoolId) {
        const school = this.getSchoolById(schoolId);
        if (school && school.settings && school.settings.scoreRanges) {
            return school.settings.scoreRanges;
        }
        return { ...this.DEFAULT_SCORE_RANGES };
    },

    updateSchoolScoreRanges(schoolId, scoreRanges) {
        const schools = this.getData('schools');
        const index = schools.findIndex(s => s.id === schoolId);
        if (index !== -1) {
            schools[index].settings = schools[index].settings || {};
            schools[index].settings.scoreRanges = scoreRanges;
            this.setData('schools', schools);
            return true;
        }
        return false;
    },

    getSchoolCustomSubjects(schoolId, level) {
        const school = this.getSchoolById(schoolId);
        if (school && school.settings && school.settings.subjects && school.settings.subjects.custom) {
            return school.settings.subjects.custom[level] || [];
        }
        return [];
    },

    getUsers(schoolId = null) {
        const users = this.getData('users');
        if (schoolId) {
            const target = String(schoolId);
            return users.filter(u => String(u.schoolId) === target);
        }
        return users;
    },

    getStudents(schoolId) {
        const students = this.getData('students');
        const target = String(schoolId);
        return students.filter(s => String(s.schoolId) === target);
    },

    getUserById(id) {
        return this.getItemById('users', id);
    },

    getStudentsByClass(schoolId, className) {
        const students = this.getData('students');
        const target = String(schoolId);
        return students.filter(s => String(s.schoolId) === target && s.class === className);
    },

    getAttendance(schoolId, date = null, className = null) {
        let attendance = this.getData('attendance');

        if (schoolId) {
            const target = String(schoolId);
            attendance = attendance.filter(a => String(a.schoolId) === target);
        }

        if (date) {
            attendance = attendance.filter(a => a.date === date);
        }

        if (className) {
            attendance = attendance.filter(a => a.class === className);
        }

        return attendance;
    },

    // Staff Attendance (Teacher Sign In/Out with GPS)
    getStaffAttendance(schoolId, filters = {}) {
        let records = this.getData('staffAttendance') || [];

        if (schoolId) {
            const target = String(schoolId);
            records = records.filter(r => String(r.schoolId) === target);
        }

        if (filters.staffId) {
            records = records.filter(r => r.staffId === filters.staffId);
        }

        if (filters.date) {
            records = records.filter(r => r.date === filters.date);
        }

        if (filters.startDate && filters.endDate) {
            records = records.filter(r => r.date >= filters.startDate && r.date <= filters.endDate);
        }

        return records.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    },

    getStaffTodayStatus(schoolId, staffId) {
        const today = new Date().toISOString().split('T')[0];
        const records = this.getStaffAttendance(schoolId, { staffId, date: today });

        const signIn = records.find(r => r.type === 'signin');
        const signOut = records.find(r => r.type === 'signout');

        return {
            signedIn: !!signIn,
            signedOut: !!signOut,
            signInTime: signIn?.time || null,
            signOutTime: signOut?.time || null,
            signInLocation: signIn?.location || null,
            signOutLocation: signOut?.location || null
        };
    },

    recordStaffAttendance(data) {
        const { schoolId, staffId, staffName, type, location } = data;
        const now = new Date();
        const record = {
            id: 'STAFF_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
            schoolId,
            staffId,
            staffName,
            type, // 'signin' or 'signout'
            date: now.toISOString().split('T')[0],
            time: now.toTimeString().split(' ')[0].substr(0, 5),
            timestamp: now.toISOString(),
            location: location || { lat: null, lng: null, address: 'Location not available' }
        };

        this.addItem('staffAttendance', record);
        return record;
    },

    getScores(schoolId, studentId = null, className = null) {
        let scores = this.getData('scores');

        if (schoolId) {
            const target = String(schoolId);
            scores = scores.filter(s => String(s.schoolId) === target);
        }

        if (studentId) {
            scores = scores.filter(s => s.studentId === studentId);
        }

        if (className) {
            scores = scores.filter(s => s.class === className);
        }

        return scores;
    },

    // Score Sessions - Consolidated Daily/Weekly Score Entries
    getScoreSessions(schoolId, filters = {}) {
        let sessions = this.getData('scoreSessions') || [];

        if (schoolId) {
            const target = String(schoolId);
            sessions = sessions.filter(s => String(s.schoolId) === target);
        }

        if (filters.teacherId) {
            sessions = sessions.filter(s => s.teacherId === filters.teacherId);
        }

        if (filters.class) {
            sessions = sessions.filter(s => s.class === filters.class);
        }

        if (filters.subject) {
            sessions = sessions.filter(s => s.subject === filters.subject);
        }

        if (filters.type) {
            sessions = sessions.filter(s => s.type === filters.type);
        }

        if (filters.term) {
            sessions = sessions.filter(s => s.term === filters.term);
        }

        if (filters.year) {
            sessions = sessions.filter(s => s.year === filters.year);
        }

        if (filters.date) {
            sessions = sessions.filter(s => s.date === filters.date);
        }

        return sessions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    },

    // Domain Scores - Cognitive, Affective, Psychomotor
    addDomainScore(domainScore) {
        const scores = this.getData('domainScores') || [];
        domainScore.id = this.generateId();
        domainScore.createdAt = new Date().toISOString();
        scores.push(domainScore);
        this.saveData('domainScores', scores);
        this.triggerUpdate('domainScores');
        
        // Background sync to Supabase
        if (typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
            SupabaseSync.uploadItem('domainScores', domainScore).catch(e => console.warn('Domain score sync failed:', e));
        }
        
        return domainScore;
    },

    getDomainScores(schoolId, filters = {}) {
        let scores = this.getData('domainScores') || [];
        if (schoolId) {
            scores = scores.filter(s => String(s.schoolId) === String(schoolId));
        }
        if (filters.studentId) {
            scores = scores.filter(s => s.studentId === filters.studentId);
        }
        if (filters.class) {
            scores = scores.filter(s => s.class === filters.class);
        }
        if (filters.subject) {
            scores = scores.filter(s => s.subject === filters.subject);
        }
        if (filters.term) {
            scores = scores.filter(s => s.term === filters.term);
        }
        if (filters.year) {
            scores = scores.filter(s => s.year === parseInt(filters.year));
        }
        if (filters.domain) {
            scores = scores.filter(s => s.domain === filters.domain);
        }
        return scores;
    },

    getDomainScore(id) {
        const scores = this.getData('domainScores') || [];
        return scores.find(s => s.id === id);
    },

    updateDomainScore(id, updates) {
        const scores = this.getData('domainScores') || [];
        const index = scores.findIndex(s => s.id === id);
        if (index !== -1) {
            scores[index] = { 
                ...scores[index], 
                ...updates, 
                updatedAt: new Date().toISOString() 
            };
            this.saveData('domainScores', scores);
            this.triggerUpdate('domainScores');
            
            // Background sync to Supabase
            if (typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
                SupabaseSync.uploadItem('domainScores', scores[index]).catch(e => console.warn('Domain score sync failed:', e));
            }
            
            return scores[index];
        }
        return null;
    },

    deleteDomainScore(id) {
        let scores = this.getData('domainScores') || [];
        scores = scores.filter(s => s.id !== id);
        this.saveData('domainScores', scores);
        this.triggerUpdate('domainScores');
    },

    addScoreSession(sessionData) {
        const session = {
            id: this.generateUniqueId('SSN'),
            ...sessionData,
            createdAt: new Date().toISOString()
        };

        this.addItem('scoreSessions', session);
        return session;
    },

    updateScoreSession(sessionId, updates) {
        const sessions = this.getData('scoreSessions') || [];
        const index = sessions.findIndex(s => s.id === sessionId);

        if (index !== -1) {
            sessions[index] = { ...sessions[index], ...updates, updatedAt: new Date().toISOString() };
            this.setData('scoreSessions', sessions);
            
            // Background sync to Supabase
            if (typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
                SupabaseSync.uploadItem('scoreSessions', sessions[index]).catch(e => console.warn('Score session sync failed:', e));
            }
            
            return sessions[index];
        }

        return null;
    },

    deleteScoreSession(sessionId) {
        this.deleteItem('scoreSessions', sessionId);
    },

    getFinance(schoolId, type = null) {
        let finance = this.getData('finance');

        if (schoolId) {
            const target = String(schoolId);
            finance = finance.filter(f => String(f.schoolId) === target);
        }

        if (type) {
            finance = finance.filter(f => f.type === type);
        }

        return finance;
    },

    // Chart of Accounts
    getChartOfAccounts(schoolId) {
        const accounts = this.getData('chart_of_accounts');
        if (!schoolId) return accounts;
        const target = String(schoolId);
        return accounts.filter(a => String(a.schoolId) === target && a.is_active);
    },

    addChartOfAccount(account) {
        return this.addItem('chart_of_accounts', account);
    },

    updateChartOfAccount(id, updates) {
        return this.updateItem('chart_of_accounts', id, updates);
    },

    deleteChartOfAccount(id) {
        return this.deleteItem('chart_of_accounts', id);
    },

    // Budgets
    getBudgets(schoolId, year = null, term = null) {
        let budgets = this.getData('budgets');
        if (schoolId) {
            const target = String(schoolId);
            budgets = budgets.filter(b => String(b.schoolId) === target);
        }
        if (year) {
            budgets = budgets.filter(b => b.academic_year === year);
        }
        if (term) {
            budgets = budgets.filter(b => b.term === term);
        }
        return budgets;
    },

    addBudget(budget) {
        return this.addItem('budgets', budget);
    },

    updateBudget(id, updates) {
        return this.updateItem('budgets', id, updates);
    },

    deleteBudget(id) {
        return this.deleteItem('budgets', id);
    },

    // Accounts Receivable
    getAccountsReceivable(schoolId, status = null) {
        let ar = this.getData('accounts_receivable');
        if (schoolId) {
            const target = String(schoolId);
            ar = ar.filter(a => String(a.school_id) === target);
        }
        if (status) {
            ar = ar.filter(a => a.status === status);
        }
        return ar;
    },

    addAccountReceivable(receivable) {
        return this.addItem('accounts_receivable', receivable);
    },

    updateAccountReceivable(id, updates) {
        return this.updateItem('accounts_receivable', id, updates);
    },

    recordPaymentToReceivable(receivableId, paymentAmount, paymentDate = new Date().toISOString().split('T')[0]) {
        const receivable = this.getItemById('accounts_receivable', receivableId);
        if (!receivable) {
            throw new Error('Receivable not found');
        }

        const newPaidAmount = (receivable.paid_amount || 0) + parseFloat(paymentAmount);
        const isFullyPaid = newPaidAmount >= receivable.amount;

        const updates = {
            paid_amount: newPaidAmount,
            status: isFullyPaid ? 'paid' : 'partial',
            last_payment_date: paymentDate
        };

        return this.updateItem('accounts_receivable', receivableId, updates);
    },

    // Tax Settings
    getTaxSettings(schoolId) {
        const settings = this.getData('tax_settings');
        if (!schoolId) return settings;
        const target = String(schoolId);
        return settings.filter(s => String(s.school_id) === target && s.is_active);
    },

    saveTaxSettings(schoolId, settings) {
        // Remove existing settings for this school
        const allSettings = this.getData('tax_settings');
        const filtered = allSettings.filter(s => String(s.school_id) !== String(schoolId));

        // Add new settings
        const newSettings = settings.map(s => ({
            ...s,
            school_id: schoolId,
            id: this.generateId(),
            created_at: new Date().toISOString()
        }));

        const updated = [...filtered, ...newSettings];
        this.setData('tax_settings', updated);
        return newSettings;
    },

    // Financial Attachments
    getTransactionAttachments(transactionId) {
        const attachments = this.getData('financial_attachments');
        return attachments.filter(a => a.transaction_id === transactionId);
    },

    addTransactionAttachment(attachment) {
        return this.addItem('financial_attachments', attachment);
    },

    deleteTransactionAttachment(id) {
        return this.deleteItem('financial_attachments', id);
    },

    // Receipts (shortcut methods)
    getReceipts(schoolId) {
        const receipts = this.getData('receipts');
        if (!schoolId) return receipts;
        const target = String(schoolId);
        return receipts.filter(r => String(r.school_id) === target);
    },

    // Helper: Get default Chart of Accounts for a new school
    getDefaultChartOfAccounts() {
        return [
            // Assets
            { account_code: '1000', account_name: 'Cash in Hand', account_type: 'asset', sub_type: 'Current Asset', is_default: true },
            { account_code: '1010', account_name: 'Bank Account', account_type: 'asset', sub_type: 'Current Asset', is_default: true },
            { account_code: '1100', account_name: 'Accounts Receivable', account_type: 'asset', sub_type: 'Current Asset', is_default: true },
            { account_code: '1200', account_name: 'Fixed Assets', account_type: 'asset', sub_type: 'Fixed Asset', is_default: true },
            { account_code: '1300', account_name: 'Prepaid Expenses', account_type: 'asset', sub_type: 'Current Asset', is_default: true },
            
            // Liabilities
            { account_code: '2000', account_name: 'Accounts Payable', account_type: 'liability', sub_type: 'Current Liability', is_default: true },
            { account_code: '2100', account_name: 'Accrued Expenses', account_type: 'liability', sub_type: 'Current Liability', is_default: true },
            { account_code: '2200', account_name: 'Loans Payable', account_type: 'liability', sub_type: 'Long-term Liability', is_default: true },
            
            // Equity
            { account_code: '3000', account_name: 'Capital Fund', account_type: 'equity', sub_type: 'Equity', is_default: true },
            { account_code: '3100', account_name: 'Retained Earnings', account_type: 'equity', sub_type: 'Equity', is_default: true },
            
            // Income
            { account_code: '4000', account_name: 'Tuition Fees', account_type: 'income', sub_type: 'Operating Revenue', is_default: true },
            { account_code: '4010', account_name: 'Registration Fees', account_type: 'income', sub_type: 'Operating Revenue', is_default: true },
            { account_code: '4020', account_name: 'Examination Fees', account_type: 'income', sub_type: 'Operating Revenue', is_default: true },
            { account_code: '4030', account_name: 'Hostel Fees', account_type: 'income', sub_type: 'Operating Revenue', is_default: true },
            { account_code: '4040', account_name: 'Transportation Fees', account_type: 'income', sub_type: 'Operating Revenue', is_default: true },
            { account_code: '4050', account_name: 'Donations', account_type: 'income', sub_type: 'Non-operating Revenue', is_default: true },
            { account_code: '4090', account_name: 'Other Income', account_type: 'income', sub_type: 'Operating Revenue', is_default: true },
            
            // Expenses
            { account_code: '5000', account_name: 'Salaries - Teaching Staff', account_type: 'expense', sub_type: 'Personnel', is_default: true },
            { account_code: '5010', account_name: 'Salaries - Admin Staff', account_type: 'expense', sub_type: 'Personnel', is_default: true },
            { account_code: '5020', account_name: 'Salaries - Support Staff', account_type: 'expense', sub_type: 'Personnel', is_default: true },
            { account_code: '5100', account_name: 'Utilities - Electricity', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5110', account_name: 'Utilities - Water', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5120', account_name: 'Utilities - Internet', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5200', account_name: 'Rent', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5300', account_name: 'Maintenance', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5310', account_name: 'Repairs', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5400', account_name: 'Supplies - Office', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5410', account_name: 'Supplies - Teaching', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5500', account_name: 'Transportation', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5600', account_name: 'Insurance', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5700', account_name: 'Marketing', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5800', account_name: 'Professional Services', account_type: 'expense', sub_type: 'Operating', is_default: true },
            { account_code: '5900', account_name: 'Miscellaneous', account_type: 'expense', sub_type: 'Operating', is_default: true }
        ];
    },

    seedChartOfAccountsForSchool(schoolId) {
        const existing = this.getChartOfAccounts(schoolId);
        if (existing.length > 0) {
            return; // Already seeded
        }

        const defaultAccounts = this.getDefaultChartOfAccounts();
        const accountsToAdd = defaultAccounts.map(acc => ({
            ...acc,
            id: this.generateId(),
            school_id: schoolId,
            created_by: null
        }));

        const allAccounts = this.getData('chart_of_accounts');
        this.setData('chart_of_accounts', [...allAccounts, ...accountsToAdd]);
    },

    ensureSchoolHasChartOfAccounts(schoolId) {
        const accounts = this.getChartOfAccounts(schoolId);
        if (accounts.length === 0) {
            this.seedChartOfAccountsForSchool(schoolId);
            console.log('Seeded default Chart of Accounts for school:', schoolId);
        }
        // Migrate old finance records to use accounts
        this.migrateFinanceToAccounts(schoolId);
    },

    // Migration: Link old finance records to Chart of Accounts
    migrateFinanceToAccounts(schoolId) {
        const finance = this.getData('finance');
        const accounts = this.getChartOfAccounts(schoolId);
        let updatedCount = 0;

        // Mapping from old categories to new account names
        const categoryToAccount = {
            'Tuition': 'Tuition Fees',
            'Salary': 'Salaries',
            'Maintenance': 'Maintenance',
            'Supplies': 'Supplies'
            // Add more as needed
        };

        finance.forEach(record => {
            if (record.school_id === schoolId && !record.account_id) {
                const accountName = categoryToAccount[record.category] || record.category;
                const account = accounts.find(acc => 
                    acc.account_name.toLowerCase().includes(accountName.toLowerCase()) ||
                    accountName.toLowerCase().includes(acc.account_name.toLowerCase())
                );

                if (account) {
                    record.account_id = account.id;
                    updatedCount++;
                }
            }
        });

        if (updatedCount > 0) {
            this.setData('finance', finance);
            console.log(`Migrated ${updatedCount} finance records to Chart of Accounts`);
        }
    },

    getChats(schoolId) {
        const chats = this.getData('chats');
        const target = String(schoolId);
        return chats.filter(c => String(c.schoolId) === target);
    },

    getMessages(chatId) {
        const db = this.getDB();
        const chats = db.chats || [];
        const chat = chats.find(c => c.id === chatId);
        return chat ? chat.messages : [];
    },

    getClasses(schoolId) {
        const students = this.getStudents(schoolId);
        const classes = [...new Set(students.map(s => s.class))];
        return classes.sort();
    },

    exportAllData() {
        const db = this.getDB();

        const exportData = {
            exportDate: new Date().toISOString(),
            version: '1.0',
            systemSettings: db.systemSettings,
            schools: db.schools,
            users: db.users.map(u => ({
                ...u,
                password: u.password
            })),
            students: db.students,
            attendance: db.attendance,
            scores: db.scores,
            finance: db.finance,
            chats: db.chats,
            activationCodes: db.activationCodes,
            staffAttendance: db.staffAttendance || []
        };

        return JSON.stringify(exportData, null, 2);
    },

    importData(jsonData) {
        try {
            const data = JSON.parse(jsonData);

            if (!data.version) {
                throw new Error('Invalid backup file');
            }

            const db = this.getDB();
            db.systemSettings = data.systemSettings || db.systemSettings;
            db.schools = data.schools || [];
            db.users = data.users || [];
            db.students = data.students || [];
            db.attendance = data.attendance || [];
            db.scores = data.scores || [];
            db.finance = data.finance || [];
            db.chats = data.chats || [];
            db.activationCodes = data.activationCodes || [];
            db.staffAttendance = data.staffAttendance || [];

            this.saveDB(db);
            return { success: true };
        } catch (e) {
            return { success: false, message: e.message };
        }
    },

    resetSystem() {
        localStorage.removeItem(this.DB_NAME);
        this.init();
    },

    deleteSchool(schoolId) {
        const schools = this.getData('schools');
        const users = this.getData('users');
        const students = this.getData('students');
        const attendance = this.getData('attendance');
        const scores = this.getData('scores');
        const finance = this.getData('finance');
        const chats = this.getData('chats');
        const staffAttendance = this.getData('staffAttendance');

        this.setData('schools', schools.filter(s => s.id !== schoolId));
        this.setData('users', users.filter(u => u.schoolId !== schoolId));
        this.setData('students', students.filter(s => s.schoolId !== schoolId));
        this.setData('attendance', attendance.filter(a => a.schoolId !== schoolId));
        this.setData('scores', scores.filter(s => s.schoolId !== schoolId));
        this.setData('finance', finance.filter(f => f.schoolId !== schoolId));
        this.setData('chats', chats.filter(c => c.schoolId !== schoolId));
        this.setData('staffAttendance', staffAttendance.filter(sa => sa.schoolId !== schoolId));

        const codes = this.getData('activationCodes');
        const updatedCodes = codes.map(c => {
            if (c.schoolId === schoolId) {
                return { ...c, isUsed: false, schoolId: null, usedAt: null, usedBySchool: null };
            }
            return c;
        });
        this.setData('activationCodes', updatedCodes);
    },

    getAllDataStats() {
        const db = this.getDB();

        return {
            schools: db.schools.length,
            users: db.users.length,
            students: db.students.length,
            attendance: db.attendance.length,
            scores: db.scores.length,
            finance: db.finance.length,
            chats: db.chats.length,
            activationCodes: db.activationCodes.length,
            staffAttendance: db.staffAttendance ? db.staffAttendance.length : 0,
            totalSchoolsActive: db.schools.filter(s => s.status === 'active').length
        };
    },

    checkSchoolExpiration(schoolId) {
        const school = this.getSchoolById(schoolId);
        if (!school) return { expired: true, message: 'School not found' };

        if (!school.expiresAt) {
            return { expired: false, school };
        }

        const expiresAt = new Date(school.expiresAt);
        const now = new Date();

        if (expiresAt < now) {
            return {
                expired: true,
                message: 'School subscription has expired. Please contact administrator.',
                school
            };
        }

        const daysLeft = Math.ceil((expiresAt - now) / (1000 * 60 * 60 * 24));
        return {
            expired: false,
            daysLeft,
            school
        };
    },

    updateSchoolExpiration(schoolId, newExpiration) {
        const schools = this.getData('schools');
        const index = schools.findIndex(s => s.id === schoolId);

        if (index !== -1) {
            schools[index].expiresAt = newExpiration;
            schools[index].subscriptionExtended = true;
            schools[index].lastExtended = new Date().toISOString();
            this.setData('schools', schools);
            return true;
        }
        return false;
    },

    getExpiredSchools() {
        const schools = this.getData('schools');
        const now = new Date();

        return schools.filter(school => {
            if (!school.expiresAt) return false;
            return new Date(school.expiresAt) < now;
        });
    },

    getExpiringSchools(days = 30) {
        const schools = this.getData('schools');
        const now = new Date();
        const future = new Date();
        future.setDate(future.getDate() + days);

        return schools.filter(school => {
            if (!school.expiresAt) return false;
            const expDate = new Date(school.expiresAt);
            return expDate >= now && expDate <= future;
        });
    },

    checkActivationCodeExpiration(codeId) {
        const codes = this.getData('activationCodes');
        const code = codes.find(c => c.id === codeId);

        if (!code) return { expired: true, message: 'Code not found' };

        if (code.isUsed || code.isRevoked) {
            return { expired: false, code };
        }

        const expiresAt = new Date(code.expiresAt);
        const now = new Date();

        if (expiresAt < now) {
            return {
                expired: true,
                message: 'Activation code has expired. Please obtain a new code.',
                code
            };
        }

        return { expired: false, code };
    },

    renewSchoolSubscription(schoolId, days) {
        const school = this.getSchoolById(schoolId);
        let newExpiresAt;

        if (school && school.expiresAt && new Date(school.expiresAt) > new Date()) {
            const currentExp = new Date(school.expiresAt);
            currentExp.setDate(currentExp.getDate() + days);
            newExpiresAt = currentExp.toISOString();
        } else {
            newExpiresAt = new Date();
            newExpiresAt.setDate(newExpiresAt.getDate() + days);
            newExpiresAt = newExpiresAt.toISOString();
        }

        return this.updateSchoolExpiration(schoolId, newExpiresAt);
    },

    createBackup() {
        const db = this.getDB();
        const backup = {
            version: '2.0',
            backupDate: new Date().toISOString(),
            description: 'Manual backup before Phase 1 upgrades',
            data: db
        };

        const backups = JSON.parse(localStorage.getItem('systemBackups') || '[]');
        backups.push({
            id: this.generateId(),
            date: backup.backupDate,
            description: backup.description,
            size: JSON.stringify(backup).length
        });

        localStorage.setItem('systemBackups', JSON.stringify(backups));
        localStorage.setItem('latestBackup', JSON.stringify(backup));

        return backup;
    },

    downloadBackup() {
        const backup = this.createBackup();
        const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `school_system_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        return true;
    },

    getBackups() {
        return JSON.parse(localStorage.getItem('systemBackups') || '[]');
    },

    restoreBackup(backupData) {
        try {
            const data = typeof backupData === 'string' ? JSON.parse(backupData) : backupData;
            if (!data.version || !data.data) {
                throw new Error('Invalid backup format');
            }
            localStorage.setItem(this.DB_NAME, JSON.stringify(data.data));
            return { success: true, message: 'Backup restored successfully' };
        } catch (e) {
            return { success: false, message: e.message };
        }
    },

    updateSchoolSubjects(schoolId, subjects) {
        const school = this.getSchoolById(schoolId);
        if (school) {
            school.settings = school.settings || {};
            school.settings.subjects = subjects;
            return this.updateItem('schools', schoolId, { settings: school.settings });
        }
        return null;
    },

    updateSchoolScoreTypes(schoolId, scoreTypes) {
        const school = this.getSchoolById(schoolId);
        if (school) {
            school.settings = school.settings || {};
            school.settings.scoreTypes = scoreTypes;
            return this.updateItem('schools', schoolId, { settings: school.settings });
        }
        return null;
    },

    getSchoolProfile(schoolId) {
        const school = this.getSchoolById(schoolId);
        if (school) {
            return {
                name: school.name || '',
                address: school.address || '',
                phone: school.phone || '',
                email: school.email || '',
                website: school.website || '',
                logo: school.logo || null,
                motto: school.motto || '',
                established: school.established || '',
                registrationNumber: school.registrationNumber || ''
            };
        }
        return null;
    },

    updateSchoolProfile(schoolId, profile) {
        const school = this.getSchoolById(schoolId);
        if (school) {
            const updates = {
                name: profile.name,
                address: profile.address,
                phone: profile.phone,
                email: profile.email,
                website: profile.website,
                motto: profile.motto,
                established: profile.established,
                registrationNumber: profile.registrationNumber
            };

            if (profile.logo !== undefined) {
                updates.logo = profile.logo;
            }

            return this.updateItem('schools', schoolId, updates);
        }
        return null;
    },

    logAudit(userId, schoolId, action, entityType, entityId, oldValues = null, newValues = null) {
        const logs = this.getData('auditLog') || [];
        logs.unshift({
            id: this.generateId(),
            userId: userId,
            schoolId: schoolId,
            action: action,
            entityType: entityType,
            entityId: entityId,
            oldValues: oldValues,
            newValues: newValues,
            userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : null,
            createdAt: new Date().toISOString()
        });
        this.setData('auditLog', logs);
        
         // Disabled to reduce usage
         // if (this.useCloudSync && typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
         //     SupabaseSync.uploadAuditLog([logs[0]]).catch(err => console.warn('Audit log sync failed:', err));
         // }
    },

    getAuditLog(filters = {}) {
        let logs = this.getData('auditLog') || [];
        
        if (filters.schoolId) {
            logs = logs.filter(l => l.schoolId === filters.schoolId);
        }
        if (filters.userId) {
            logs = logs.filter(l => l.userId === filters.userId);
        }
        if (filters.action) {
            logs = logs.filter(l => l.action === filters.action);
        }
        if (filters.entityType) {
            logs = logs.filter(l => l.entityType === filters.entityType);
        }
        if (filters.dateFrom) {
            logs = logs.filter(l => l.createdAt >= filters.dateFrom);
        }
        if (filters.dateTo) {
            logs = logs.filter(l => l.createdAt <= filters.dateTo);
        }
        
        logs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        return logs;
    },

    logSync(syncType, direction, recordsCount, status, errorMessage = null) {
        const logs = this.getData('syncLog') || [];
        logs.unshift({
            id: this.generateId(),
            syncType: syncType,
            direction: direction,
            recordsCount: recordsCount,
            status: status,
            errorMessage: errorMessage,
            createdAt: new Date().toISOString()
        });
        this.setData('syncLog', logs);
        
        if (this.useCloudSync && typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
            SupabaseSync.uploadSyncLog([logs[0]]).catch(err => console.warn('Sync log upload failed:', err));
        }
    },

    getSyncLog(filters = {}) {
        let logs = this.getData('syncLog') || [];
        
        if (filters.status) {
            logs = logs.filter(l => l.status === filters.status);
        }
        if (filters.syncType) {
            logs = logs.filter(l => l.syncType === filters.syncType);
        }
        if (filters.dateFrom) {
            logs = logs.filter(l => l.createdAt >= filters.dateFrom);
        }
        
        logs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        return logs;
    },

     clearOldSyncLog(daysToKeep = 90) {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);
        const logs = this.getData('syncLog') || [];
        const filtered = logs.filter(l => new Date(l.createdAt) >= cutoffDate);
        this.setData('syncLog', filtered);
    },

    // Homework Submission Methods
    getHomeworkSubmissions(homeworkId) {
        const homework = this.getData('homework')?.find(h => h.id === homeworkId);
        return homework?.submissions || [];
    },

    addHomeworkSubmission(homeworkId, studentId, studentName, answerText, attachments = []) {
        const homework = this.getData('homework')?.find(h => h.id === homeworkId);
        if (!homework) {
            throw new Error('Homework not found');
        }
        
        const submission = {
            id: this.generateId(),
            studentId,
            studentName,
            submissionDate: new Date().toISOString(),
            status: 'submitted',
            answerText,
            attachments,
            grade: null,
            feedback: '',
            gradedBy: null,
            gradedAt: null
        };
        
        if (!homework.submissions) {
            homework.submissions = [];
        }
        homework.submissions.push(submission);
        
        this.updateItem('homework', homeworkId, { submissions: homework.submissions });
        
        if (this.useCloudSync && typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
            // Sync will handle this through normal homework sync
        }
        
        return submission;
    },

    updateHomeworkSubmission(homeworkId, submissionId, updates) {
        const homework = this.getData('homework')?.find(h => h.id === homeworkId);
        if (!homework || !homework.submissions) {
            throw new Error('Homework or submissions not found');
        }
        
        const submissionIndex = homework.submissions.findIndex(s => s.id === submissionId);
        if (submissionIndex === -1) {
            throw new Error('Submission not found');
        }
        
        homework.submissions[submissionIndex] = {
            ...homework.submissions[submissionIndex],
            ...updates,
            gradedAt: updates.grade !== undefined ? new Date().toISOString() : homework.submissions[submissionIndex].gradedAt
        };
        
        this.updateItem('homework', homeworkId, { submissions: homework.submissions });
    },

     getStudentHomeworkSubmissions(studentId, schoolId, homeworkId = null) {
         // Get submissions from separate normalized collection
         let submissions = this.getData('homework_submissions')?.filter(s => 
             s.studentId === studentId && 
             s.schoolId === schoolId && 
             (homeworkId ? s.homeworkId === homeworkId : true)
         ) || [];
         
         // Sort by submission date descending
         submissions.sort((a, b) => new Date(b.submissionDate) - new Date(a.submissionDate));
         
         // Enrich with homework details
         const homeworks = this.getData('homework') || [];
         return submissions.map(submission => {
             const homework = homeworks.find(h => h.id === submission.homeworkId);
             return {
                 ...submission,
                 homeworkTitle: homework?.title || 'Unknown',
                 homeworkSubject: homework?.subject || '',
                 dueDate: homework?.due_date || '',
                 totalMarks: homework?.total_marks || 100
             };
         });
     },

    // Library Book Loan Methods
   borrowBook(bookId, studentId, studentName, schoolId, dueDate = null) {
        const book = this.getData('library_books')?.find(b => b.id === bookId);
        if (!book) {
            throw new Error('Book not found');
        }
        
        if (book.available <= 0) {
            throw new Error('No copies available');
        }
        
        // Check if student already has this book
        const existingLoan = this.getData('bookLoans')?.find(l => 
            l.bookId === bookId && l.studentId === studentId && l.status === 'borrowed'
        );
        if (existingLoan) {
            throw new Error('You already have this book borrowed');
        }
        
        const loanId = this.generateId();
        const loanDueDate = dueDate || this.calculateLibraryDueDate(30); // 30 days from now
        
        const loan = {
            id: loanId,
            schoolId,
            bookId,
            studentId,
            studentName,
            checkoutDate: new Date().toISOString().split('T')[0],
            dueDate: loanDueDate,
            returnDate: null,
            status: 'borrowed',
            fineAmount: 0,
            createdAt: new Date().toISOString()
        };
        
        // Decrease available count
        const updatedBook = {
            ...book,
            available: book.available - 1,
            status: book.available - 1 === 0 ? 'borrowed' : book.status
        };
        
        this.updateItem('library_books', bookId, { 
            available: updatedBook.available,
            status: updatedBook.status
        });
        
        const loans = this.getData('bookLoans') || [];
        loans.push(loan);
        this.setData('bookLoans', loans);
        
        return loan;
    },

    returnBook(loanId) {
        const loans = this.getData('bookLoans') || [];
        const loanIndex = loans.findIndex(l => l.id === loanId);
        
        if (loanIndex === -1) {
            throw new Error('Loan not found');
        }
        
        const loan = loans[loanIndex];
        if (loan.status === 'returned') {
            throw new Error('Book already returned');
        }
        
        // Calculate fine if overdue
        const dueDate = new Date(loan.dueDate);
        const returnDate = new Date();
        const fine = this.calculateLibraryFine(dueDate, returnDate, loan.schoolId);
        
        loan.status = 'returned';
        loan.returnDate = returnDate.toISOString().split('T')[0];
        loan.fineAmount = fine;
        
        loans[loanIndex] = loan;
        this.setData('bookLoans', loans);
        
        // Increase book available count
        const book = this.getData('library_books')?.find(b => b.id === loan.bookId);
        if (book) {
            this.updateItem('library_books', loan.bookId, {
                available: book.available + 1,
                status: 'available'
            });
        }
        
        return loan;
    },

    getStudentLoans(studentId, schoolId, status = null) {
        let loans = this.getData('bookLoans')?.filter(l => 
            l.studentId === studentId && l.schoolId === schoolId
        ) || [];
        
        if (status) {
            loans = loans.filter(l => l.status === status);
        }
        
        return loans.sort((a, b) => new Date(b.checkoutDate) - new Date(a.checkoutDate));
    },

    getOverdueLoans(schoolId) {
        const today = new Date().toISOString().split('T')[0];
        return this.getData('bookLoans')?.filter(l => 
            l.schoolId === schoolId &&
            l.status === 'borrowed' &&
            l.dueDate < today
        ) || [];
    },

    calculateLibraryDueDate(days = 30) {
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + days);
        return dueDate.toISOString().split('T')[0];
    },

    calculateLibraryFine(dueDate, returnDate, schoolId = null) {
        const due = new Date(dueDate);
        const returned = new Date(returnDate);
        const daysOverdue = Math.max(0, Math.floor((returned - due) / (1000 * 60 * 60 * 24)));
        
        let finePerDay = 1.00; // default $1 per day
        
        if (schoolId) {
            const school = this.getSchoolById(schoolId);
            if (school?.settings?.libraryFineRate) {
                finePerDay = parseFloat(school.settings.libraryFineRate);
                if (isNaN(finePerDay) || finePerDay <= 0) finePerDay = 1.00;
            }
        }
        
        return parseFloat((daysOverdue * finePerDay).toFixed(2));
    },

    getLibraryBooks(schoolId, search = '', category = '') {
        let books = this.getData('library_books')?.filter(b => b.schoolId === schoolId) || [];
        
        if (search) {
            const searchLower = search.toLowerCase();
            books = books.filter(b => 
                (b.title && b.title.toLowerCase().includes(searchLower)) ||
                (b.author && b.author.toLowerCase().includes(searchLower)) ||
                (b.isbn && b.isbn.includes(search))
            );
        }
        
        if (category) {
            books = books.filter(b => b.category === category);
        }
        
         return books.sort((a, b) => a.title.localeCompare(b.title));
     },

     // ============================================
     // TEACHERS TABLE
     // ============================================
     getTeachers(schoolId) {
         const teachers = this.getData('teachers') || [];
         return schoolId ? teachers.filter(t => t.schoolId === schoolId) : teachers;
     },

     getTeacherById(teacherId) {
         return this.getData('teachers')?.find(t => t.id === teacherId);
     },

     getTeacherByUserId(userId) {
         return this.getData('teachers')?.find(t => t.userId === userId);
     },

     addTeacher(teacher) {
         teacher.id = teacher.id || this.generateUniqueId('TCH');
         teacher.created_at = teacher.created_at || new Date().toISOString();
         teacher.supabase_last_sync = null;
         
         const teachers = this.getData('teachers') || [];
         teachers.push(teacher);
         this.setData('teachers', teachers);
         return teacher;
     },

     updateTeacher(teacherId, updates) {
         const teachers = this.getData('teachers') || [];
         const index = teachers.findIndex(t => t.id === teacherId);
         if (index === -1) return null;
         
         teachers[index] = {
             ...teachers[index],
             ...updates,
             updated_at: new Date().toISOString()
         };
         this.setData('teachers', teachers);
         return teachers[index];
     },

     deleteTeacher(teacherId) {
         let teachers = this.getData('teachers') || [];
         teachers = teachers.filter(t => t.id !== teacherId);
         this.setData('teachers', teachers);
         // Also delete associated user?
         return true;
     },

     // ============================================
     // TIMETABLE TABLE
     // ============================================
     getTimetable(schoolId, filters = {}) {
         let timetable = this.getData('timetable')?.filter(t => t.schoolId === schoolId) || [];
         
         if (filters.class) {
             timetable = timetable.filter(t => t.class === filters.class);
         }
         if (filters.dayOfWeek) {
             timetable = timetable.filter(t => t.dayOfWeek === filters.dayOfWeek);
         }
         if (filters.term) {
             timetable = timetable.filter(t => t.term === filters.term);
         }
         if (filters.year) {
             timetable = timetable.filter(t => t.year === filters.year);
         }
         
         return timetable.sort((a, b) => {
             const dayOrder = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
             const dayDiff = dayOrder.indexOf(a.dayOfWeek) - dayOrder.indexOf(b.dayOfWeek);
             if (dayDiff !== 0) return dayDiff;
             return a.periodNumber - b.periodNumber;
         });
     },

      addTimetableEntry(entry) {
          entry.id = entry.id || this.generateUniqueId('TIM');
          entry.created_at = entry.created_at || new Date().toISOString();
          entry.supabase_last_sync = null;
          
          const timetable = this.getData('timetable') || [];
          timetable.push(entry);
          this.setData('timetable', timetable);
          
          // Trigger background sync if enabled
          if (this.useCloudSync && typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
              SupabaseSync.syncAllToCloud().catch(e => console.warn('Background sync failed:', e));
          }
          
          return entry;
      },

     updateTimetableEntry(entryId, updates) {
         const timetable = this.getData('timetable') || [];
         const index = timetable.findIndex(t => t.id === entryId);
         if (index === -1) return null;
         
         timetable[index] = {
             ...timetable[index],
             ...updates,
             updated_at: new Date().toISOString()
         };
         this.setData('timetable', timetable);
         return timetable[index];
     },

     deleteTimetableEntry(entryId) {
         let timetable = this.getData('timetable') || [];
         timetable = timetable.filter(t => t.id !== entryId);
         this.setData('timetable', timetable);
         return true;
     },

     // ============================================
     // EXAMS TABLE
     // ============================================
     getExams(schoolId, filters = {}) {
         let exams = this.getData('exams')?.filter(e => e.schoolId === schoolId) || [];
         
         if (filters.status) {
             exams = exams.filter(e => e.status === filters.status);
         }
         if (filters.subject) {
             exams = exams.filter(e => e.subject === filters.subject);
         }
         if (filters.class) {
             exams = exams.filter(e => e.class === filters.class);
         }
         
         return exams.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
     },

     getExamById(examId) {
         return this.getData('exams')?.find(e => e.id === examId);
     },

     addExam(exam) {
         exam.id = exam.id || this.generateUniqueId('EXAM');
         exam.created_at = exam.created_at || new Date().toISOString();
         exam.supabase_last_sync = null;
         
         const exams = this.getData('exams') || [];
         exams.push(exam);
         this.setData('exams', exams);
         return exam;
     },

     updateExam(examId, updates) {
         const exams = this.getData('exams') || [];
         const index = exams.findIndex(e => e.id === examId);
         if (index === -1) return null;
         
         exams[index] = {
             ...exams[index],
             ...updates,
             updated_at: new Date().toISOString()
         };
         this.setData('exams', exams);
         return exams[index];
     },

     deleteExam(examId) {
         let exams = this.getData('exams') || [];
         exams = exams.filter(e => e.id !== examId);
         this.setData('exams', exams);
         // Also delete related questions and results
         this.deleteData('exam_questions', q => q.exam_id === examId);
         this.deleteData('test_results', r => r.test_id === examId); // using test_results for now
         return true;
     },

     // ============================================
     // EXAM QUESTIONS TABLE
     // ============================================
     getExamQuestions(examId) {
         return this.getData('exam_questions')?.filter(q => q.examId === examId) || [];
     },

     addExamQuestion(question) {
         question.id = question.id || this.generateUniqueId('EQ');
         question.created_at = question.created_at || new Date().toISOString();
         
         const questions = this.getData('exam_questions') || [];
         questions.push(question);
         this.setData('exam_questions', questions);
         return question;
     },

     updateExamQuestion(questionId, updates) {
         const questions = this.getData('exam_questions') || [];
         const index = questions.findIndex(q => q.id === questionId);
         if (index === -1) return null;
         
         questions[index] = { ...questions[index], ...updates };
         this.setData('exam_questions', questions);
         return questions[index];
     },

     deleteExamQuestion(questionId) {
         let questions = this.getData('exam_questions') || [];
         questions = questions.filter(q => q.id !== questionId);
         this.setData('exam_questions', questions);
         return true;
     },

     // ============================================
     // EXAM RESULTS TABLE
     // ============================================
     getExamResults(examId) {
         return this.getData('exam_results')?.filter(r => r.examId === examId) || [];
     },

     getStudentExamResult(examId, studentId) {
         return this.getData('exam_results')?.find(r => r.examId === examId && r.studentId === studentId);
     },

     addExamResult(result) {
         result.id = result.id || this.generateUniqueId('ER');
         result.created_at = result.created_at || new Date().toISOString();
         
         const results = this.getData('exam_results') || [];
         // Remove existing result for same exam+student if exists
         results.splice(0, results.length, ...results.filter(r => !(r.examId === result.examId && r.studentId === result.studentId)));
         results.push(result);
         this.setData('exam_results', results);
         return result;
     },

     updateExamResult(resultId, updates) {
         const results = this.getData('exam_results') || [];
         const index = results.findIndex(r => r.id === resultId);
         if (index === -1) return null;
         
         results[index] = { ...results[index], ...updates };
         this.setData('exam_results', results);
         return results[index];
     },

     // ============================================
     // NOTIFICATIONS TABLE
     // ============================================
     getNotifications(filters = {}) {
         let notifications = this.getData('notifications') || [];
         
         if (filters.userId) {
             notifications = notifications.filter(n => n.userId === filters.userId);
         }
         if (filters.schoolId) {
             notifications = notifications.filter(n => n.schoolId === filters.schoolId);
         }
         if (filters.isRead !== undefined) {
             notifications = notifications.filter(n => n.isRead === filters.isRead);
         }
         
         return notifications.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
     },

     addNotification(notification) {
         notification.id = notification.id || this.generateId();
         notification.created_at = notification.created_at || new Date().toISOString();
         notification.isRead = notification.isRead || false;
         
         const notifications = this.getData('notifications') || [];
         notifications.push(notification);
         this.setData('notifications', notifications);
         return notification;
     },

     markNotificationRead(notificationId, read = true) {
         const notifications = this.getData('notifications') || [];
         const index = notifications.findIndex(n => n.id === notificationId);
         if (index === -1) return false;
         
         notifications[index].isRead = read;
         this.setData('notifications', notifications);
         return true;
     },

     markAllNotificationsRead(userId) {
         const notifications = this.getData('notifications') || [];
         notifications.forEach(n => {
             if (n.userId === userId) {
                 n.isRead = true;
             }
         });
         this.setData('notifications', notifications);
         return true;
     },

     deleteNotification(notificationId) {
         let notifications = this.getData('notifications') || [];
         notifications = notifications.filter(n => n.id !== notificationId);
         this.setData('notifications', notifications);
         return true;
     },

     // ============================================
     // CALENDAR EVENTS TABLE
     // ============================================
     getCalendarEvents(schoolId, filters = {}) {
         let events = this.getData('calendar_events')?.filter(e => e.schoolId === schoolId) || [];
         
         if (filters.eventType) {
             events = events.filter(e => e.eventType === filters.eventType);
         }
         if (filters.startDate && filters.endDate) {
             events = events.filter(e => {
                 const eventDate = new Date(e.eventDate);
                 return eventDate >= new Date(filters.startDate) && eventDate <= new Date(filters.endDate);
             });
         }
         
         return events.sort((a, b) => new Date(a.eventDate) - new Date(b.eventDate));
     },

     addCalendarEvent(event) {
         event.id = event.id || this.generateUniqueId('EVT');
         event.created_at = event.created_at || new Date().toISOString();
         event.supabase_last_sync = null;
         
         const events = this.getData('calendar_events') || [];
         events.push(event);
         this.setData('calendar_events', events);
         return event;
     },

     updateCalendarEvent(eventId, updates) {
         const events = this.getData('calendar_events') || [];
         const index = events.findIndex(e => e.id === eventId);
         if (index === -1) return null;
         
         events[index] = { ...events[index], ...updates };
         this.setData('calendar_events', events);
         return events[index];
     },

     deleteCalendarEvent(eventId) {
         let events = this.getData('calendar_events') || [];
         events = events.filter(e => e.id !== eventId);
         this.setData('calendar_events', events);
         return true;
     },

     // ============================================
     // TEST QUESTIONS JUNCTION TABLE
     // ============================================
     getTestQuestions(testId) {
         return this.getData('test_questions')?.filter(tq => tq.testId === testId) || [];
     },

     addTestQuestion(testQuestion) {
         testQuestion.id = testQuestion.id || this.generateId();
         const questions = this.getData('test_questions') || [];
         questions.push(testQuestion);
         this.setData('test_questions', questions);
         return testQuestion;
     },

     deleteTestQuestion(questionId) {
         let questions = this.getData('test_questions') || [];
         questions = questions.filter(q => q.id !== questionId);
         this.setData('test_questions', questions);
         return true;
     },

     // ============================================
     // HOMEWORK SUBMISSIONS (Normalize)
     // ============================================
     getHomeworkSubmissions(homeworkId) {
         const submissions = this.getData('homework_submissions') || [];
         return submissions.filter(s => s.homeworkId === homeworkId);
     },

     getStudentHomeworkSubmissionsSeparate(studentId, schoolId, homeworkId = null) {
         let submissions = this.getData('homework_submissions')?.filter(s => s.studentId === studentId && s.schoolId === schoolId) || [];
         if (homeworkId) {
             submissions = submissions.filter(s => s.homeworkId === homeworkId);
         }
         return submissions.sort((a, b) => new Date(b.submissionDate) - new Date(a.submissionDate));
     },

     addHomeworkSubmission(homeworkId, studentId, studentName, schoolId, answerText, attachments = []) {
         const submission = {
             id: this.generateId(),
             homeworkId,
             studentId,
             studentName,
             schoolId,
             submissionDate: new Date().toISOString(),
             status: 'submitted',
             answerText,
             attachments,
             grade: null,
             feedback: '',
             gradedBy: null,
             gradedAt: null,
             created_at: new Date().toISOString()
         };
         
         const submissions = this.getData('homework_submissions') || [];
         submissions.push(submission);
         this.setData('homework_submissions', submissions);
         
         // Also add to homework.submissions for backward compatibility (optional)
         const homework = this.getData('homework')?.find(h => h.id === homeworkId);
         if (homework) {
             if (!homework.submissions) homework.submissions = [];
             homework.submissions.push(submission);
             this.updateItem('homework', homeworkId, { submissions: homework.submissions });
         }
         
         return submission;
     },

     updateHomeworkSubmission(homeworkId, submissionId, updates) {
         const submissions = this.getData('homework_submissions') || [];
         const index = submissions.findIndex(s => s.id === submissionId && s.homeworkId === homeworkId);
         if (index === -1) return false;
         
         submissions[index] = {
             ...submissions[index],
             ...updates,
             updated_at: new Date().toISOString()
         };
         this.setData('homework_submissions', submissions);
         
         // Update backward compatible homework.submissions too
         const homework = this.getData('homework')?.find(h => h.id === homeworkId);
         if (homework && homework.submissions) {
             const subIndex = homework.submissions.findIndex(s => s.id === submissionId);
             if (subIndex !== -1) {
                 homework.submissions[subIndex] = submissions[index];
                 this.updateItem('homework', homeworkId, { submissions: homework.submissions });
             }
         }
         
         return true;
     },

     // ============================================
     // EXTRACT MESSAGES FROM CHATS (Normalize)
     // ============================================
     getMessages(chatId) {
         // First check if we have separate messages table
         const separateMessages = this.getData('messages')?.filter(m => m.chatId === chatId) || [];
         if (separateMessages.length > 0) {
             return separateMessages.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
         }
         
         // Fallback to embedded messages in chats
         const chat = this.getData('chats')?.find(c => c.id === chatId);
         return chat?.messages || [];
     },

     addMessage(chatId, message) {
         // Add to separate messages table
         const messages = this.getData('messages') || [];
         const newMessage = {
             id: this.generateId(),
             chatId,
             ...message,
             created_at: new Date().toISOString()
         };
         messages.push(newMessage);
         this.setData('messages', messages);
         
         // Also update chat's last_message and last_message_at
         const chats = this.getData('chats') || [];
         const chatIndex = chats.findIndex(c => c.id === chatId);
         if (chatIndex !== -1) {
             chats[chatIndex].lastMessage = message.message || '';
             chats[chatIndex].lastMessageAt = new Date().toISOString();
             this.setData('chats', chats);
         }
         
         return newMessage;
     },

     markMessageRead(messageId, read = true) {
         const messages = this.getData('messages') || [];
         const index = messages.findIndex(m => m.id === messageId);
         if (index !== -1) {
             messages[index].is_read = read;
             this.setData('messages', messages);
         }
         return true;
     },

     // Helper to delete data with filter (for cascade operations)
     deleteData(table, filterFn) {
         let items = this.getData(table) || [];
         items = items.filter(item => !filterFn(item));
         this.setData(table, items);
             return true;
         },

         // ============================================
         // DATA NORMALIZATION & MIGRATION
         // ============================================
           normalizeAllData() {
               this.normalizeChatMessages();
               this.normalizeHomeworkSubmissions();
               this.normalizeStudentMessages();
               this.normalizeParentMessages();
               this.normalizeLibraryBooks();
               this.normalizeStories();
               this.normalizeExamData();
               console.log('Data normalization complete');
           },

         normalizeChatMessages() {
             const chats = this.getData('chats') || [];
             let messages = this.getData('messages') || [];
             let addedCount = 0;
             
             chats.forEach(chat => {
                 if (Array.isArray(chat.messages)) {
                     chat.messages.forEach(msg => {
                         // Check if already exists (by content hash or duplicate detection)
                         const exists = messages.some(m => m.chatId === chat.id && m.message === msg.message && m.senderId === msg.senderId);
                         if (!exists) {
                             messages.push({
                                 id: this.generateId(),
                                 chatId: chat.id,
                                 senderId: msg.senderId,
                                 senderName: msg.senderName,
                                 senderRole: msg.senderRole,
                                 message: msg.message,
                                 message_type: msg.messageType || 'text',
                                 attachments: msg.attachments || [],
                                 is_read: msg.isRead || false,
                                 created_at: msg.timestamp || msg.createdAt || new Date().toISOString(),
                                 supabase_last_sync: null
                             });
                             addedCount++;
                         }
                     });
                 }
             });
             
             if (addedCount > 0) {
                 this.setData('messages', messages);
                 console.log(`Migrated ${addedCount} chat messages to separate table`);
             }
         },

         normalizeHomeworkSubmissions() {
             const homeworks = this.getData('homework') || [];
             let submissions = this.getData('homework_submissions') || [];
             let addedCount = 0;
             
             homeworks.forEach(homework => {
                 if (Array.isArray(homework.submissions)) {
                     homework.submissions.forEach(sub => {
                         // Check if already exists
                         const exists = submissions.some(s => s.homeworkId === homework.id && s.studentId === sub.studentId);
                         if (!exists) {
                             submissions.push({
                                 id: sub.id || this.generateId(),
                                 homeworkId: homework.id,
                                 studentId: sub.studentId,
                                 studentName: sub.studentName,
                                 schoolId: homework.schoolId,
                                 submissionDate: sub.submissionDate || sub.created_at,
                                 status: sub.status || 'submitted',
                                 answerText: sub.answerText || '',
                                 attachments: sub.attachments || [],
                                 grade: sub.grade,
                                 feedback: sub.feedback || '',
                                 gradedBy: sub.gradedBy,
                                 gradedAt: sub.gradedAt,
                                 created_at: sub.created_at || new Date().toISOString(),
                                 supabase_last_sync: null
                             });
                             addedCount++;
                         }
                     });
                 }
             });
             
             if (addedCount > 0) {
                 this.setData('homework_submissions', submissions);
                 console.log(`Migrated ${addedCount} homework submissions to separate table`);
             }
         },

         normalizeStudentMessages() {
             const messages = this.getData('student_messages') || [];
             let updatedCount = 0;
             
             messages.forEach(msg => {
                 let changed = false;
                 // Ensure from_role is set
                 if (!msg.from_role) {
                     msg.from_role = 'student';
                     changed = true;
                 }
                 // Extract reply if exists
                 if (msg.reply && typeof msg.reply === 'object' && !msg.reply_message) {
                     msg.reply_message = msg.reply.message;
                     msg.replied_at = msg.reply.repliedAt;
                     msg.replied_by = msg.reply.repliedBy;
                     changed = true;
                 }
                 
                 if (changed) {
                     updatedCount++;
                 }
             });
             
             if (updatedCount > 0) {
                 this.setData('student_messages', messages);
                 console.log(`Normalized ${updatedCount} student messages`);
             }
         },

          normalizeParentMessages() {
              const messages = this.getData('parent_messages') || [];
              let updatedCount = 0;

              messages.forEach(msg => {
                  let changed = false;
                  // Extract reply if exists
                  if (msg.reply && typeof msg.reply === 'object' && !msg.reply_message) {
                      msg.reply_message = msg.reply.message;
                      msg.replied_at = msg.reply.repliedAt;
                      msg.replied_by = msg.reply.repliedBy;
                      changed = true;
                  }

                  if (changed) {
                      updatedCount++;
                  }
              });

              if (updatedCount > 0) {
                  this.setData('parent_messages', messages);
                  console.log(`Normalized ${updatedCount} parent messages`);
              }
          },

          normalizeLibraryBooks() {
              // Migrate from old 'libraryBooks' key to 'library_books'
              const oldData = localStorage.getItem('libraryBooks');
              const currentData = this.getData('library_books') || [];

              if (oldData && currentData.length === 0) {
                  try {
                      const parsed = JSON.parse(oldData);
                      if (Array.isArray(parsed) && parsed.length > 0) {
                          this.setData('library_books', parsed);
                          console.log(`Migrated ${parsed.length} library books from old storage key`);
                          // Optionally remove old key
                          // localStorage.removeItem('libraryBooks');
                      }
                  } catch (e) {
                      console.error('Failed to migrate libraryBooks data:', e);
                  }
              }
          },

          normalizeStories() {
              // Migrate from old 'storiesData' structure to new separate keys
              const oldData = localStorage.getItem('storiesData');
              if (oldData) {
                  try {
                      const parsed = JSON.parse(oldData);
                      let migrated = false;

                      // Migrate stories array
                      if (parsed.stories && Array.isArray(parsed.stories)) {
                          const existingStories = this.getData('stories') || [];
                          if (existingStories.length === 0) {
                              this.setData('stories', parsed.stories);
                              console.log(`Migrated ${parsed.stories.length} stories`);
                              migrated = true;
                          }
                      }

                      // Migrate interactions
                      if (parsed.interactions && Array.isArray(parsed.interactions)) {
                          const existingInteractions = this.getData('storyInteractions') || [];
                          if (existingInteractions.length === 0) {
                              this.setData('storyInteractions', parsed.interactions);
                              console.log(`Migrated ${parsed.interactions.length} story interactions`);
                              migrated = true;
                          }
                      }

                      // Migrate comments
                      if (parsed.comments && Array.isArray(parsed.comments)) {
                          const existingComments = this.getData('storyComments') || [];
                          if (existingComments.length === 0) {
                              this.setData('storyComments', parsed.comments);
                              console.log(`Migrated ${parsed.comments.length} story comments`);
                              migrated = true;
                          }
                      }

                      // Migrate submissions
                      if (parsed.submissions && Array.isArray(parsed.submissions)) {
                          const existingSubmissions = this.getData('storySubmissions') || [];
                          if (existingSubmissions.length === 0) {
                              this.setData('storySubmissions', parsed.submissions);
                              console.log(`Migrated ${parsed.submissions.length} story submissions`);
                              migrated = true;
                          }
                      }

                      // Optionally remove old key after successful migration
                      if (migrated) {
                          // localStorage.removeItem('storiesData');
                          console.log('Stories data migration complete');
                      }
                  } catch (e) {
                      console.error('Failed to migrate storiesData:', e);
                  }
              }
          },

          normalizeExamData() {
              // Migrate examSessions, examLogs, violationReports from school_{id} keys to central arrays
              const examSessions = this.getData('examSessions') || [];
              const examLogs = this.getData('examLogs') || [];
              const violationReports = this.getData('violationReports') || [];

              // Collect additional data from school-specific keys
              let mergedSessions = [...examSessions];
              let mergedLogs = [...examLogs];
              let mergedViolations = [...violationReports];

              for (let i = 0; i < localStorage.length; i++) {
                  const key = localStorage.key(i);
                  if (key && key.startsWith('school_')) {
                      try {
                          const schoolData = JSON.parse(localStorage.getItem(key));
                          if (schoolData.examSessions) {
                              mergedSessions.push(...schoolData.examSessions);
                          }
                          if (schoolData.examLogs) {
                              mergedLogs.push(...schoolData.examLogs);
                          }
                          if (schoolData.violationReports) {
                              mergedViolations.push(...schoolData.violationReports);
                          }
                          // Remove from school data to avoid duplicates
                          if (schoolData.examSessions || schoolData.examLogs || schoolData.violationReports) {
                              delete schoolData.examSessions;
                              delete schoolData.examLogs;
                              delete schoolData.violationReports;
                              localStorage.setItem(key, JSON.stringify(schoolData));
                          }
                      } catch (e) {
                          console.warn('Failed to migrate exam data from school key:', key, e);
                      }
                  }
              }

              this.setData('examSessions', mergedSessions);
              this.setData('examLogs', mergedLogs);
              this.setData('violationReports', mergedViolations);
              console.log(`Migrated ${mergedSessions.length} exam sessions, ${mergedLogs.length} exam logs, ${mergedViolations.length} violation reports`);
          },

          // ============================================
          // INITIALIZATION & HELPERS
          // ============================================
        ensureTables() {
            // Ensure all new tables exist in data
            const requiredTables = [
                'teachers', 'timetable', 'exams', 'examQuestions', 'examResults',
                'notifications', 'messages', 'parentMessages', 'homeworkSubmissions', 'testQuestions'
            ];
            
            const data = this.getDB();  // Fixed: was getData() which returned [] and corrupted DB
            let changed = false;
            
            requiredTables.forEach(table => {
                if (!data[table]) {
                    data[table] = [];
                    changed = true;
                }
            });
            
            if (changed) {
                this.saveDBLocal(data);
                console.log('Added missing tables to database');
            }
        }
     };


// Initialize storage
Storage.init();

window.Storage = Storage;

// Cloud sync - using Supabase (see supabase-sync.js)
window.syncFromFirebase = async function () {
    if (typeof SupabaseSync !== 'undefined') {
        return await SupabaseSync.syncFromCloud();
    }
    console.log('Supabase sync not available');
    return false;
};

window.syncToFirebase = async function () {
    if (typeof SupabaseSync !== 'undefined') {
        return await SupabaseSync.syncAllToCloud();
    }
    console.log('Supabase sync not available');
    return false;
};

window.smartSyncOnLogin = async function () {
    if (typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
        console.log('Syncing from Supabase...');
        return await SupabaseSync.syncFromCloud();
    }
    console.log('Using local storage only');
};

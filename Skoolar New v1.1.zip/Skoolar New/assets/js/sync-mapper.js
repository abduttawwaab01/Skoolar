/**
 * SyncMapper - Transforms data between local storage (camelCase) and SQL (snake_case)
 * Handles field name mapping, type conversions, default values, and validation
 */

const SyncMapper = {
    // Field mapping configuration per SQL table
    // Format: { sql_field: storage_field }
    fieldMappings: {
        // Core tables
        schools: {
            id: 'id',
            name: 'name',
            email: 'email',
            phone: 'phone',
            address: 'address',
            type: 'type',
            status: 'status',
            logo: 'logo',
            settings: 'settings',
            created_at: 'created_at',
            expires_at: 'expires_at',
            subscription_days: 'subscriptionDays',
            // Missing in storage - will need defaults
            currency: null, // default 'NGN'
            restrictions: null, // default {}
            activation_code_id: null,
            supabase_last_sync: null
        },
        users: {
            id: 'id',
            name: 'name',
            email: 'email',
            phone: 'phone',
            username: 'username',
            // password: 'password', // Excluded: use Supabase Auth for password verification
            role: 'role',
            school_id: 'schoolId',
            status: 'status',
            avatar: 'avatar',
            settings: 'settings',
            created_at: 'created_at',
            supabase_last_sync: null // needs to be added
        },
        students: {
            id: 'id',
            school_id: 'schoolId',
            student_id: 'studentId',
            name: 'name',
            email: 'email',
            phone: 'phone',
            class: 'class',
            section: 'section',
            gender: 'gender',
            dob: 'dob',
            blood_group: 'bloodGroup',
            address: 'address',
            guardian_name: 'guardianName',
            guardian_phone: 'guardianPhone',
            guardian_email: 'guardianEmail',
            guardian_occupation: 'guardianOccupation',
            parent_name: 'parentName',
            parent_phone: 'parentPhone',
            parent_email: 'parentEmail',
            parent_id: 'parentId',
            username: 'username',
            password: 'password',
            photo: 'photo',
            status: 'status',
            enrollment_date: 'enrollmentDate',
            created_at: 'created_at',
            supabase_last_sync: null,
            user_id: null // needs to be added (FK to users)
        },
        teachers: {
            id: 'id',
            school_id: 'schoolId',
            user_id: 'userId',
            name: 'name',
            email: 'email',
            phone: 'phone',
            employee_id: 'employeeId',
            department: 'department',
            classes: 'classes',
            subjects: 'subjects',
            qualifications: 'qualifications',
            experience_years: 'experienceYears',
            photo: 'photo',
            status: 'status',
            created_at: 'created_at',
            supabase_last_sync: null
        },
        attendance: {
            id: 'id',
            student_id: 'studentId',
            school_id: 'schoolId',
            class: 'class',
            section: 'section',
            date: 'date',
            status: 'status',
            remarks: 'remarks',
            marked_by: 'markedBy',
            marked_at: 'markedAt',
            term: 'term',
            year: 'year',
            supabase_last_sync: null
        },
        staff_attendance: {
            id: 'id',
            school_id: 'schoolId',
            staff_id: 'staffId',
            staff_name: 'staffName',
            date: 'date',
            check_in: 'checkIn',
            check_out: 'checkOut',
            location_in: 'locationIn',
            location_out: 'locationOut',
            status: 'status',
            remarks: 'remarks',
            supabase_last_sync: null
        },
        scores: {
            id: 'id',
            student_id: 'studentId',
            school_id: 'schoolId',
            student_name: 'studentName',
            class: 'class',
            subject: 'subject',
            term: 'term',
            year: 'year',
            score_type: 'scoreType',
            score: 'score',
            max_score: 'maxScore',
            entered_by: 'enteredBy',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        score_sessions: {
            id: 'id',
            school_id: 'schoolId',
            teacher_id: 'teacherId',
            class: 'class',
            subject: 'subject',
            type: 'type',
            term: 'term',
            year: 'year',
            date: 'date',
            total_students: 'totalStudents',
            average_score: 'averageScore',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        domain_scores: {
            id: 'id',
            school_id: 'schoolId',
            student_id: 'studentId',
            teacher_id: 'teacherId',
            class: 'class',
            subject: 'subject',
            domain: 'domain',
            score: 'score',
            remark: 'remark',
            term: 'term',
            year: 'year',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        finance: {
            id: 'id',
            school_id: 'schoolId',
            type: 'type',
            category: 'category',
            amount: 'amount',
            description: 'description',
            payment_method: 'paymentMethod',
            reference_number: 'referenceNumber',
            related_student_id: 'relatedStudentId',
            related_class: 'relatedClass',
            term: 'term',
            year: 'year',
            date: 'date',
            created_by: 'createdBy',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        library_books: {
            id: 'id',
            school_id: 'schoolId',
            isbn: 'isbn',
            title: 'title',
            author: 'author',
            publisher: 'publisher',
            category: 'category',
            quantity: 'quantity',
            available: 'available',
            shelf_location: 'shelfLocation',
            status: 'status',
            created_at: 'created_at',
            supabase_last_sync: null
        },
        book_loans: {
            id: 'id',
            school_id: 'schoolId',
            book_id: 'bookId',
            student_id: 'studentId',
            student_name: 'studentName',
            checkout_date: 'checkoutDate',
            due_date: 'dueDate',
            return_date: 'returnDate',
            status: 'status',
            fine_amount: 'fineAmount',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        homework: {
            id: 'id',
            school_id: 'schoolId',
            teacher_id: 'teacherId',
            class: 'class',
            subject: 'subject',
            title: 'title',
            description: 'description',
            due_date: 'dueDate',
            total_marks: 'totalMarks',
            attachments: 'attachments',
            term: 'term',
            year: 'year',
            status: 'status',
            created_at: 'created_at',
            supabase_last_sync: null
        },
        homework_submissions: {
            id: 'id',
            homework_id: 'homeworkId',
            student_id: 'studentId',
            student_name: 'studentName',
            submission_date: 'submissionDate',
            status: 'status',
            answer_text: 'answerText',
            attachments: 'attachments',
            grade: 'grade',
            feedback: 'feedback',
            graded_by: 'gradedBy',
            graded_at: 'gradedAt',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        timetable: {
            id: 'id',
            school_id: 'schoolId',
            class: 'class',
            section: 'section',
            day_of_week: 'dayOfWeek',
            period_number: 'periodNumber',
            subject: 'subject',
            teacher_id: 'teacherId',
            teacher_name: 'teacherName',
            room: 'room',
            term: 'term',
            year: 'year',
            created_at: 'created_at',
            supabase_last_sync: null
        },
        chats: {
            id: 'id',
            school_id: 'schoolId',
            title: 'title',
            type: 'type',
            participants: 'participants',
            last_message: 'lastMessage',
            last_message_at: 'lastMessageAt',
            created_by: 'createdBy',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        messages: {
            id: 'id',
            chat_id: 'chatId',
            sender_id: 'senderId',
            sender_name: 'senderName',
            sender_role: 'senderRole',
            message: 'message',
            message_type: 'messageType',
            attachments: 'attachments',
            is_read: 'isRead',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        student_messages: {
            id: 'id',
            school_id: 'schoolId',
            student_id: 'studentId',
            from_role: 'fromRole', // needs to be added to storage
            from_name: 'fromName', // maybe use studentName?
            subject: 'subject',
            message: 'message',
            is_read: 'isRead',
            reply_message: 'reply.message',
            replied_at: 'reply.repliedAt',
            replied_by: 'reply.repliedBy',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        parent_messages: {
            id: 'id',
            school_id: 'schoolId',
            parent_id: 'parentId',
            parent_name: 'parentName',
            student_id: 'studentId',
            student_name: 'studentName',
            subject: 'subject',
            message: 'message',
            is_read: 'isRead',
            reply_message: 'reply.message',
            replied_at: 'reply.repliedAt',
            replied_by: 'reply.repliedBy',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        parent_announcements: {
            id: 'id',
            school_id: 'schoolId',
            title: 'title', // needs to be added
            message: 'message',
            target_class: 'targetClass', // needs to be added
            target_student_ids: 'targetStudentIds', // needs to be added (array)
            created_by: 'createdBy',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        adverts: {
            id: 'id',
            school_id: 'schoolId', // needs to be added
            title: 'title',
            description: 'content', // storage uses 'content'
            image_url: 'mediaUrl', // storage uses mediaUrl
            target_url: 'buttonLink', // storage uses buttonLink
            is_active: 'isActive',
            position: 'position', // needs to be added
            start_date: 'startDate', // needs to be added
            end_date: 'endDate', // needs to be added
            impressions: 'impressions', // needs to be added
            clicks: 'clicks', // needs to be added
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        activation_codes: {
            id: 'id',
            code: 'code',
            school_id: 'schoolId',
            is_used: 'isUsed',
            is_revoked: 'isRevoked',
            expires_at: 'expiresAt',
            created_at: 'createdAt',
            created_by: 'createdBy',
            used_at: 'usedAt',
            supabase_last_sync: null,
            subscription_days: 'subscriptionDays' // may be missing in storage
        },
        sync_log: {
            id: 'id',
            school_id: 'schoolId', // needs to be added
            sync_type: 'syncType',
            direction: 'direction',
            records_count: 'recordsCount',
            status: 'status',
            error_message: 'errorMessage',
            created_at: 'createdAt'
        },
        audit_log: {
            id: 'id',
            user_id: 'userId',
            school_id: 'schoolId',
            action: 'action',
            entity_type: 'entityType',
            entity_id: 'entityId',
            old_values: 'oldValues',
            new_values: 'newValues',
            ip_address: null, // needs to be added
            user_agent: 'userAgent',
            created_at: 'createdAt'
        },
        notifications: {
            id: 'id',
            user_id: 'userId',
            school_id: 'schoolId',
            title: 'title',
            message: 'message',
            type: 'type',
            is_read: 'isRead',
            link: 'link',
            created_at: 'createdAt'
        },
        calendar_events: {
            id: 'id',
            school_id: 'schoolId',
            title: 'title',
            description: 'description',
            event_date: 'eventDate',
            event_type: 'eventType',
            for_classes: 'forClasses',
            created_by: 'createdBy',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        tests: {
            id: 'id',
            school_id: 'schoolId',
            teacher_id: 'teacherId',
            title: 'title',
            description: 'description',
            subject: 'subject',
            class: 'class',
            type: 'type',
            term: 'term',
            year: 'year',
            duration_minutes: 'durationMinutes',
            passing_percentage: 'passingPercentage',
            randomize_questions: 'randomizeQuestions',
            randomize_options: 'randomizeOptions',
            show_results: 'showResults',
            status: 'status',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        test_questions: {
            id: 'id',
            test_id: 'testId',
            question_id: 'questionId',
            question_order: 'questionOrder',
            marks: 'marks'
        },
        test_results: {
            id: 'id',
            test_id: 'testId',
            student_id: 'studentId',
            school_id: 'schoolId',
            answers: 'answers',
            score: 'score',
            total_marks: 'totalMarks',
            percentage: 'percentage',
            status: 'status',
            started_at: 'startedAt',
            submitted_at: 'submittedAt',
            graded_by: 'gradedBy',
            graded_at: 'gradedAt',
            created_at: 'createdAt',
            supabase_last_sync: null
        },
        exam_questions: {
            id: 'id',
            exam_id: 'examId',
            question_text: 'questionText',
            question_type: 'questionType',
            options: 'options',
            correct_answer: 'correctAnswer',
            points: 'points',
            explanation: 'explanation',
            question_order: 'questionOrder'
        },
        examSessions: {
            id: 'id',
            test_id: 'testId',
            student_id: 'studentId',
            answers: 'answers',
            flagged_questions: 'flaggedQuestions',
            current_question_index: 'currentQuestionIndex',
            last_saved: 'lastSaved',
            created_at: 'created_at',
            supabase_last_sync: null
        },
        examLogs: {
            id: 'id',
            student_id: 'studentId',
            test_id: 'testId',
            type: 'type',
            description: 'description',
            timestamp: 'timestamp',
            question_at_violation: 'questionAtViolation',
            total_questions: 'totalQuestions',
            answered_count: 'answeredCount',
            violation_number: 'violationNumber',
            counted: 'counted',
            created_at: 'created_at',
            supabase_last_sync: null
        },
        violationReports: {
            id: 'id',
            test_id: 'testId',
            student_id: 'studentId',
            school_id: 'schoolId',
            test_title: 'testTitle',
            subject: 'subject',
            class_name: 'className',
            violations: 'violations',
            violation_count: 'violationCount',
            auto_submitted: 'autoSubmitted',
            submitted_at: 'submittedAt',
            answered_questions: 'answeredQuestions',
            total_questions: 'totalQuestions',
            status: 'status',
            created_at: 'created_at',
            supabase_last_sync: null
        }
    },

    // Default values for missing fields
    defaultValues: {
        schools: {
            currency: 'NGN',
            restrictions: {},
            subscription_days: 365,
            supabase_last_sync: null
        },
        users: {
            supabase_last_sync: null
        },
        students: {
            user_id: null,
            supabase_last_sync: null
        },
        teachers: {
            supabase_last_sync: null
        },
        attendance: {
            supabase_last_sync: null
        },
        staff_attendance: {
            location_in: null,
            location_out: null,
            supabase_last_sync: null
        },
        scores: {
            supabase_last_sync: null
        },
        score_sessions: {
            supabase_last_sync: null
        },
        domain_scores: {
            supabase_last_sync: null
        },
        finance: {
            supabase_last_sync: null
        },
        library_books: {
            supabase_last_sync: null
        },
        book_loans: {
            supabase_last_sync: null
        },
        homework: {
            supabase_last_sync: null
        },
        homework_submissions: {
            supabase_last_sync: null
        },
        timetable: {
            supabase_last_sync: null
        },
        chats: {
            supabase_last_sync: null
        },
        messages: {
            supabase_last_sync: null
        },
        student_messages: {
            from_role: 'student',
            supabase_last_sync: null
        },
        parent_messages: {
            supabase_last_sync: null
        },
        parent_announcements: {
            title: 'Announcement',
            target_class: null,
            target_student_ids: [],
            supabase_last_sync: null
        },
        adverts: {
            school_id: null,
            position: 'sidebar',
            start_date: new Date().toISOString().split('T')[0],
            end_date: null,
            impressions: 0,
            clicks: 0,
            supabase_last_sync: null
        },
        activation_codes: {
            supabase_last_sync: null
        },
        sync_log: {
            school_id: null
        },
        audit_log: {
            ip_address: null,
            supabase_last_sync: null
        },
        notifications: {},
        calendar_events: {
            supabase_last_sync: null
        },
        tests: {
            supabase_last_sync: null
        },
        test_questions: {},
        test_results: {
            supabase_last_sync: null
        },
        exam_questions: {},
        examSessions: {
            supabase_last_sync: null
        },
        examLogs: {
            supabase_last_sync: null
        },
        violationReports: {
            supabase_last_sync: null
        }
    },

    // Enum validations (SQL CHECK constraints)
    enums: {
        users: {
            role: ['super_admin', 'school_admin', 'teacher', 'accountant', 'director', 'parent', 'student']
        },
        schools: {
            type: ['primary', 'secondary', 'both'],
            status: ['active', 'suspended', 'closed']
        },
        students: {
            gender: ['male', 'female', 'other'],
            status: ['active', 'inactive', 'graduated', 'transferred', 'suspended']
        },
        staff_attendance: {
            status: ['present', 'absent', 'late', 'excused', 'on_leave']
        },
        scores: {
            score_type: ['Daily', 'Weekly', 'Mid-term', 'Exam']
        },
        score_sessions: {
            type: ['Daily', 'Weekly', 'Mid-term', 'Exam']
        },
        domain_scores: {
            domain: ['Cognitive', 'Affective', 'Psychomotor']
        },
        finance: {
            type: ['income', 'expense'],
            payment_method: ['cash', 'bank_transfer', 'online', 'cheque', 'pos']
        },
        chats: {
            type: ['direct', 'group', 'class']
        },
        messages: {
            message_type: ['text', 'image', 'file', 'system']
        },
        homework: {
            status: ['active', 'closed', 'archived']
        },
        timetable: {
            day_of_week: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        },
        parent_announcements: {}, // no enums
        adverts: {
            position: ['sidebar', 'banner', 'popup', 'login']
        },
        sync_log: {
            direction: ['upload', 'download', 'both'],
            status: ['success', 'partial', 'error']
        },
        tests: {
            type: ['mcq', 'true_false', 'fill_blank', 'essay', 'mixed'],
            status: ['draft', 'published', 'archived']
        },
        test_results: {
            status: ['passed', 'failed', 'incomplete']
        },
        exam_questions: {
            question_type: ['mcq', 'true_false', 'fill_blank', 'essay', 'short_answer']
        },
        exams: {
            exam_type: ['objective', 'subjective', 'mixed'],
            status: ['draft', 'published', 'ongoing', 'completed', 'archived']
        }
    },

    // Get field mapping for a SQL table
    getMapping(sqlTable) {
        return this.fieldMappings[sqlTable] || {};
    },

    // Get default values for a SQL table
    getDefaults(sqlTable) {
        return this.defaultValues[sqlTable] || {};
    },

    // Convert storage record to SQL format
    transformForSQL(storageRecord, sqlTable) {
        const mapping = this.getMapping(sqlTable);
        const defaults = this.getDefaults(sqlTable);
        const sqlRecord = {};

        // If no explicit mapping, fallback: convert all fields to snake_case
        if (Object.keys(mapping).length === 0) {
            for (const [camelKey, value] of Object.entries(storageRecord)) {
                if (value === undefined || value === null) continue;
                const snakeKey = camelKey.replace(/([A-Z])/g, '_$1').toLowerCase();
                sqlRecord[snakeKey] = this.convertValue(snakeKey, value, sqlTable);
            }
            // Apply defaults for known fields like supabase_last_sync
            for (const [key, defaultValue] of Object.entries(defaults)) {
                if (sqlRecord[key] === undefined) {
                    sqlRecord[key] = defaultValue;
                }
            }
            return sqlRecord;
        }

        // Apply explicit field mappings
        for (const [sqlField, storageField] of Object.entries(mapping)) {
            if (storageField === null) {
                // Field doesn't exist in storage, use default if available
                if (defaults[sqlField] !== undefined) {
                    sqlRecord[sqlField] = defaults[sqlField];
                }
                // If no default and field is required, leave it out (will cause SQL error)
                continue;
            }

            const value = this.getNestedValue(storageRecord, storageField);
            if (value !== undefined && value !== null) {
                // Type conversions
                sqlRecord[sqlField] = this.convertValue(sqlField, value, sqlTable);
            } else if (defaults[sqlField] !== undefined) {
                sqlRecord[sqlField] = defaults[sqlField];
            }
        }

        // Add any missing defaults that weren't in mapping
        for (const [key, defaultValue] of Object.entries(defaults)) {
            if (sqlRecord[key] === undefined) {
                sqlRecord[key] = defaultValue;
            }
        }

        return sqlRecord;
    },

    // Convert SQL record to storage format
    transformForStorage(sqlRecord, storageTable) {
        const mapping = this.getMapping(sqlTable);
        const storageRecord = {};

        // Reverse mapping
        for (const [sqlField, storageField] of Object.entries(mapping)) {
            if (storageField === null) continue; // Skip storage-only fields

            const value = sqlRecord[sqlField];
            if (value !== undefined && value !== null) {
                // Convert snake_case back to camelCase for storage field name
                const storageFieldName = this.camelCase(storageField);
                storageRecord[storageFieldName] = this.reverseConvertValue(sqlField, value, sqlTable);
            }
        }

        return storageRecord;
    },

    // Get nested value using dot notation (e.g., 'reply.message')
    getNestedValue(obj, path) {
        if (!path) return undefined;
        if (!path.includes('.')) return obj[path];
        
        const parts = path.split('.');
        let current = obj;
        for (const part of parts) {
            if (current === null || current === undefined) return undefined;
            current = current[part];
        }
        return current;
    },

    // Set nested value using dot notation
    setNestedValue(obj, path, value) {
        if (!path.includes('.')) {
            obj[path] = value;
            return;
        }
        const parts = path.split('.');
        let current = obj;
        for (let i = 0; i < parts.length - 1; i++) {
            if (!current[parts[i]]) {
                current[parts[i]] = {};
            }
            current = current[parts[i]];
        }
        current[parts[parts.length - 1]] = value;
    },

    // Convert value based on SQL field type expectations
    convertValue(sqlField, value, sqlTable) {
        // Date/TIMESTAMPTZ conversions
        if (this.isDateField(sqlField, sqlTable)) {
            return this.parseDate(value);
        }
        
        // Decimal conversions
        if (this.isDecimalField(sqlField, sqlTable)) {
            return parseFloat(value) || 0;
        }

        // Boolean conversions
        if (this.isBooleanField(sqlField, sqlTable)) {
            return Boolean(value);
        }

        // JSONB fields - ensure proper JSON
        if (this.isJsonbField(sqlField, sqlTable)) {
            return typeof value === 'string' ? value : JSON.stringify(value || {});
        }

        // Enum validation
        this.validateEnum(sqlTable, sqlField, value);

        return value;
    },

    // Reverse conversion (SQL → storage)
    reverseConvertValue(sqlField, value, sqlTable) {
        if (value === null || value === undefined) return value;

        // Dates back to ISO strings
        if (this.isDateField(sqlField, sqlTable) || this.isTimestampField(sqlField, sqlTable)) {
            if (value instanceof Date) return value.toISOString();
            if (typeof value === 'string') return value; // Assume already ISO
        }

        // JSONB parse
        if (this.isJsonbField(sqlField, sqlTable)) {
            if (typeof value === 'string') {
                try {
                    return JSON.parse(value);
                } catch (e) {
                    return value;
                }
            }
            return value;
        }

        // Numbers stay as numbers
        if (this.isDecimalField(sqlField, sqlTable)) {
            return typeof value === 'number' ? value : parseFloat(value) || 0;
        }

        return value;
    },

    // Helpers to identify field types
    isDateField(sqlField, sqlTable) {
        return sqlField === 'date' || sqlField.endsWith('_date');
    },

    isTimestampField(sqlField, sqlTable) {
        return sqlField === 'created_at' || sqlField === 'updated_at' || sqlField === 'marked_at' || 
               sqlField.endsWith('_at') || sqlField === 'start_date' || sqlField === 'end_date';
    },

    isDecimalField(sqlField, sqlTable) {
        return ['amount', 'score', 'max_score', 'average_score', 'total_marks', 'passing_percentage', 'points', 'marks', 'fine_amount', 'subscription_days', 'total_students', 'impressions', 'clicks'].includes(sqlField);
    },

    isBooleanField(sqlField, sqlTable) {
        return ['is_active', 'is_used', 'is_revoked', 'is_read', 'show_results', 'randomize_questions', 'randomize_options'].includes(sqlField);
    },

    isJsonbField(sqlField, sqlTable) {
        return ['settings', 'restrictions', 'participants', 'attachments', 'answers', 'for_classes', 'target_student_ids', 'target_schools', 'target_roles', 'messages', 'scores', 'options', 'reply'].includes(sqlField);
    },

    // Validate enum values
    validateEnum(sqlTable, sqlField, value) {
        const enums = this.enums[sqlTable];
        if (enums && enums[sqlField] && !enums[sqlField].includes(value)) {
            console.warn(`SyncMapper: Invalid enum value for ${sqlTable}.${sqlField}: "${value}". Expected: ${enums[sqlField].join(', ')}`);
        }
    },

    // Convert string to snake_case (for generating storage field names if needed)
    toSnakeCase(str) {
        return str.replace(/([A-Z])/g, '_$1').toLowerCase();
    },

    // Convert snake_case to camelCase
    camelCase(str) {
        return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
    },

    // Parse date string to ensure proper format for SQL
    parseDate(value) {
        if (!value) return null;
        if (value instanceof Date) return value;
        if (typeof value === 'string') {
            // Already in YYYY-MM-DD or ISO format
            return value;
        }
        return String(value);
    },

    // Check if a table has mapping defined
    isMapped(sqlTable) {
        return !!this.fieldMappings[sqlTable];
    },

    // Get all mapped tables
    getMappedTables() {
        return Object.keys(this.fieldMappings);
    }
};

// Make available globally
if (typeof window !== 'undefined') {
    window.SyncMapper = SyncMapper;
}

const Auth = {
    SESSION_KEY: 'mySchoolSession',
    SESSION_TIMEOUT: 24 * 60 * 60 * 1000,

    async init() {
        console.log('=== AUTH MODULE INITIALIZING (v3 with Supabase Auth) ===');

        // Ensure Storage is initialized first
        if (typeof Storage !== 'undefined' && typeof Storage.init === 'function') {
            Storage.init();
        }

        // Initialize Supabase Auth
        if (typeof SupabaseAuth !== 'undefined' && typeof SupabaseAuth.init === 'function') {
            SupabaseAuth.init();
        }

        // Check if there's an active session before wiping any data
        const existingSession = localStorage.getItem(this.SESSION_KEY);
        let currentUser = null;
        
        if (existingSession) {
            try {
                const session = JSON.parse(existingSession);
                if (session && session.user && new Date(session.expiresAt) > new Date()) {
                    currentUser = session.user;
                }
            } catch (e) {
                console.warn('Failed to parse existing session:', e);
            }
        }

        // Only wipe data if no user is currently logged in (first run or fresh start)
        // This prevents wiping user data when they're already logged in
        const VERSION_KEY = 'skoolar_data_version';
        const CURRENT_VERSION = '1.0-supabase-auth';
        const savedVersion = localStorage.getItem(VERSION_KEY);

        if (savedVersion !== CURRENT_VERSION && !currentUser) {
            console.log('New version detected and no active session, wiping data except super admin...');
            try {
                await this.wipeDataExceptSuperAdmin();
                localStorage.setItem(VERSION_KEY, CURRENT_VERSION);
            } catch (err) {
                console.error('Data wipe failed, continuing anyway:', err);
            }
        } else if (savedVersion !== CURRENT_VERSION && currentUser) {
            console.log('New version detected but user is logged in, skipping data wipe to preserve user session');
            localStorage.setItem(VERSION_KEY, CURRENT_VERSION);
        }

        // Ensure super admin exists in localStorage (already done in wipeDataExceptSuperAdmin)
        // But keep as fallback
        if (typeof Storage !== 'undefined' && typeof Storage.seedSuperAdmin === 'function') {
            Storage.seedSuperAdmin();
        }

        // Ensure super admin exists in Supabase (if enabled)
        await this.ensureSupabaseSuperAdmin();
    },

    // Wipe all data except super admin for fresh start
    async wipeDataExceptSuperAdmin() {
        console.log('Wiping all data except super admin...');
        
        // Ensure Storage is ready
        if (typeof Storage !== 'undefined' && typeof Storage.init === 'function') {
            Storage.init();
        }
        
        let db = Storage.getDB();
        console.log('Current DB state:', db);

        // Safely get users array with multiple fallbacks
        let users = [];
        if (db && typeof db === 'object') {
            if (Array.isArray(db.users)) {
                users = db.users;
            } else if (db.users && typeof db.users === 'object' && Array.isArray(db.users)) {
                users = db.users;
            }
        }

        // Keep only super admin in users
        const superAdminUsername = 'abduttawwab';
        const superAdminId = 'sa_001';
        const superAdmins = users.filter(u =>
            u && (u.username === superAdminUsername || u.id === superAdminId)
        );

        // Ensure db is a valid object before modifying
        if (!db || typeof db !== 'object' || db === null) {
            db = {};
        }

        // Reset database arrays
        db.systemSettings = db.systemSettings || {}; // keep settings
        db.activationCodes = [];
        db.schools = [];
        db.students = [];
        db.teachers = [];
        db.attendance = [];
        db.scores = [];
        db.finance = [];
        db.chats = [];
        db.messages = [];
        db.studentMessages = [];
        db.parentMessages = [];
        db.notifications = [];
        db.reports = [];
        db.helpContent = null;
        db.questions = [];
        db.tests = [];
        db.testResults = [];
        db.testAttempts = [];
        db.testQuestions = [];
        db.calendarEvents = [];
        db.adverts = [];
        db.staffAttendance = [];
        db.scoreSessions = [];
        db.libraryBooks = [];
        db.bookLoans = [];
        db.homework = [];
        db.homeworkSubmissions = [];
        db.timetable = [];
        db.exams = [];
        db.examQuestions = [];
        db.examResults = [];
        db.auditLog = [];
        db.syncLog = [];

        // Restore super admin
        db.users = superAdmins;

        Storage.saveDBLocal(db);
        console.log('Data wipe complete. Super admin preserved.');
    },

    // Ensure super admin exists in Supabase Auth and users table
    async ensureSupabaseSuperAdmin() {
        if (!isSupabaseEnabled()) return;

        try {
            const supabase = getSupabase();
            if (!supabase) return;

            // Check if super admin exists in auth.users by trying to fetch from our users table with known email
            const superAdminEmail = 'odebunmitawwab123@gmail.com';
            const superAdminUsername = 'abduttawwab';
            const superAdminPassword = 'Successor1*'; // same as seed

            // Check if we have super admin in local users
            const localUsers = Storage.getData('users') || [];
            const localSuperAdmin = localUsers.find(u => u.username === superAdminUsername || u.email === superAdminEmail);

            if (!localSuperAdmin) {
                console.warn('Local super admin not found, seeding...');
                Storage.seedSuperAdmin();
            }

            // Try to get profile from Supabase users table to see if it exists
            const { data: existing } = await supabase
                .from('users')
                .select('id, email')
                .eq('email', superAdminEmail)
                .single();

            if (existing) {
                console.log('Super admin exists in Supabase users table');
                // Optionally, ensure they also exist in auth.users? We assume they do if they were registered.
                return;
            }

            // Create super admin in Supabase Auth and users table
            console.log('Creating super admin in Supabase...');
            const { data: authData, error: authError } = await supabase.auth.signUp({
                email: superAdminEmail,
                password: superAdminPassword,
                options: {
                    data: {
                        name: 'Odebunmi Tawwab',
                        username: superAdminUsername,
                        role: 'super_admin'
                    }
                }
            });

            if (authError) {
                console.error('Failed to create super admin in Supabase Auth:', authError);
                return;
            }

            // The user should be created automatically in the 'users' table via a trigger?
            // If not, we need to insert manually into the users table
            const { error: profileError } = await supabase.from('users').insert({
                id: authData.user.id,
                name: 'Odebunmi Tawwab',
                email: superAdminEmail,
                username: superAdminUsername,
                role: 'super_admin',
                status: 'active',
                school_id: null,
                phone: '',
                avatar: null
            });

            if (profileError) {
                console.error('Failed to create super admin profile in users table:', profileError);
            } else {
                console.log('Super admin created in Supabase successfully');
            }

        } catch (err) {
            console.error('Error ensuring super admin in Supabase:', err);
        }
    },

    // Hybrid login: try Supabase first, fallback to localStorage
    async loginWithSupabase(credentials) {
        const { email, password, schoolId } = credentials;
        console.log('Login attempt for:', email, 'schoolId:', schoolId);

        // Early check: if local user with password exists, use local auth directly (bypass Supabase)
        const allUsers = Storage.getData('users') || [];
        const emailLower = email.toLowerCase();
        const localUser = allUsers.find(u => 
            (u.email && u.email.toLowerCase() === emailLower) || 
            (u.username && u.username.toLowerCase() === emailLower)
        );
        if (localUser && localUser.password) {
            console.log('Local user with password found, using local auth directly');
            return this.localLogin(credentials);
        }

        // If we already have a valid Supabase session, use it
        if (typeof SupabaseAuth !== 'undefined' && SupabaseAuth.isAuthenticated()) {
            console.log('Already have Supabase session, using that');
            const supabaseUser = SupabaseAuth.getUser();
            if (supabaseUser) {
                // Ensure user exists locally and complete login
                const users = Storage.getData('users') || [];
                const supabaseEmailLower = (supabaseUser.email || '').toLowerCase();
                let user = users.find(u => 
                    (u.email && u.email.toLowerCase() === supabaseEmailLower) || 
                    (u.username && u.username.toLowerCase() === supabaseEmailLower)
                );
                if (!user) {
                    // Provision from Supabase profile
                    user = { ...supabaseUser, supabase_last_sync: new Date().toISOString() };
                    users.push(user);
                    Storage.setData('users', users);
                    console.log('Provisioned user from existing session:', supabaseUser.email);
                }
                return this.completeLogin(user, schoolId);
            }
        }

        // Try Supabase if enabled and online
        if (typeof SupabaseAuth !== 'undefined' && typeof SupabaseAuth.signIn === 'function' && isSupabaseEnabled() && navigator.onLine) {
            console.log('Attempting Supabase authentication...');
            try {
                const supabaseResult = await SupabaseAuth.signIn(email, password);
                console.log('Supabase signIn result:', supabaseResult);
                if (supabaseResult.success) {
                    console.log('Supabase auth successful, fetching full user record from users table...');
                    const supabaseUser = supabaseResult.user;
                    const supabase = getSupabase();
                    
                    let fullUser = { 
                        id: supabaseUser.id,
                        email: supabaseUser.email,
                        name: supabaseUser.email?.split('@')[0] || 'User',
                        role: 'parent',
                        schoolId: schoolId
                    };
                    
                    try {
                        // Try to fetch from users table - check both id and email
                        const { data: fetchedUser, error: fetchErr } = await supabase
                            .from('users')
                            .select('*')
                            .eq('id', supabaseUser.id)
                            .single();
                            
                        if (!fetchErr && fetchedUser) {
                            fullUser = { ...fullUser, ...fetchedUser };
                            console.log('Fetched user from users table:', fullUser);
                        } else {
                            // Try by email as fallback
                            const { data: fetchedByEmail } = await supabase
                                .from('users')
                                .select('*')
                                .eq('email', supabaseUser.email)
                                .single();
                            
                            if (fetchedByEmail) {
                                fullUser = { ...fullUser, ...fetchedByEmail };
                                console.log('Fetched user by email:', fullUser);
                            } else {
                                console.warn('User not found in users table, using auth profile only');
                            }
                        }
                    } catch (e) {
                        console.warn('Exception fetching full user record:', e);
                    }
                    
                    // Ensure user has required fields for local storage
                    fullUser.status = fullUser.status || 'active';
                    
                    // Handle school_id vs schoolId naming
                    if (fullUser.school_id && !fullUser.schoolId) {
                        fullUser.schoolId = fullUser.school_id;
                    }
                    
                    // Provision full user to local storage
                    if (typeof Storage !== 'undefined' && Storage.setData) {
                        const users = Storage.getData('users') || [];
                        const existingIndex = users.findIndex(u => u.id === fullUser.id || (u.email && u.email.toLowerCase() === (fullUser.email || '').toLowerCase()));
                        if (existingIndex >= 0) {
                            const existing = users[existingIndex];
                            // Preserve password if exists locally
                            const existingPassword = existing.password;
                            users[existingIndex] = { 
                                ...existing, 
                                ...fullUser, 
                                password: existingPassword || fullUser.password,
                                supabase_last_sync: new Date().toISOString() 
                            };
                        } else {
                            users.push({ 
                                ...fullUser, 
                                supabase_last_sync: new Date().toISOString() 
                            });
                        }
                        Storage.setData('users', users);
                        console.log('Provisioned/updated user in local storage:', fullUser.email || fullUser.username);
                    }
                    
                    return this.completeLogin(fullUser, schoolId);
                } else {
                    // Supabase auth failed - check if we have a local user with a password (local-only user)
                    console.warn('Supabase auth failed, checking local fallback...');
                    const allUsers = Storage.getData('users') || [];
                    const emailLower = email.toLowerCase();
                    const localUser = allUsers.find(u => 
                        (u.email && u.email.toLowerCase() === emailLower) || 
                        (u.username && u.username.toLowerCase() === emailLower)
                    );
                    if (localUser && localUser.password) {
                        // Local-only user with password hash exists, try local auth
                        console.log('Local user with password found, using local auth');
                        return this.localLogin(credentials);
                    } else if (localUser && !localUser.password) {
                        // User synced from Supabase (no local password) - must use Supabase
                        console.log('User is managed by Supabase (no local password), returning Supabase error');
                        return supabaseResult;
                    } else {
                        // No local record at all, try local auth (will likely fail)
                        console.log('No local user found, trying local auth as fallback');
                        return this.localLogin(credentials);
                    }
                }
            } catch (err) {
                console.error('Supabase auth exception:', err);
                return this.localLogin(credentials);
            }
        }

        // Offline or Supabase not available: use localStorage fallback
        console.log('Using localStorage fallback for authentication');
        return this.localLogin(credentials);
    },

    // Find user and validate (common for both Supabase and local)
    findAndValidateUser(email, schoolId) {
        const users = Storage.getData('users') || [];
        const user = users.find(u => {
            const emailMatch = (u.email && u.email.toLowerCase() === email.toLowerCase()) ||
                              (u.username && u.username.toLowerCase() === email.toLowerCase());
            return emailMatch;
        });

        if (!user) {
            return { success: false, message: 'User not found' };
        }

        if (user.status !== 'active') {
            return { success: false, message: 'Your account is not active' };
        }

        // School validation for non-super_admin
        if (user.role !== 'super_admin') {
            if (user.role === 'school_admin' || user.role === 'teacher' || user.role === 'accountant' || user.role === 'director' || user.role === 'parent') {
                if (!schoolId || schoolId === '') {
                    return { success: false, message: 'Please select your school' };
                }
                const userSchoolId = String(user.schoolId);
                const selectedSchoolId = String(schoolId);
                if (userSchoolId !== selectedSchoolId) {
                    return { success: false, message: 'Invalid school selection. Your account is not associated with this school.' };
                }
            }
        }

        // Check school subscription - fetch fresh data from Supabase first
        let warningMessage = null;
        let schoolCheck = null;
        if (user.role !== 'super_admin' && user.schoolId) {
            // First, try to fetch fresh school data from Supabase (non-blocking)
            if (typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
                SupabaseSync.fetchSchoolFromCloud(user.schoolId).catch(e => {
                    console.warn('Could not refresh school data from cloud:', e);
                });
            }
            
            // Check expiration (will use cached data if fetch not complete yet)
            schoolCheck = Storage.checkSchoolExpiration(user.schoolId);
            if (schoolCheck.expired) {
                return {
                    success: false,
                    message: 'School subscription has expired. Please contact the administrator to renew.',
                    expired: true,
                    schoolName: schoolCheck.school?.name
                };
            }
            if (schoolCheck.daysLeft && schoolCheck.daysLeft <= 7) {
                // Don't return early - collect warning and continue to create session
                warningMessage = `School subscription expires in ${schoolCheck.daysLeft} days. Please renew soon.`;
            }
        }

        // Dashboard access restrictions
        if (user.role !== 'super_admin' && user.role !== 'student') {
            const school = Storage.getSchoolById(user.schoolId);
            if (school) {
                const roleToDashboard = {
                    'teacher': 'teacher_dashboard',
                    'school_admin': 'admin_dashboard',
                    'director': 'director_dashboard',
                    'accountant': 'accountant_dashboard',
                    'parent': 'parent_dashboard'
                };
                const dashboardKey = roleToDashboard[user.role];
                if (dashboardKey) {
                    const restrictions = school.restrictions || {};
                    const disabledDashboards = restrictions.disabled_dashboards || [];
                    if (disabledDashboards.includes(dashboardKey)) {
                        return {
                            success: false,
                            message: `Your ${Auth.DASHBOARD_ACCESS[dashboardKey]} has been disabled by the Super Admin. Please contact support.`
                        };
                    }
                }
            }
        }

        // Create session
        const session = {
            userId: user.id,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                username: user.username,
                role: user.role,
                schoolId: user.schoolId,
                avatar: user.avatar,
                phone: user.phone
            },
            schoolId: user.schoolId,
            loginAt: new Date().toISOString(),
            expiresAt: new Date(Date.now() + this.SESSION_TIMEOUT).toISOString()
        };

        localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));

        this.logActivity(user.id, 'login', 'User logged in');

        if (typeof Storage.logAudit === 'function') {
            Storage.logAudit(user.id, user.schoolId, 'LOGIN', 'user', user.id);
        }

        // Sync from cloud after login - role-based sync options
        if (typeof SupabaseSync !== 'undefined' && typeof isSupabaseEnabled === 'function' && isSupabaseEnabled()) {
            console.log('Starting login sync...');
            const syncOptions = { schools: true, users: true, students: true, systemConfig: true };
            
            // Add role-specific sync tables
            if (user.role === 'teacher') {
                syncOptions.teachers = true;
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.tests = true;
                syncOptions.testResults = true;
                syncOptions.questions = true;
                syncOptions.homework = true;
                syncOptions.homework_submissions = true;
                syncOptions.timetable = true;
                syncOptions.notifications = true;
                syncOptions.staffAttendance = true;
            } else if (user.role === 'school_admin' || user.role === 'director') {
                syncOptions.teachers = true;
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.finance = true;
                syncOptions.chart_of_accounts = true;
                syncOptions.budgets = true;
                syncOptions.accounts_receivable = true;
                syncOptions.receipts = true;
                syncOptions.homework = true;
                syncOptions.timetable = true;
                syncOptions.notifications = true;
                syncOptions.staffAttendance = true;
                syncOptions.tests = true;
                syncOptions.testResults = true;
                syncOptions.questions = true;
                syncOptions.homework_submissions = true;
            } else if (user.role === 'accountant') {
                syncOptions.finance = true;
                syncOptions.chart_of_accounts = true;
                syncOptions.budgets = true;
                syncOptions.accounts_receivable = true;
                syncOptions.receipts = true;
                syncOptions.notifications = true;
            } else if (user.role === 'super_admin') {
                syncOptions.activationCodes = true;
                syncOptions.adverts = true;
                syncOptions.blogPosts = true;
                syncOptions.teachers = true;
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.finance = true;
                syncOptions.notifications = true;
            } else if (user.role === 'parent') {
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.homework = true;
                syncOptions.notifications = true;
                syncOptions.parentAnnouncements = true;
            } else if (user.role === 'student') {
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.homework = true;
                syncOptions.tests = true;
                syncOptions.testResults = true;
                syncOptions.timetable = true;
                syncOptions.notifications = true;
                syncOptions.libraryBooks = true;
            }
            
            SupabaseSync.syncOnLogin(syncOptions)
                .then(result => {
                    console.log('Login sync completed:', result);
                    if (result.downloaded) {
                        console.log('Students downloaded:', result.downloaded.students || 0);
                        console.log('Users downloaded:', result.downloaded.users || 0);
                    }
                })
                .catch(err => console.warn('Login sync failed:', err));
        } else {
            console.log('Skipping login sync - Supabase not enabled or not ready');
        }

        const result = { success: true, user: session.user };
        if (warningMessage) {
            result.warning = true;
            result.message = warningMessage;
            result.schoolId = user.schoolId;
            if (schoolCheck?.school?.name) {
                result.schoolName = schoolCheck.school.name;
            }
        }
        return result;
    },

    clearNotifications(userId) {
        let notifications = Storage.getData('notifications') || [];
        notifications = notifications.filter(n => n.userId !== userId);
        Storage.setData('notifications', notifications);
    },

    markAllNotificationsAsRead(userId) {
        let notifications = Storage.getData('notifications') || [];
        notifications.forEach(n => {
            if (n.userId === userId) n.read = true;
        });
        Storage.setData('notifications', notifications);
    },

    login(credentials) {
        const { email, password, schoolId } = credentials;

        const users = Storage.getData('users');
        const hashedPassword = Storage.hashPassword(password);

        console.log('Login Comparison Debug:');
        console.log('--- Attempting login for:', email);
        console.log('--- Attempted password hash:', hashedPassword);
        console.log('--- Total local users:', users.length);

        const user = users.find(u => {
            const emailMatch = (u.email === email || u.username === email);
            const passMatch = (u.password === hashedPassword);

            if (u.username === email || u.email === email) {
                console.log(`--- Checking user: ${u.username || u.email}`);
                console.log(`--- Email/Username Match: ${emailMatch}`);
                console.log(`--- Password Hash Match: ${passMatch} (Stored: ${u.password})`);
            }

            return emailMatch && passMatch;
        });

        if (!user) {
            return { success: false, message: 'Invalid email/username or password' };
        }

        if (user.status !== 'active') {
            return { success: false, message: 'Your account is not active' };
        }

        if (user.role !== 'super_admin') {
            if (user.role === 'school_admin' || user.role === 'teacher' || user.role === 'accountant' || user.role === 'director' || user.role === 'parent') {
                if (!schoolId || schoolId === '') {
                    return { success: false, message: 'Please select your school' };
                }
                const userSchoolId = String(user.schoolId);
                const selectedSchoolId = String(schoolId);
                if (userSchoolId !== selectedSchoolId) {
                    return { success: false, message: 'Invalid school selection. Your account is not associated with this school.' };
                }
            }
        }

        // Super admin can login with or without selecting a school
        // For other roles, verify school subscription if they have a schoolId

        // For non-super_admin users, verify school subscription if they have a schoolId
        let warningMessage = null;
        let schoolCheck = null;
        if (user.role !== 'super_admin' && user.schoolId) {
            // First, try to fetch fresh school data from Supabase (non-blocking)
            if (typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
                SupabaseSync.fetchSchoolFromCloud(user.schoolId).catch(e => {
                    console.warn('Could not refresh school data from cloud:', e);
                });
            }
            
            // Check expiration (will use cached data if fetch not complete yet)
            schoolCheck = Storage.checkSchoolExpiration(user.schoolId);
            if (schoolCheck.expired) {
                return {
                    success: false,
                    message: 'School subscription has expired. Please contact the administrator to renew.',
                    expired: true,
                    schoolName: schoolCheck.school?.name
                };
            }

            if (schoolCheck.daysLeft && schoolCheck.daysLeft <= 7) {
                // Don't return early - collect warning and continue to create session
                warningMessage = `School subscription expires in ${schoolCheck.daysLeft} days. Please renew soon.`;
            }
        }

        // Check if user's dashboard access is enabled
        if (user.role !== 'super_admin' && user.role !== 'student') {
            const school = Storage.getSchoolById(user.schoolId);
            if (school) {
                const roleToDashboard = {
                    'teacher': 'teacher_dashboard',
                    'school_admin': 'admin_dashboard',
                    'director': 'director_dashboard',
                    'accountant': 'accountant_dashboard',
                    'parent': 'parent_dashboard'
                };
                const dashboardKey = roleToDashboard[user.role];
                if (dashboardKey) {
                    const restrictions = school.restrictions || {};
                    const disabledDashboards = restrictions.disabled_dashboards || [];
                    if (disabledDashboards.includes(dashboardKey)) {
                        return {
                            success: false,
                            message: `Your ${Auth.DASHBOARD_ACCESS[dashboardKey]} has been disabled by the Super Admin. Please contact support.`
                        };
                    }
                }
            }
         }

        // Ensure school has default Chart of Accounts
        if (typeof Storage.ensureSchoolHasChartOfAccounts === 'function' && user.schoolId) {
            Storage.ensureSchoolHasChartOfAccounts(user.schoolId);
        }

        const session = {
            userId: user.id,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                username: user.username,
                role: user.role,
                schoolId: user.schoolId,
                avatar: user.avatar,
                phone: user.phone
            },
            schoolId: user.schoolId,
            loginAt: new Date().toISOString(),
            expiresAt: new Date(Date.now() + this.SESSION_TIMEOUT).toISOString()
        };

        localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));

        this.logActivity(user.id, 'login', 'User logged in');
        
        if (typeof Storage.logAudit === 'function') {
            Storage.logAudit(user.id, user.schoolId, 'LOGIN', 'user', user.id);
        }

        // Sync from cloud after login - role-based sync options
        if (typeof SupabaseSync !== 'undefined' && isSupabaseEnabled()) {
            const syncOptions = { schools: true, users: true, students: true, systemConfig: true };
            
            // Add role-specific sync tables
            if (user.role === 'teacher') {
                syncOptions.teachers = true;
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.tests = true;
                syncOptions.testResults = true;
                syncOptions.questions = true;
                syncOptions.homework = true;
                syncOptions.homework_submissions = true;
                syncOptions.timetable = true;
                syncOptions.notifications = true;
                syncOptions.staffAttendance = true;
            } else if (user.role === 'school_admin' || user.role === 'director') {
                syncOptions.teachers = true;
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.finance = true;
                syncOptions.chart_of_accounts = true;
                syncOptions.budgets = true;
                syncOptions.accounts_receivable = true;
                syncOptions.receipts = true;
                syncOptions.homework = true;
                syncOptions.timetable = true;
                syncOptions.notifications = true;
                syncOptions.staffAttendance = true;
                syncOptions.tests = true;
                syncOptions.testResults = true;
                syncOptions.questions = true;
                syncOptions.homework_submissions = true;
            } else if (user.role === 'accountant') {
                syncOptions.finance = true;
                syncOptions.chart_of_accounts = true;
                syncOptions.budgets = true;
                syncOptions.accounts_receivable = true;
                syncOptions.receipts = true;
                syncOptions.notifications = true;
            } else if (user.role === 'super_admin') {
                syncOptions.activationCodes = true;
                syncOptions.adverts = true;
                syncOptions.blogPosts = true;
                syncOptions.teachers = true;
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.finance = true;
                syncOptions.notifications = true;
            } else if (user.role === 'parent') {
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.homework = true;
                syncOptions.notifications = true;
                syncOptions.parentAnnouncements = true;
            } else if (user.role === 'student') {
                syncOptions.attendance = true;
                syncOptions.scores = true;
                syncOptions.homework = true;
                syncOptions.tests = true;
                syncOptions.testResults = true;
                syncOptions.timetable = true;
                syncOptions.notifications = true;
                syncOptions.libraryBooks = true;
            }
            
            // Don't await this - it's a background sync that shouldn't block login
            SupabaseSync.syncOnLogin(syncOptions).catch(err => console.warn('Login sync failed:', err));
        }

        const result = { success: true, user: session.user };
        if (warningMessage) {
            result.warning = true;
            result.message = warningMessage;
            result.schoolId = user.schoolId;
            // Get school name from schoolCheck if available
            if (schoolCheck?.school?.name) {
                result.schoolName = schoolCheck.school.name;
            }
        }
        return result;
    },

    logActivity(userId, type, description) {
        const activities = Storage.getData('activities') || [];
        activities.push({
            id: Storage.generateId(),
            userId: userId,
            type: type,
            description: description,
            timestamp: new Date().toISOString()
        });
        Storage.setData('activities', activities);
    },

    addNotification(userId, message, type = 'info') {
        const notifications = Storage.getData('notifications') || [];
        const notification = {
            id: Storage.generateId(),
            userId: userId,
            title: message.substring(0, 100),
            message: message,
            type: type,
            read: false,
            createdAt: new Date().toISOString()
        };
        notifications.unshift(notification);
        Storage.setData('notifications', notifications);
        
        // Sync to Supabase
        if (typeof SupabaseSync !== 'undefined') {
            SupabaseSync.uploadItem('notifications', notification).catch(e => console.warn('Notification sync failed:', e));
        }
    },

    async logout() {
        const session = this.getSession();

        // Sign out from Supabase Auth first
        if (typeof SupabaseAuth !== 'undefined' && typeof SupabaseAuth.signOut === 'function') {
            await SupabaseAuth.signOut();
        }

        // Sync data to cloud before logout (if Supabase enabled)
        if (typeof SupabaseSync !== 'undefined' && isSupabaseEnabled()) {
            SupabaseSync.syncOnLogout().catch(err => console.warn('Logout sync failed:', err));
        }

        if (session?.user && typeof Storage.logAudit === 'function') {
            Storage.logAudit(session.user.id, session.schoolId, 'LOGOUT', 'user', session.user.id);
        }

        localStorage.removeItem(this.SESSION_KEY);
        // Robust redirect
        const currentPath = window.location.pathname;
        const loginPath = currentPath.includes('/pages/') ? '../login' : 'login';
        window.location.href = loginPath;
    },

    getSession() {
        const sessionJson = localStorage.getItem(this.SESSION_KEY);
        if (!sessionJson) return null;

        const session = JSON.parse(sessionJson);

        if (new Date(session.expiresAt) < new Date()) {
            this.logout();
            return null;
        }

        return session;
    },

    isAuthenticated() {
        return this.getSession() !== null;
    },

    getCurrentUser() {
        const session = this.getSession();
        return session ? session.user : null;
    },

    getCurrentSchoolId() {
        // Allow override for Super Admin viewing/editing school
        if (window.superAdminSchoolIdOverride) {
            return window.superAdminSchoolIdOverride;
        }
        const session = this.getSession();
        return session ? session.schoolId : null;
    },

    setSchoolIdOverride(schoolId) {
        window.superAdminSchoolIdOverride = schoolId;
    },

    clearSchoolIdOverride() {
        window.superAdminSchoolIdOverride = null;
    },

    hasRole(roles) {
        const user = this.getCurrentUser();
        if (!user) return false;

        if (typeof roles === 'string') {
            return user.role === roles;
        }

        return roles.includes(user.role);
    },

    hasPermission(permission) {
        const user = this.getCurrentUser();
        if (!user) return false;

        const permissions = {
            super_admin: ['all'],
            school_admin: ['manage_students', 'manage_teachers', 'manage_finance', 'view_reports', 'manage_attendance', 'generate_id_cards'],
            teacher: ['manage_students', 'manage_attendance', 'input_scores', 'view_reports'],
            accountant: ['manage_finance', 'view_reports'],
            director: ['view_all', 'view_reports', 'approve_finance']
        };

        const userPermissions = permissions[user.role] || [];
        return userPermissions.includes('all') || userPermissions.includes(permission);
    },

     hasFeature(feature) {
         const user = this.getCurrentUser();
         if (!user) return false;

         if (this.normalizeRole(user.role) === 'super_admin') return true;

         const school = this.getSchool();
         if (!school) return true;

         const restrictions = school.restrictions || {};
         const disabledFeatures = restrictions.disabled_features || [];

         return !disabledFeatures.includes(feature);
     },

     canAccessDashboard(role) {
         const user = this.getCurrentUser();
         if (!user) return false;

         if (this.normalizeRole(user.role) === 'super_admin') return true;

         const school = this.getSchool();
         if (!school) return true;

         const roleToDashboard = {
             'teacher': 'teacher_dashboard',
             'school_admin': 'admin_dashboard',
             'director': 'director_dashboard',
             'accountant': 'accountant_dashboard',
             'parent': 'parent_dashboard'
         };

         const dashboardKey = roleToDashboard[role];
         if (!dashboardKey) return true;

         const restrictions = school.restrictions || {};
         const disabledDashboards = restrictions.disabled_dashboards || [];

         return !disabledDashboards.includes(dashboardKey);
     },

    getSchoolRestrictions(schoolId) {
        const schools = Storage.getData('schools') || [];
        const school = schools.find(s => s.id === schoolId);
        return school ? (school.restrictions || { disabled_features: [] }) : { disabled_features: [] };
    },

    updateSchoolRestrictions(schoolId, restrictions) {
        const schools = Storage.getData('schools') || [];
        const schoolIndex = schools.findIndex(s => s.id === schoolId);

        if (schoolIndex === -1) return { success: false, message: 'School not found' };

        schools[schoolIndex].restrictions = {
            ...restrictions,
            updated_at: new Date().toISOString()
        };

        Storage.setData('schools', schools);
        return { success: true, message: 'Restrictions updated successfully' };
    },

    // Features that can be restricted by Super Admin
    RESTRICTABLE_FEATURES: {
        chat: 'Chat & Messaging',
        downloads: 'Data Export/Download',
        scores_entry: 'Score Entry',
        attendance_qr: 'QR Attendance Scanning',
        id_cards: 'ID Card Generation',
        finance: 'Finance Management',
        reports: 'Reports & Analytics',
        parent_portal: 'Parent Portal Access',
        multi_class: 'Multi-Class Management',
        sms: 'SMS Notifications',
        exams: 'Exams Management',
        question_bank: 'Question Bank',
        create_test: 'Create Test',
        test_results: 'Test Results',
        calendar_events: 'Calendar Events',
        print_export: 'Print & Export'
    },

    // Dashboard access keys for restriction
    DASHBOARD_ACCESS: {
        teacher_dashboard: 'Teacher Dashboard',
        admin_dashboard: 'Admin Dashboard',
        director_dashboard: 'Director Dashboard',
        accountant_dashboard: 'Accountant Dashboard',
        parent_dashboard: 'Parent Dashboard',
        student_dashboard: 'Student Dashboard'
    },

    checkAuth() {
        if (!this.isAuthenticated()) {
            const currentPath = window.location.pathname;
            const loginPath = currentPath.includes('/pages/') ? '../login.html' : 'login.html';
            window.location.href = loginPath;
            return false;
        }
        return true;
    },

     // Normalize role strings to handle common variations
     normalizeRole(role) {
         if (!role) return '';
         const roleMap = {
             'admin': 'school_admin',
             'Admin': 'school_admin',
             'administrator': 'school_admin',
             'School Admin': 'school_admin',
             'school admin': 'school_admin',
             'Teacher': 'teacher',
             'TEACHER': 'teacher',
             'techer': 'teacher',
             'Class Teacher': 'teacher',
             'Accountant': 'accountant',
             'accountant': 'accountant',
             'Director': 'director',
             'director': 'director',
             'Parent': 'parent',
             'parent': 'parent',
             'Super Admin': 'super_admin',
             'super admin': 'super_admin',
             'SUPER_ADMIN': 'super_admin'
         };
         const normalized = role.toString().toLowerCase().trim();
         return roleMap[normalized] || roleMap[role] || role;
     },

     checkRole(allowedRoles) {
         if (!this.checkAuth()) return false;

         const user = this.getCurrentUser();
         if (!user) {
             console.error('[Auth] No user in session during checkRole');
             this.logout();
             return false;
         }

         const normalizedUserRole = this.normalizeRole(user.role);
         const normalizedAllowed = allowedRoles.map(r => this.normalizeRole(r));

         if (!normalizedAllowed.includes(normalizedUserRole)) {
             console.warn('[Auth] Role mismatch:', {
                 actual: user.role,
                 normalized: normalizedUserRole,
                 expected: allowedRoles,
                 normalizedExpected: normalizedAllowed,
                 userId: user.id
             });
             const currentPath = window.location.pathname;
             const loginPath = currentPath.includes('/pages/') ? '../login.html' : 'login.html';
             window.location.href = loginPath;
             return false;
         }
         return true;
     },

    async registerSchool(data) {
        const { activationCode, schoolName, schoolAlias, schoolEmail, schoolPhone, schoolAddress, schoolType, currency, adminName, adminUsername, adminEmail, adminPhone, adminPassword } = data;

        let validation = Storage.validateActivationCode(activationCode);

        // If not found locally, check Supabase
        if (!validation.valid && typeof SupabaseSync !== 'undefined' && typeof SupabaseSync.isReady === 'function' && SupabaseSync.isReady()) {
            validation = await Storage.validateActivationCodeFromCloud(activationCode);
            if (validation && validation.valid) {
                // Add to local storage for future use
                Storage.addItem('activationCodes', validation.code);
            }
        }

        if (!validation.valid) {
            return { success: false, message: validation.message };
        }

        const existingSchools = Storage.getSchools();
        if (existingSchools.some(s => s.name.toLowerCase() === schoolName.toLowerCase())) {
            return { success: false, message: 'School with this name already exists' };
        }

        const schoolId = Storage.generateId();

        const subscriptionDays = validation.code.subscriptionDays || 365;
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + subscriptionDays);

        const school = {
            id: schoolId,
            name: schoolName,
            alias: schoolAlias || schoolName.substring(0, 3).toUpperCase(),
            email: schoolEmail,
            phone: schoolPhone,
            address: schoolAddress,
            type: schoolType,
            currency: currency,
            status: 'active',
            activationCodeId: validation.code.id,
            createdAt: new Date().toISOString(),
            expiresAt: expiresAt.toISOString(),
            subscriptionDays: subscriptionDays,
            settings: {
                classes: Storage.getClassesBySchoolType(schoolType),
                subjects: Storage.getSubjectsBySchoolType(schoolType),
                scoreTypes: Storage.SCORE_TYPES
            },
            restrictions: {
                disabled_features: [],
                max_students: null,
                max_staff: null,
                restriction_note: ''
            }
        };

        Storage.addItem('schools', school);

        const adminUser = {
            id: Storage.generateId(),
            name: adminName,
            username: adminUsername,
            email: adminEmail,
            phone: adminPhone,
            password: Storage.hashPassword(adminPassword),
            role: 'school_admin',
            schoolId: schoolId,
            status: 'active',
            createdAt: new Date().toISOString(),
            avatar: null
        };

        Storage.addItem('users', adminUser);

        Storage.useActivationCode(validation.code.id, schoolId);

        // Seed default Chart of Accounts for the new school
        Storage.seedChartOfAccountsForSchool(schoolId);

        // Sync to Supabase immediately after registration
        let syncResult = { success: false, reason: 'Supabase not available' };
        
        if (typeof SupabaseSync !== 'undefined' && typeof SupabaseSync.isReady === 'function' && SupabaseSync.isReady()) {
            try {
                // Wait for Supabase to be ready
                if (window.supabaseReady) {
                    await window.supabaseReady;
                }
                
                // Small delay to ensure everything is initialized
                await new Promise(resolve => setTimeout(resolve, 500));
                
                // Sync school
                const schoolResult = await SupabaseSync.uploadItem('schools', school);
                console.log('School sync result:', schoolResult);
                
                // Sync admin user
                const userResult = await SupabaseSync.uploadItem('users', adminUser);
                console.log('User sync result:', userResult);
                
                // Mark activation code as used in cloud
                if (validation.code) {
                    await SupabaseSync.uploadItem('activationCodes', {
                        ...validation.code,
                        isUsed: true,
                        usedAt: new Date().toISOString()
                    });
                }
                
                syncResult = { success: true, message: 'School and admin synced to cloud' };
                console.log('School registration synced to Supabase successfully');
            } catch (syncErr) {
                console.error('Sync error during registration:', syncErr);
                syncResult = { success: false, reason: syncErr.message };
            }
        }

        return { success: true, message: 'School registered successfully', school, syncResult };
    },

    async autoSyncSchoolData(school, adminUser, activationCode) {
        console.log('=== Starting Auto-Sync ===');

        // Wait for Supabase to be fully initialized
        if (window.supabaseReady) {
            console.log('Waiting for Supabase to be ready...');
            try {
                await window.supabaseReady;
                console.log('Supabase promise resolved');
            } catch (e) {
                console.warn('Supabase promise failed:', e);
            }
        }

        // Small delay to ensure everything is initialized
        await new Promise(resolve => setTimeout(resolve, 500));

        // Check if Supabase is available
        const supabaseAvailable = typeof getSupabase === 'function' && typeof isSupabaseEnabled === 'function' && isSupabaseEnabled();

        if (!supabaseAvailable) {
            console.warn('⚠️ Supabase not ready, skipping auto-sync. getSupabase:', typeof getSupabase, 'isSupabaseEnabled:', typeof isSupabaseEnabled === 'function' ? isSupabaseEnabled() : 'not a function');
            return { success: false, reason: 'Supabase not ready' };
        }

        console.log('✅ Supabase is ready');

        // Only include known fields to avoid column errors
        const filterKnownFields = (obj, knownFields) => {
            const filtered = {};
            knownFields.forEach(field => {
                if (obj[field] !== undefined) {
                    const snakeKey = field.replace(/([A-Z])/g, '_$1').toLowerCase();
                    filtered[snakeKey] = obj[field];
                }
            });
            return filtered;
        };

        // Known fields for each table - only sync fields that exist in Supabase
        const schoolFields = ['id', 'name', 'alias', 'email', 'phone', 'address', 'type', 'currency', 'status', 'settings', 'restrictions', 'activationCodeId', 'createdAt', 'expiresAt', 'subscriptionDays'];
        const userFields = ['id', 'name', 'email', 'phone', 'username', 'password', 'role', 'schoolId', 'status', 'avatar', 'settings', 'createdAt'];
        const knownFieldsMap = {
            'activationCodes': ['id', 'code', 'schoolId', 'isUsed', 'isRevoked', 'subscriptionDays', 'expiresAt', 'createdAt', 'usedAt'],
            'calendarEvents': ['id', 'schoolId', 'title', 'description', 'eventDate', 'eventType', 'createdAt'],
            'teachers': ['id', 'userId', 'schoolId', 'name', 'email', 'phone', 'classes', 'subjects', 'createdAt'],
            'finance': ['id', 'schoolId', 'type', 'category', 'amount', 'description', 'date', 'createdBy', 'createdAt']
        };
        const tableNameMap = {
            'schools': 'schools',
            'users': 'users',
            'activationCodes': 'activation_codes',
            'calendarEvents': 'calendar_events',
            'teachers': 'teachers',
            'finance': 'finance'
        };

        const codeFields = knownFieldsMap.activationCodes;

        const supabase = getSupabase();
        console.log('Supabase client:', supabase ? '✅ Available' : '❌ Not available');

        if (!supabase) {
            console.error('❌ Supabase client is null');
            return { success: false, reason: 'Supabase client not available' };
        }

        // Sync school
        const schoolData = filterKnownFields(school, schoolFields);
        console.log('Syncing school:', schoolData);

        const { error: schoolError } = await supabase.from('schools').upsert(schoolData, { onConflict: 'id' });

        if (schoolError) {
            console.error('❌ School sync failed:', schoolError.message);
            throw new Error('School sync failed: ' + schoolError.message);
        }
        console.log('✅ School synced successfully');

        // Sync admin user
        const userData = filterKnownFields(adminUser, userFields);
        console.log('Syncing user:', userData);

        const { error: userError } = await supabase.from('users').upsert(userData, { onConflict: 'id' });

        if (userError) {
            console.error('❌ User sync failed:', userError.message);
            throw new Error('User sync failed: ' + userError.message);
        }
        console.log('✅ User synced successfully');

        // Mark activation code as used in cloud
        const codeData = filterKnownFields(activationCode, codeFields);
        codeData.school_id = school.id;
        codeData.is_used = true;
        codeData.is_revoked = false;
        codeData.used_at = new Date().toISOString();

        console.log('Syncing activation code:', codeData);

        const { error: codeError } = await supabase.from('activation_codes').upsert(codeData, { onConflict: 'id' });

        if (codeError) {
            console.error('❌ Activation code sync failed:', codeError.message);
            throw new Error('Activation code sync failed: ' + codeError.message);
        }

        console.log('✅ All data synced successfully!');
        console.log('=== Auto-Sync Complete ===');

        return { success: true };
    },

    async registerUser(userData) {
        const { name, email, phone, username, password, role, schoolId, className, id } = userData;

        const users = Storage.getData('users');
        if (users.some(u => u.email === email)) {
            return { success: false, message: 'Email already exists' };
        }
        if (users.some(u => u.username === username)) {
            return { success: false, message: 'Username already exists' };
        }

        const user = {
            id: id || undefined, // Use provided ID if exists
            name,
            email,
            phone,
            username,
            password: Storage.hashPassword(password),
            role,
            schoolId,
            className: className || null,
            status: 'active',
            avatar: null
        };

        const savedUser = Storage.addItem('users', user);

        if (role === 'teacher') {
            const teacherProfile = {
                id: Storage.generateId(),
                userId: savedUser.id,
                schoolId,
                name,
                email,
                phone,
                classes: [],
                subjects: [],
                createdAt: new Date().toISOString()
            };
            Storage.addItem('teachers', teacherProfile);
        }

        if (role === 'student') {
            const studentId = Storage.generateUniqueId('STU');
            const student = {
                id: studentId,
                userId: savedUser.id,
                schoolId,
                name,
                username, // Store for portal access
                password: savedUser.password, // Store hashed password for portal access
                email,
                phone,
                class: className,
                status: 'active',
                enrollmentDate: new Date().toISOString()
            };
            Storage.addItem('students', student);
        }

        return { success: true, message: 'User registered successfully', user: savedUser };
    },

    updateProfile(userId, updates) {
        const users = Storage.getData('users');
        const index = users.findIndex(u => u.id === userId);

        if (index === -1) {
            return { success: false, message: 'User not found' };
        }

        if (updates.password) {
            updates.password = Storage.hashPassword(updates.password);
        }

        const updatedUser = Storage.updateItem('users', userId, updates);

        const session = this.getSession();
        if (session && session.userId === userId) {
            session.user = { ...session.user, ...updates };
            localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));
        }

        return { success: true, message: 'Profile updated successfully', user: updatedUser };
    },

    changePassword(userId, oldPassword, newPassword) {
        const user = Storage.getItemById('users', userId);

        if (!user || user.password !== Storage.hashPassword(oldPassword)) {
            return { success: false, message: 'Current password is incorrect' };
        }

        const updatedUser = Storage.updateItem('users', userId, {
            password: Storage.hashPassword(newPassword)
        });

        return { success: true, message: 'Password changed successfully' };
    },

    // In auth.js, modify getSchool:
    getSchool() {
        const session = this.getSession();
        if (!session) return null;

        if (session.user.role === 'super_admin') {
            return { id: null, name: 'Super Admin', type: 'super_admin' };
        }

        // Try cache first
        const cached = CacheManager.get(`school_${session.schoolId}`);
        if (cached) {
            return cached;
        }

        // If not in cache, get from storage
        const school = Storage.getSchoolById(session.schoolId);

        // Cache for 5 minutes
        CacheManager.set(`school_${session.schoolId}`, school);

        return school;
     },

      clearSchoolCache(schoolId) {
          if (typeof CacheManager !== 'undefined') {
              CacheManager.delete(`school_${schoolId}`);
          }
       },

      // Complete login flow: checks, session creation, audit, sync
      async completeLogin(user, schoolId) {
          // Validate user status
          if (user.status !== 'active') {
              return { success: false, message: 'Your account is not active' };
          }

          // School validation for non-super_admin roles (excluding students)
          if (user.role !== 'super_admin' && user.role !== 'student') {
              if (!schoolId || schoolId === '') {
                  return { success: false, message: 'Please select your school' };
              }
              const userSchoolId = String(user.schoolId);
              const selectedSchoolId = String(schoolId);
              if (userSchoolId !== selectedSchoolId) {
                  return {
                      success: false,
                      message: 'Invalid school selection. Your account is not associated with this school.'
                  };
              }
          }

          // Check school subscription for non-super_admin
          let warningMessage = null;
          let schoolCheck = null;
          if (user.role !== 'super_admin' && user.schoolId) {
              // First, try to fetch fresh school data from Supabase - WAIT for it!
              if (typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
                  try {
                      await SupabaseSync.fetchSchoolFromCloud(user.schoolId);
                      // Small delay to ensure localStorage is updated
                      await new Promise(resolve => setTimeout(resolve, 100));
                  } catch (e) {
                      console.warn('Could not refresh school data from cloud:', e);
                  }
              }
              
              // Check expiration with potentially refreshed data
              schoolCheck = Storage.checkSchoolExpiration(user.schoolId);
              if (schoolCheck.expired) {
                  return {
                      success: false,
                      message: 'School subscription has expired. Please contact the administrator to renew.',
                      expired: true,
                      schoolName: schoolCheck.school?.name
                  };
              }
              if (schoolCheck.daysLeft && schoolCheck.daysLeft <= 7) {
                  warningMessage = `School subscription expires in ${schoolCheck.daysLeft} days. Please renew soon.`;
              }
          }

          // Dashboard restrictions
          if (user.role !== 'super_admin' && user.role !== 'student') {
              const school = Storage.getSchoolById(user.schoolId);
              if (school) {
                  const roleToDashboard = {
                      'teacher': 'teacher_dashboard',
                      'school_admin': 'admin_dashboard',
                      'director': 'director_dashboard',
                      'accountant': 'accountant_dashboard',
                      'parent': 'parent_dashboard'
                  };
                  const dashboardKey = roleToDashboard[user.role];
                  if (dashboardKey) {
                      const restrictions = school.restrictions || {};
                      const disabledDashboards = restrictions.disabled_dashboards || [];
                      if (disabledDashboards.includes(dashboardKey)) {
                          return {
                              success: false,
                              message: `Your ${Auth.DASHBOARD_ACCESS[dashboardKey]} has been disabled by the Super Admin. Please contact support.`
                          };
                      }
                  }
              }
          }

          // Create session
          const session = {
              userId: user.id,
              user: {
                  id: user.id,
                  name: user.name,
                  email: user.email,
                  username: user.username,
                  role: user.role,
                  schoolId: user.schoolId,
                  avatar: user.avatar,
                  phone: user.phone
              },
              schoolId: user.schoolId,
              loginAt: new Date().toISOString(),
              expiresAt: new Date(Date.now() + this.SESSION_TIMEOUT).toISOString()
          };
          localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));

          this.logActivity(user.id, 'login', 'User logged in');

          if (typeof Storage.logAudit === 'function') {
              Storage.logAudit(user.id, user.schoolId, 'LOGIN', 'user', user.id);
          }

          // Role-based sync after login (non-blocking)
          if (typeof SupabaseSync !== 'undefined' && isSupabaseEnabled()) {
              const syncOptions = { systemConfig: true };
              
              // Add role-specific data sync
              if (user.role === 'student') {
                  // Sync students for this student's school (including their class)
                  syncOptions.students = true;
                  syncOptions.attendance = true;
                  syncOptions.scores = true;
                  syncOptions.homework = true;
                  syncOptions.homework_submissions = true;
                  syncOptions.timetable = true;
                  syncOptions.notifications = true;
              } else if (user.role === 'teacher') {
                  // Sync teachers and their related data
                  syncOptions.teachers = true;
                  syncOptions.attendance = true;
                  syncOptions.scores = true;
                  syncOptions.tests = true;
                  syncOptions.testResults = true;
                  syncOptions.homework = true;
                  syncOptions.timetable = true;
                  syncOptions.notifications = true;
              } else if (user.role === 'school_admin' || user.role === 'director' || user.role === 'accountant') {
                  // Sync core data for admin roles
                  syncOptions.schools = true;
                  syncOptions.teachers = true;
                  syncOptions.students = true;
                  syncOptions.attendance = true;
                  syncOptions.finance = true;
                  syncOptions.chart_of_accounts = true;
                  syncOptions.budgets = true;
                  syncOptions.accounts_receivable = true;
                  syncOptions.receipts = true;
                  syncOptions.homework = true;
                  syncOptions.notifications = true;
              } else if (user.role === 'parent') {
                  // Sync parent-specific data
                  syncOptions.students = true; // parent needs to see their children
                  syncOptions.attendance = true;
                  syncOptions.scores = true;
                  syncOptions.homework = true;
                  syncOptions.notifications = true;
              }
              
              // Fire and forget - don't block login
              SupabaseSync.syncOnLogin(syncOptions).catch(err => console.warn('Login sync failed:', err));
          }

          const result = { success: true, user: session.user };
          if (warningMessage) {
              result.warning = true;
              result.message = warningMessage;
              result.schoolId = user.schoolId;
              if (schoolCheck?.school?.name) {
                  result.schoolName = schoolCheck.school.name;
              }
          }
          return result;
      },

      // Pure local login (no Supabase)
      localLogin(credentials) {
          const { email, password, schoolId } = credentials;
          const users = Storage.getData('users') || [];
          const hashedPassword = Storage.hashPassword(password);
          const emailLower = email.toLowerCase();

          const user = users.find(u => {
              const emailMatch = (u.email && u.email.toLowerCase() === emailLower) || 
                                (u.username && u.username.toLowerCase() === emailLower);
              return emailMatch && u.password === hashedPassword;
          });

          if (!user) {
              return { success: false, message: 'Invalid email/username or password' };
          }

          if (user.status !== 'active') {
              return { success: false, message: 'Your account is not active' };
          }

          // School validation for non-super_admin
          if (user.role !== 'super_admin') {
              if (!schoolId || schoolId === '') {
                  return { success: false, message: 'Please select your school' };
              }
              const userSchoolId = String(user.schoolId);
              const selectedSchoolId = String(schoolId);
              if (userSchoolId !== selectedSchoolId) {
                  return { success: false, message: 'Invalid school selection. Your account is not associated with this school.' };
              }
          }

          // Use completeLogin to finish
          return this.completeLogin(user, schoolId);
      }
}

const StudentAuth = {
    SESSION_KEY: 'mySchoolStudentSession',

    async login(studentIdOrUsername, password, schoolId) {
        try {
            // Sync from cloud after login - student role sync options
            if (typeof SupabaseSync !== 'undefined' && typeof SupabaseSync.isReady === 'function' && SupabaseSync.isReady()) {
                const syncOptions = { 
                    schools: true, 
                    users: true, 
                    students: true, 
                    attendance: true,
                    scores: true,
                    homework: true,
                    tests: true,
                    testResults: true,
                    timetable: true,
                    notifications: true,
                    libraryBooks: true,
                    systemConfig: true 
                };
                
                SupabaseSync.syncOnLogin(syncOptions).catch(err => console.warn('Student login sync failed:', err));
            }

            const students = Storage.getStudents(schoolId);

            // Find student by ID or username
            const student = students.find(s =>
                s.id === studentIdOrUsername ||
                (s.username && s.username.toLowerCase() === studentIdOrUsername.toLowerCase()) ||
                (s.email && s.email.toLowerCase() === studentIdOrUsername.toLowerCase())
            );

            if (!student) {
                // Try to fetch from Supabase directly if not found locally
                if (typeof SupabaseSync !== 'undefined' && typeof SupabaseSync.isReady === 'function' && SupabaseSync.isReady()) {
                    if (typeof getSupabase === 'function' && typeof isSupabaseEnabled === 'function' && isSupabaseEnabled()) {
                        try {
                            const supabase = getSupabase();
                            const { data: studentData } = await supabase
                                .from('students')
                                .select('*')
                                .eq('id', studentIdOrUsername)
                                .single();

                            if (studentData) {
                                // Add to local storage
                                const allStudents = Storage.getData('students') || [];
                                allStudents.push(studentData);
                                Storage.setData('students', allStudents);

                                // Use the fetched student
                                const freshStudent = Storage.getStudents(schoolId).find(s => s.id === studentIdOrUsername);
                                if (freshStudent) {
                                    return this._completeStudentLogin(freshStudent, schoolId, password);
                                }
                            }
                        } catch (e) {
                            console.warn('Failed to fetch student from Supabase:', e);
                        }
                    }
                }
                return { success: false, message: 'Invalid Student ID or Username' };
            }

            return this._completeStudentLogin(student, schoolId, password);
        } catch (error) {
            console.error('Student login error:', error);
            return { success: false, message: 'Login failed due to an error' };
        }
    },

    _completeStudentLogin(student, schoolId, password) {
        if (student.status !== 'active') {
            return { success: false, message: 'Your account is not active' };
        }

        // Check password (default is student ID if not set)
        const storedPassword = student.password || student.id;
        const hashedInput = Storage.hashPassword(password);

        if (storedPassword !== hashedInput && storedPassword !== password) {
            return { success: false, message: 'Invalid password' };
        }

        // Check if student dashboard access is enabled
        const school = Storage.getSchoolById(schoolId);
        if (school) {
            const restrictions = school.restrictions || {};
            const disabledDashboards = restrictions.disabled_dashboards || [];
            if (disabledDashboards.includes('student_dashboard')) {
                return {
                    success: false,
                    message: 'Student Portal has been disabled by the Super Admin. Please contact support.'
                };
            }
        }

        // Create session
        const session = {
            userId: student.id,
            user: {
                id: student.id,
                name: student.name,
                email: student.email || '',
                role: 'student',
                schoolId: schoolId,
                class: student.class
            },
            schoolId: schoolId,
            loginTime: new Date().toISOString()
        };

        localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));

        return { success: true, message: 'Login successful' };
    },

    logout() {
        localStorage.removeItem(this.SESSION_KEY);
        const currentPath = window.location.pathname;
        const loginPath = currentPath.includes('/pages/') ? '../student-login.html' : './student-login.html';
        window.location.href = loginPath;
    },

    isAuthenticated() {
        const session = localStorage.getItem(this.SESSION_KEY);
        return session !== null;
    },

    getCurrentUser() {
        const session = localStorage.getItem(this.SESSION_KEY);
        if (!session) return null;
        try {
            return JSON.parse(session);
        } catch (e) {
            console.error('Failed to parse student session:', e);
            return null;
        }
    },

    getCurrentSchoolId() {
        const session = this.getCurrentUser();
        return session ? session.schoolId : null;
    },

    getCurrentStudent() {
        const session = this.getCurrentUser();
        if (!session) return null;

        const students = Storage.getStudents(session.schoolId);
        // Compare as strings to handle type mismatches (e.g., number vs string)
        const userId = String(session.userId);
        return students.find(s => String(s.id) === userId);
    },

    showForgotPassword() {
        const modal = document.getElementById('forgotPasswordModal');
        if (modal) {
            modal.classList.add('active');
        }
    },

    resetPassword() {
        const studentId = document.getElementById('resetStudentId').value.trim();
        const newPassword = document.getElementById('resetNewPassword').value;
        const confirmPassword = document.getElementById('resetConfirmPassword').value;
        const schoolId = document.getElementById('schoolSelect').value;

        if (!studentId || !newPassword || !confirmPassword) {
            Toast.error('Please fill all fields');
            return;
        }

        if (newPassword !== confirmPassword) {
            Toast.error('Passwords do not match');
            return;
        }

        if (newPassword.length < 4) {
            Toast.error('Password must be at least 4 characters');
            return;
        }

        const students = Storage.getStudents(schoolId);
        const student = students.find(s => s.id === studentId);

        if (!student) {
            Toast.error('Student ID not found');
            return;
        }

        // Update password with hashing
        const hashedPassword = Storage.hashPassword(newPassword);
        Storage.updateItem('students', studentId, {
            password: hashedPassword
        });

        Toast.success('Password reset successfully! You can now login.');
        Modal.hide('forgotPasswordModal');
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const publicPages = ['index', 'login', 'register-school', 'student-login', 'parent-login'];
    const protectedDashboards = [
        { clean: '/student', html: '/pages/student.html', type: 'student' },
        { clean: '/parent', html: '/parent.html', type: 'parent' },
        { clean: '/pages/student', html: '/pages/student.html', type: 'student' },
        { clean: '/pages/parent', html: '/pages/parent.html', type: 'parent' }
    ];

    const currentPath = window.location.pathname;
    
    // Normalize path: strip .html extension if present
    const normalizedPath = currentPath.replace(/\.html$/, '');
    
    // Check if current page is a protected dashboard
    const dashboard = protectedDashboards.find(d => 
        currentPath.endsWith(d.html) || normalizedPath === d.clean || normalizedPath.endsWith(d.clean)
    );

    if (dashboard) {
        // Dashboard access control
        if (dashboard.type === 'student' && !StudentAuth.isAuthenticated()) {
            // Redirect to student login (relative path based on depth)
            const loginPath = currentPath.includes('/pages/') ? '../student-login.html' : './student-login.html';
            window.location.href = loginPath;
            return;
        }
        if (dashboard.type === 'parent' && !Auth.isAuthenticated()) {
            const loginPath = currentPath.includes('/pages/') ? '../parent-login.html' : './parent-login.html';
            window.location.href = loginPath;
            return;
        }
        return;
    }

    // Check if public page
    let currentPage = currentPath.split('/').pop() || 'index';
    if (currentPage.endsWith('.html')) {
        currentPage = currentPage.slice(0, -5);
    }
    const isPublicPage = publicPages.includes(currentPage);

    // If trying to access non-public page without auth, redirect to main login
    if (!isPublicPage && !Auth.isAuthenticated()) {
        const loginRedirect = currentPath.includes('/pages/') ? '../login.html' : 'login.html';
        window.location.href = loginRedirect;
    }
});

window.Auth = Auth;
Auth.login = Auth.loginWithSupabase;
console.log('Auth module loaded and globally assigned');

// Mobile Gestures for Responsive Navigation
const MobileGestures = {
    init() {
        this.setupSwipeGestures();
    },

    setupSwipeGestures() {
        document.addEventListener('DOMContentLoaded', () => {
            const overlay = document.querySelector('.sidebar-overlay');
            if (!overlay) {
                console.warn('Sidebar overlay not found - mobile gestures disabled');
                return;
            }

            let startX = 0;
            let startY = 0;
            let isSwiping = false;

            overlay.addEventListener('touchstart', (e) => {
                startX = e.touches[0].clientX;
                startY = e.touches[0].clientY;
                isSwiping = true;
            }, { passive: true });

            overlay.addEventListener('touchmove', (e) => {
                if (!isSwiping) return;
                const currentX = e.touches[0].clientX;
                const diffX = startX - currentX;
                const diffY = Math.abs(startY - e.touches[0].clientY);
                if (diffX > 30 && diffY < 30) {
                    const sidebar = document.querySelector('.sidebar');
                    if (sidebar) {
                        sidebar.style.transition = 'none';
                        sidebar.style.transform = `translateX(${diffX - 280}px)`;
                    }
                }
            }, { passive: true });

            overlay.addEventListener('touchend', (e) => {
                if (!isSwiping) return;
                isSwiping = false;
                
                const endX = e.changedTouches[0].clientX;
                const diff = startX - endX;
                
                const sidebar = document.querySelector('.sidebar');
                if (sidebar) {
                    sidebar.style.transition = '';
                    sidebar.style.transform = '';
                }
                
                if (diff > 50) {
                    if (window.toggleSidebar) {
                        window.toggleSidebar();
                    }
                }
            }, { passive: true });
        });
    }
};

// QR Scanner Fullscreen Toggle
function toggleQrFullscreen() {
    const container = document.getElementById('qrScannerContainer');
    if (!container) return;
    
    if (container.requestFullscreen) {
        container.requestFullscreen().catch(err => {
            console.log('Fullscreen not supported:', err);
        });
    } else if (container.webkitRequestFullscreen) {
        container.webkitRequestFullscreen();
    } else if (container.msRequestFullscreen) {
        container.msRequestFullscreen();
    }
    
    // Listen for fullscreen change to update button icon
    document.addEventListener('fullscreenchange', () => {
        const btn = document.getElementById('qrFullscreenBtn');
        if (btn) {
            const icon = btn.querySelector('i');
            if (document.fullscreenElement) {
                icon.className = 'fas fa-compress';
            } else {
                icon.className = 'fas fa-expand';
            }
        }
    });
}

if (typeof window !== 'undefined') {
    window.MobileGestures = MobileGestures;
    window.toggleQrFullscreen = toggleQrFullscreen;
}

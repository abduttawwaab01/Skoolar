// =====================================================
// SUPABASE AUTH MODULE
// Handles authentication using Supabase Auth
// =====================================================

const SupabaseAuth = {
    session: null,
    user: null,
    authListener: null,

    // Initialize auth state listener
    init() {
        if (!isSupabaseEnabled()) {
            console.log('Supabase not enabled, skipping auth init');
            return;
        }

        const supabase = getSupabase();
        if (!supabase) {
            console.error('Supabase client not available');
            return;
        }

        // Set up auth state change listener
        this.authListener = supabase.auth.onAuthStateChange(
            async (event, session) => {
                console.log('Auth state change:', event, session?.user?.email);

                if (session) {
                    this.session = session;
                    this.user = session.user;

                    // Fetch custom user profile from users table
                    await this.fetchUserProfile(session.user.id);

                    // Store session in localStorage for offline fallback
                    this.cacheSession(session);
                } else {
                    this.session = null;
                    this.user = null;
                    localStorage.removeItem('supabase_session');
                }

                // Dispatch custom event for other modules
                window.dispatchEvent(new CustomEvent('auth-state-change', {
                    detail: { event, session: this.session, user: this.user }
                }));
            }
        );

        // Check for existing session on load
        supabase.auth.getSession().then(({ data: { session } }) => {
            if (session) {
                this.session = session;
                this.user = session.user;
                this.fetchUserProfile(session.user.id);
            }
        }).catch(err => {
            console.warn('Error getting session:', err);
        });
    },

    // Fetch custom user profile from users table
    async fetchUserProfile(userId) {
        try {
            const supabase = getSupabase();
            if (!supabase) return null;

            const { data, error } = await supabase
                .from('users')
                .select('*')
                .eq('id', userId)
                .single();

            if (error) {
                console.warn('User profile not found in users table:', error.message);
                return null;
            }

            // Store profile in session storage for quick access
            localStorage.setItem('user_profile', JSON.stringify(data));

            // Also store in local Storage.users array (for offline fallback and consistency)
            if (typeof Storage !== 'undefined' && typeof Storage.addItem === 'function') {
                const existingUsers = Storage.getData('users') || [];
                const existingIndex = existingUsers.findIndex(u => u.id === data.id);
                if (existingIndex >= 0) {
                    existingUsers[existingIndex] = data;
                } else {
                    existingUsers.push(data);
                }
                Storage.setData('users', existingUsers);
            }

            return data;
        } catch (err) {
            console.error('Error fetching user profile:', err);
            return null;
        }
    },

    // Sign up new user
    async signUp(email, password, userData = {}) {
        try {
            const supabase = getSupabase();
            if (!supabase) {
                return { success: false, message: 'Supabase not configured' };
            }

            // Check if email already exists in users table
            const { data: existingUsers } = await supabase
                .from('users')
                .select('email')
                .eq('email', email);

            if (existingUsers && existingUsers.length > 0) {
                return { success: false, message: 'Email already registered' };
            }

            // Sign up with Supabase Auth
            const { data, error } = await supabase.auth.signUp({
                email,
                password,
                options: {
                    emailRedirectTo: window.location.origin + '/login.html'
                }
            });

            if (error) {
                return { success: false, message: error.message };
            }

            if (data.user) {
                // Create user profile in users table
                const userProfile = {
                    id: data.user.id,
                    name: userData.name || email.split('@')[0],
                    email: email,
                    username: userData.username || email.split('@')[0],
                    phone: userData.phone || '',
                    role: userData.role || 'student', // default role
                    school_id: userData.schoolId || null,
                    status: 'active',
                    avatar: null,
                    created_at: new Date().toISOString()
                };

                const { error: profileError } = await supabase
                    .from('users')
                    .insert(userProfile);

                if (profileError) {
                    console.error('Error creating user profile:', profileError);
                }

                const needsVerification = !!data.user.confirmation_sent_at;
                
                return {
                    success: true,
                    message: needsVerification 
                        ? 'Registration successful! Please check your email to verify your account.'
                        : 'Registration successful! You can now log in.',
                    user: userProfile,
                    needsVerification: needsVerification
                };
            }

            return { success: false, message: 'Registration failed' };
        } catch (err) {
            console.error('Sign up error:', err);
            return { success: false, message: err.message };
        }
    },

    // Sign in with email and password
    async signIn(email, password) {
        try {
            const supabase = getSupabase();
            if (!supabase) {
                return { success: false, message: 'Supabase not configured' };
            }

            const { data, error } = await supabase.auth.signInWithPassword({
                email,
                password
            });

            if (error) {
                return { success: false, message: error.message };
            }

            if (data.user) {
                // Fetch user profile
                const profile = await this.fetchUserProfile(data.user.id);

                return {
                    success: true,
                    user: {
                        id: data.user.id,
                        email: data.user.email,
                        ...profile
                    },
                    session: data.session
                };
            }

            return { success: false, message: 'Login failed' };
        } catch (err) {
            console.error('Sign in error:', err);
            return { success: false, message: err.message };
        }
    },

    // Sign out
    async signOut() {
        try {
            const supabase = getSupabase();
            if (!supabase) {
                return { success: false, message: 'Supabase not configured' };
            }

            const { error } = await supabase.auth.signOut();
            if (error) {
                return { success: false, message: error.message };
            }

            this.session = null;
            this.user = null;
            localStorage.removeItem('supabase_session');
            localStorage.removeItem('user_profile');

            return { success: true };
        } catch (err) {
            console.error('Sign out error:', err);
            return { success: false, message: err.message };
        }
    },

    // Reset password
    async resetPassword(email) {
        try {
            const supabase = getSupabase();
            if (!supabase) {
                return { success: false, message: 'Supabase not configured' };
            }

            const { error } = await supabase.auth.resetPasswordForEmail(email, {
                redirectTo: window.location.origin + '/reset-password.html'
            });

            if (error) {
                return { success: false, message: error.message };
            }

            return {
                success: true,
                message: 'Password reset email sent. Please check your inbox.'
            };
        } catch (err) {
            console.error('Reset password error:', err);
            return { success: false, message: err.message };
        }
    },

    // Update password (after reset)
    async updatePassword(newPassword) {
        try {
            const supabase = getSupabase();
            if (!supabase) {
                return { success: false, message: 'Supabase not configured' };
            }

            const { error } = await supabase.auth.updateUser({
                password: newPassword
            });

            if (error) {
                return { success: false, message: error.message };
            }

            return { success: true, message: 'Password updated successfully' };
        } catch (err) {
            console.error('Update password error:', err);
            return { success: false, message: err.message };
        }
    },

    // Get current session
    getSession() {
        return this.session;
    },

    // Get current user
    getUser() {
        return this.user;
    },

    // Check if authenticated
    isAuthenticated() {
        return !!this.session;
    },

    // Cache session for offline use
    cacheSession(session) {
        try {
            localStorage.setItem('supabase_session', JSON.stringify({
                access_token: session.access_token,
                refresh_token: session.refresh_token,
                expires_at: session.expires_at,
                user: session.user
            }));
        } catch (err) {
            console.warn('Could not cache session:', err);
        }
    },

    // Restore session from cache (for offline fallback)
    restoreCachedSession() {
        try {
            const cached = localStorage.getItem('supabase_session');
            if (cached) {
                const sessionData = JSON.parse(cached);
                // Check if token is still valid (rough check)
                if (sessionData.expires_at * 1000 > Date.now()) {
                    this.session = sessionData;
                    this.user = sessionData.user;
                    return true;
                }
            }
        } catch (err) {
            console.warn('Could not restore session:', err);
        }
        return false;
    },

    // Get user profile from localStorage cache
    getCachedProfile() {
        try {
            const cached = localStorage.getItem('user_profile');
            return cached ? JSON.parse(cached) : null;
        } catch (err) {
            return null;
        }
    }
};

// Export to window
window.SupabaseAuth = SupabaseAuth;

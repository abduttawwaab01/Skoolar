// Parent Homework Viewing Feature
// Adds homework viewing capabilities for parents

(function() {
    // Ensure ParentDashboard is available
    if (typeof ParentDashboard === 'undefined') {
        console.warn('ParentDashboard not found, homework features will not be installed');
        return;
    }

    // Extend ParentDashboard with homework methods
    ParentDashboard.loadHomework = function() {
        const container = document.getElementById('homeworkContent');
        if (!container) return;

        if (!this.currentChild) {
            container.innerHTML = '<p class="text-muted">Select a child to view homework</p>';
            return;
        }

        const statusFilter = document.getElementById('homeworkStatusFilter') ? document.getElementById('homeworkStatusFilter').value : 'all';

        // Get all active homework for this class - handle both snake_case and camelCase
        const homeworks = Storage.getData('homework')?.filter(h => {
            const hSchoolId = h.schoolId || h.school_id;
            const hClass = h.class || h.class;
            const hStatus = h.status || h.status;
            return String(hSchoolId) === String(this.schoolId) &&
                String(hClass) === String(this.currentChild.class) &&
                hStatus === 'active';
        }) || [];

        // Get student's submissions
        const submissions = Storage.getStudentHomeworkSubmissions(this.currentChild.id, this.schoolId);
        const submissionMap = {};
        submissions.forEach(s => {
            submissionMap[s.homeworkId || s.homework_id] = s;
        });

        // Filter homeworks based on status filter
        const filteredHomeworks = homeworks.filter(homework => {
            if (statusFilter === 'all') return true;
            const submission = submissionMap[homework.id];
            if (!submission) return statusFilter === 'pending';
            return submission.status === statusFilter;
        });

        // Render
        this.renderHomeworkList(filteredHomeworks, submissionMap);
        this.updateHomeworkStats(homeworks, submissionMap);
    };

    ParentDashboard.updateHomeworkStats = function(homeworks, submissionMap) {
        const total = homeworks.length;
        const pending = homeworks.filter(h => !submissionMap[h.id]).length;
        const submitted = homeworks.filter(h => submissionMap[h.id] && submissionMap[h.id].status === 'submitted').length;
        const graded = homeworks.filter(h => submissionMap[h.id] && submissionMap[h.id].status === 'graded').length;

        const totalEl = document.getElementById('homeworkTotalCount');
        const pendingEl = document.getElementById('homeworkPendingCount');
        const submittedEl = document.getElementById('homeworkSubmittedCount');
        const gradedEl = document.getElementById('homeworkGradedCount');

        if (totalEl) totalEl.textContent = total;
        if (pendingEl) pendingEl.textContent = pending;
        if (submittedEl) submittedEl.textContent = submitted;
        if (gradedEl) gradedEl.textContent = graded;
    };

    ParentDashboard.renderHomeworkList = function(homeworks, submissionMap) {
        const container = document.getElementById('homeworkContent');
        if (!container) return;

        if (homeworks.length === 0) {
            container.innerHTML = '<p class="text-muted">No homework assignments found</p>';
            return;
        }

        let html = `
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Assignment</th>
                            <th>Subject</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Grade</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        homeworks.forEach(homework => {
            const submission = submissionMap[homework.id];
            const dueDate = homework.due_date ? new Date(homework.due_date).toLocaleDateString() : 'N/A';
            let statusBadge = '';
            let gradeText = '-';

            if (submission) {
                const subStatus = submission.status || submission.status || 'submitted';
                const subGrade = submission.grade ?? submission.grade;
                const totalMarks = homework.total_marks || 100;
                
                if (subStatus === 'graded' && subGrade !== null && subGrade !== undefined) {
                    const percentage = Math.round((subGrade / totalMarks) * 100);
                    statusBadge = `<span class="badge badge-success">Graded (${percentage}%)</span>`;
                    gradeText = `${percentage}%`;
                } else if (subStatus === 'submitted') {
                    statusBadge = `<span class="badge badge-info">Submitted</span>`;
                    gradeText = '-';
                }
            } else {
                statusBadge = `<span class="badge badge-warning">Pending</span>`;
                gradeText = '-';
            }

            const actionBtn = submission ?
                `<button class="btn btn-sm btn-outline" onclick="ParentDashboard.viewHomeworkDetails('${homework.id}', '${submission.id}')">View</button>` :
                '<span class="text-muted">-</span>';

            const truncatedDesc = this.truncateText ? this.truncateText(homework.description || '', 80) : (homework.description ? homework.description.substring(0, 80) + (homework.description.length > 80 ? '...' : '') : '');

            html += `
                <tr>
                    <td>
                        <strong>${homework.title || 'Untitled'}</strong>
                        ${homework.description ? `<br><small class="text-muted">${truncatedDesc}</small>` : ''}
                    </td>
                    <td>${homework.subject || 'N/A'}</td>
                    <td>${dueDate}</td>
                    <td>${statusBadge}</td>
                    <td>${gradeText}</td>
                    <td>${actionBtn}</td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        container.innerHTML = html;
    };

    ParentDashboard.getHomeworkStatusBadge = function(status, grade) {
        if (status === 'graded') {
            return `<span class="badge badge-success">Graded (${grade}%)</span>`;
        } else if (status === 'submitted') {
            return `<span class="badge badge-info">Submitted</span>`;
        } else {
            return `<span class="badge badge-warning">Pending</span>`;
        }
    };

    ParentDashboard.viewHomeworkDetails = function(homeworkId, submissionId) {
        if (!this.currentChild) {
            Toast.error('No child selected');
            return;
        }

        // Get submission - normalize field names
        const submissions = Storage.getStudentHomeworkSubmissions(this.currentChild.id, this.schoolId, homeworkId);
        const submission = submissions.find(s => s.id === submissionId || s.id === String(submissionId));
        if (!submission) {
            console.error('Submission not found. homeworkId:', homeworkId, 'submissionId:', submissionId, 'submissions:', submissions);
            Toast.error('Submission not found');
            return;
        }

        // Get homework details - normalize field names
        const homework = Storage.getData('homework')?.find(h => h.id === homeworkId || h.id === String(homeworkId));
        if (!homework) {
            console.error('Homework not found. homeworkId:', homeworkId, 'homeworks:', Storage.getData('homework'));
            Toast.error('Homework not found');
            return;
        }

        // Normalize submission fields (handle both snake_case and camelCase)
        const subDate = submission.submissionDate || submission.submission_date;
        const ansText = submission.answerText || submission.answer_text;
        const subStatus = submission.status || 'submitted';
        const subGrade = submission.grade ?? submission.grade;
        const subFeedback = submission.feedback || submission.feedback;
        const subGradedBy = submission.gradedBy || submission.graded_by;
        const subGradedAt = submission.gradedAt || submission.graded_at;
        const subAttachments = submission.attachments || submission.attachments || [];

        const totalMarks = homework.total_marks || 100;
        const dueDate = homework.due_date ? new Date(homework.due_date).toLocaleDateString() : 'N/A';
        const submissionDate = subDate ? new Date(subDate).toLocaleString() : 'N/A';

        let gradeHtml = '';
        if (subStatus === 'graded' && subGrade !== null && subGrade !== undefined) {
            const percentage = Math.round((subGrade / totalMarks) * 100);
            gradeHtml = `
                <div class="card" style="background: var(--lighter); margin-top: 15px; padding: 15px; border-radius: 8px;">
                    <h5><i class="fas fa-check-circle" style="color: var(--success);"></i> Graded</h5>
                    <p><strong>Score:</strong> ${subGrade} / ${totalMarks} (${percentage}%)</p>
                    ${subFeedback ? `<p><strong>Feedback:</strong></p><div style="background: #fff; padding: 10px; border-radius: 4px; margin-top: 5px;">${subFeedback}</div>` : ''}
                    <p><small>Graded by: ${subGradedBy || 'System'} on ${subGradedAt ? new Date(subGradedAt).toLocaleString() : 'N/A'}</small></p>
                </div>
            `;
        } else {
            gradeHtml = `
                <div class="alert alert-info">
                    <i class="fas fa-clock"></i> This homework is pending grading.
                </div>
            `;
        }

         const modalBody = `
             <div class="form-group">
                 <label><strong>Assignment:</strong></label>
                 <p>${homework.title || 'Untitled'}</p>
             </div>
             <div class="form-group">
                 <label><strong>Subject:</strong></label>
                 <p>${homework.subject || 'N/A'}</p>
             </div>
             <div class="form-group">
                 <label><strong>Due Date:</strong></label>
                 <p>${dueDate}</p>
             </div>
             <div class="form-group">
                 <label><strong>Description:</strong></label>
                 <p>${homework.description || 'No description provided'}</p>
             </div>
             <hr style="margin: 15px 0; border: none; border-top: 1px solid var(--gray);">
             <div class="form-group">
                 <label><strong>Student's Submission:</strong></label>
                 <div style="background: var(--lighter); padding: 15px; border-radius: 8px; white-space: pre-wrap; margin-top: 5px; min-height: 50px;">
                     ${ansText || '<em class="text-muted">No text provided</em>'}
                 </div>
                 <small class="text-muted">Submitted on: ${submissionDate}</small>
             </div>
             ${subAttachments && subAttachments.length > 0 ? `
                 <div class="form-group">
                     <label><strong>Attachments (${subAttachments.length}):</strong></label>
                     <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
                         ${subAttachments.map(att => `
                             <div style="border: 1px solid var(--gray); border-radius: 8px; padding: 8px; text-align: center; background: #fff;">
                                 <img src="${att.data || att.url || ''}" alt="${att.name || 'attachment'}" style="width: 120px; height: 120px; object-fit: cover; border-radius: 4px; margin-bottom: 5px;">
                                 <div style="font-size: 11px; color: var(--gray); max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${att.name || 'attachment'}">${att.name || 'attachment'}</div>
                             </div>
                         `).join('')}
                     </div>
                 </div>
             ` : ''}
             ${gradeHtml}
         `;

        document.getElementById('homeworkModalTitle').textContent = homework.title || 'Homework Details';
        document.getElementById('homeworkModalBody').innerHTML = modalBody;
        Modal.show('viewHomeworkModal');
    };

    // Add truncateText method if not already present
    if (typeof ParentDashboard.truncateText !== 'function') {
        ParentDashboard.truncateText = function(text, maxLength) {
            if (!text) return '';
            if (text.length <= maxLength) return text;
            return text.substring(0, maxLength) + '...';
        };
    }

    // Add loadProfile method for parent profile section
    ParentDashboard.loadProfile = function() {
        const user = Auth.getCurrentUser();
        const school = Auth.getSchool();
        
        // Populate user info
        const nameEl = document.getElementById('profileName');
        const emailEl = document.getElementById('profileEmail');
        const phoneEl = document.getElementById('profilePhone');
        
        if (nameEl) nameEl.textContent = user.name;
        if (emailEl) emailEl.textContent = user.email || 'N/A';
        if (phoneEl) phoneEl.textContent = user.phone || 'N/A';
        
        // Load children
        const childrenContainer = document.getElementById('profileChildrenList');
        if (!childrenContainer) return;
        
        const students = Storage.getStudents(this.schoolId);
        const children = students.filter(s => 
            s.parentId === user.id || 
            s.parentPhone === user.phone || 
            s.parentEmail === user.email
        );
        
        if (children.length === 0) {
            childrenContainer.innerHTML = '<p class="text-muted">No children linked to your account</p>';
            return;
        }
        
        let html = '<div class="stats-grid">';
        children.forEach(child => {
            html += `
                <div class="stat-card">
                    <div class="stat-icon primary">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-label">${child.name}</div>
                        <div class="stat-value">${child.class}</div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        childrenContainer.innerHTML = html;
    };

    console.log('Parent homework feature loaded');
})();

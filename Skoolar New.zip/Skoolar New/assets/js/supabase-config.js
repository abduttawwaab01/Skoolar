// =====================================================
// SUPABASE CONFIGURATION - FIXED VERSION
// =====================================================

const SupabaseConfig = {
    // Your Supabase Project Credentials
    url: 'https://amccnstthagjzdidshpw.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFtY2Nuc3R0aGFnanpkaWRzaHB3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI0MzQ5MjQsImV4cCI6MjA4ODAxMDkyNH0.A9PMBauIYMZVLopkXJWjaS2-EQ5Imi_cNwPbohbYduQ',

    // Enable Supabase
    enabled: true,

    auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
    },

    // Tables names - using snake_case to match Supabase SQL schema
    tables: {
        schools: 'schools',
        users: 'users',
        students: 'students',
        teachers: 'teachers',
        scores: 'scores',
        attendance: 'attendance',
        staffAttendance: 'staff_attendance',
        finance: 'finance',
        chartOfAccounts: 'chart_of_accounts',
        budgets: 'budgets',
        accountsReceivable: 'accounts_receivable',
        taxSettings: 'tax_settings',
        financialAttachments: 'financial_attachments',
        receipts: 'receipts',
        questions: 'questions',
        tests: 'tests',
        testResults: 'test_results',
        testQuestions: 'test_questions',
        testAttempts: 'test_attempts',
        exams: 'exams',
        examQuestions: 'exam_questions',
        examResults: 'exam_results',
        calendarEvents: 'calendar_events',
        activationCodes: 'activation_codes',
        chats: 'chats',
        messages: 'messages',
        studentMessages: 'student_messages',
        parentMessages: 'parent_messages',
        parentAnnouncements: 'parent_announcements',
        notifications: 'notifications',
        adverts: 'adverts',
        libraryBooks: 'library_books',
        bookLoans: 'book_loans',
        homework: 'homework',
        homeworkSubmissions: 'homework_submissions',
        timetable: 'timetable',
        stories: 'stories',
        storyInteractions: 'story_interactions',
        storyComments: 'story_comments',
        storySubmissions: 'story_submissions',
         auditLog: 'audit_log',
         syncLog: 'sync_log',
         systemConfig: 'system_config'
     }
};

// =====================================================
// SUPABASE CLIENT - Using different variable names to avoid conflicts
// =====================================================
let supabaseClient = null;
let isSupabaseReady = false;
let scriptLoadAttempted = false;

// Function to load the Supabase script
function loadSupabaseScript() {
    return new Promise((resolve, reject) => {
        // Check if already loaded
        if (window.supabase) {
            console.log('Supabase already available in window');
            resolve();
            return;
        }

        // Check if we already attempted to load
        if (scriptLoadAttempted) {
            // Wait a bit and check again
            setTimeout(() => {
                if (window.supabase) {
                    resolve();
                } else {
                    reject(new Error('Supabase still not available after load attempt'));
                }
            }, 500);
            return;
        }

        scriptLoadAttempted = true;

        // Create script element
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
        script.onload = () => {
            console.log('✅ Supabase script loaded');
            // Give it a moment to initialize
            setTimeout(resolve, 100);
        };
        script.onerror = (error) => {
            console.error('❌ Failed to load Supabase script:', error);
            reject(new Error('Failed to load Supabase'));
        };
        document.head.appendChild(script);
    });
}

// Initialize Supabase client
async function initSupabase() {
    // Don't initialize if not enabled
    if (!SupabaseConfig.enabled) {
        console.log('ℹ️ Supabase not enabled in config - using localStorage only');
        return false;
    }

    // Check if credentials are configured
    if (SupabaseConfig.url === 'YOUR_SUPABASE_URL' ||
        SupabaseConfig.anonKey === 'YOUR_SUPABASE_ANON_KEY') {
        console.log('⚠️ Supabase credentials not configured - using localStorage only');
        return false;
    }

    try {
        // Load the Supabase script
        await loadSupabaseScript();

        // Check if the library is available
        if (!window.supabase) {
            throw new Error('Supabase library not available after loading');
        }

        // Create the client - store in our own variable
        supabaseClient = window.supabase.createClient(
            SupabaseConfig.url,
            SupabaseConfig.anonKey,
            {
                auth: {
                    persistSession: false,
                    autoRefreshToken: false,
                    detectSessionInUrl: false
                }
            }
        );

        isSupabaseReady = true;
        window.supabaseClient = supabaseClient; // Update global reference after creation
        console.log('✅ Supabase client created successfully');
        
        // Enable cloud sync in Storage module
        if (typeof Storage !== 'undefined' && typeof Storage.enableCloudSync === 'function') {
            Storage.enableCloudSync();
        }

        // Test the connection (optional)
        try {
            const { error } = await supabaseClient
                .from('schools')
                .select('count', { count: 'exact', head: true });

            if (error) {
                console.warn('⚠️ Supabase connected but tables may not exist:', error.message);
            } else {
                console.log('✅ Supabase query successful');
            }
        } catch (testError) {
            // Ignore test errors
        }

        return true;

    } catch (error) {
        console.error('❌ Failed to initialize Supabase:', error);
        isSupabaseReady = false;
        supabaseClient = null;
        return false;
    }
}

// Helper function to check if Supabase is enabled and ready
function isSupabaseEnabled() {
    return SupabaseConfig.enabled && isSupabaseReady && supabaseClient !== null;
}

// Helper function to get the Supabase client
function getSupabase() {
    return supabaseClient;
}

// =====================================================
// EXPORT TO WINDOW - Using unique names to avoid conflicts
// =====================================================
window.SupabaseConfig = SupabaseConfig;
window.initSupabase = initSupabase;
window.isSupabaseEnabled = isSupabaseEnabled;
window.getSupabase = getSupabase;
// window.supabaseClient is set inside initSupabase() after client creation

// Diagnostic function to test Supabase connection
window.testSupabaseConnection = async function() {
    console.log('=== Supabase Connection Diagnostic ===');
    console.log('Supabase enabled:', SupabaseConfig.enabled);
    console.log('Supabase ready:', isSupabaseReady);
    console.log('Supabase client:', supabaseClient !== null);
    
    if (!supabaseClient) {
        console.error('❌ Supabase client not initialized');
        return { success: false, message: 'Supabase client not initialized' };
    }
    
    try {
        // Test schools table
        const { data: schools, error: schoolsError } = await supabaseClient
            .from('schools')
            .select('count', { count: 'exact', head: true });
        
        if (schoolsError) {
            console.error('❌ Schools table error:', schoolsError.message);
            return { success: false, message: schoolsError.message, table: 'schools' };
        }
        console.log('✅ Schools table accessible');
        
        // Test students table
        const { data: students, error: studentsError } = await supabaseClient
            .from('students')
            .select('count', { count: 'exact', head: true });
        
        if (studentsError) {
            console.error('❌ Students table error:', studentsError.message);
            return { success: false, message: studentsError.message, table: 'students' };
        }
        console.log('✅ Students table accessible');
        console.log('Student count:', students);
        
        return { success: true, schools: schools, students: students };
    } catch (error) {
        console.error('❌ Connection test failed:', error);
        return { success: false, message: error.message };
    }
};

// Auto-initialize when DOM is ready
if (typeof document !== 'undefined') {
    // Create a global promise that other scripts can wait for
    window.supabaseReady = (async () => {
        if (SupabaseConfig.enabled) {
            return await initSupabase();
        }
        return false;
    })();

    // Also support traditional DOMContentLoaded for backward compatibility
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            // initSupabase is already started above
        });
    }
}
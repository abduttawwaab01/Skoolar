// cache-manager.js
// Simple caching system to reduce Supabase calls

const CacheManager = {
    // Cache data in memory (fastest)
    memoryCache: new Map(),

    // Cache in localStorage (persists between page reloads)

    // Get data from cache
    get(key, maxAge = 5 * 60 * 1000) { // 5 minutes default
        // Check memory cache first
        if (this.memoryCache.has(key)) {
            const item = this.memoryCache.get(key);
            if (Date.now() - item.timestamp < maxAge) {
                return item.data;
            }
            this.memoryCache.delete(key);
        }

        // Check localStorage
        const localItem = localStorage.getItem(`cache_${key}`);
        if (localItem) {
            try {
                const item = JSON.parse(localItem);
                if (Date.now() - item.timestamp < maxAge) {
                    return item.data;
                }
                localStorage.removeItem(`cache_${key}`);
            } catch (e) {
                // Invalid cache, ignore
            }
        }

        return null;
    },

    // Remove data from cache
    delete(key) {
        this.memoryCache.delete(key);
        localStorage.removeItem(`cache_${key}`);
    },

    // Save to cache
    set(key, data) {
        const item = {
            data: data,
            timestamp: Date.now()
        };

        // Save to memory
        this.memoryCache.set(key, item);

        // Save to localStorage (but only for important data)
        if (this.shouldPersist(key)) {
            localStorage.setItem(`cache_${key}`, JSON.stringify(item));
        }
    },

    // Only persist important data types
    shouldPersist(key) {
        const persistTypes = ['school_settings', 'subjects', 'classes'];
        return persistTypes.some(type => key.startsWith(type));
    },

    // Clear old cache
    clean() {
        const now = Date.now();
        const maxAge = 30 * 60 * 1000; // 30 minutes

        // Clean memory cache
        for (const [key, item] of this.memoryCache) {
            if (now - item.timestamp > maxAge) {
                this.memoryCache.delete(key);
            }
        }

        // Clean localStorage
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith('cache_')) {
                try {
                    const item = JSON.parse(localStorage.getItem(key));
                    if (now - item.timestamp > maxAge) {
                        localStorage.removeItem(key);
                    }
                } catch (e) {
                    localStorage.removeItem(key);
                }
            }
        }
    }
};

// Auto-clean every hour
setInterval(() => CacheManager.clean(), 60 * 60 * 1000);
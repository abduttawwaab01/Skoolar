-- =============================================
-- SUPABASE STORAGE POLICIES FOR SCHOOL FILES
-- Run these in your Supabase SQL Editor
-- =============================================

-- First, let's check if the bucket exists
SELECT id, name, public FROM storage.buckets WHERE name = 'school-files';

-- If bucket doesn't exist, create it (run this first if needed):
-- INSERT INTO storage.buckets (id, name, public) VALUES ('school-files', 'school-files', true);

-- =============================================
-- POLICIES FOR PUBLIC ACCESS
-- =============================================

-- 1. Allow public READ access to files
DROP POLICY IF EXISTS "Public Read Access" ON storage.objects;
CREATE POLICY "Public Read Access" ON storage.objects
FOR SELECT USING (bucket_id = 'school-files');

-- 2. Allow public INSERT/UPLOAD access
DROP POLICY IF EXISTS "Public Insert Access" ON storage.objects;
CREATE POLICY "Public Insert Access" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'school-files');

-- 3. Allow public UPDATE access
DROP POLICY IF EXISTS "Public Update Access" ON storage.objects;
CREATE POLICY "Public Update Access" ON storage.objects
FOR UPDATE USING (bucket_id = 'school-files');

-- 4. Allow public DELETE access
DROP POLICY IF EXISTS "Public Delete Access" ON storage.objects;
CREATE POLICY "Public Delete Access" ON storage.objects
FOR DELETE USING (bucket_id = 'school-files');

-- =============================================
-- VERIFICATION
-- =============================================
SELECT * FROM storage.policies WHERE bucket_id = 'school-files';

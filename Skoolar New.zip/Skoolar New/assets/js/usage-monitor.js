// usage-monitor.js - Simplified version for new projects
// Uses localStorage only, no Supabase calls

const UsageMonitor = {
    limits: {
        database: 500 * 1024 * 1024,      // 500 MB
        storage: 1 * 1024 * 1024 * 1024,   // 1 GB
        apiCalls: 1000000                   // 1M calls
    },
    
    usage: {
        database: 0,
        storage: 0,
        apiCalls: 0,
        mau: 0,
        lastChecked: null,
        history: []
    },
    
    async init() {
        console.log('📊 Usage Monitor initializing (localStorage mode)...');
        this.loadHistory();
        await this.checkAll();
        this.startAutoCheck();
        console.log('✅ Usage Monitor ready');
    },
    
    loadHistory() {
        const saved = localStorage.getItem('usage_history');
        if (saved) {
            try {
                this.usage.history = JSON.parse(saved);
            } catch (e) {
                console.error('Error loading usage history:', e);
            }
        }
    },
    
    saveHistory() {
        if (this.usage.history.length > 30) {
            this.usage.history = this.usage.history.slice(-30);
        }
        localStorage.setItem('usage_history', JSON.stringify(this.usage.history));
    },
    
    startAutoCheck() {
        // Check every hour
        setInterval(() => {
            this.checkAll();
        }, 60 * 60 * 1000);
    },
    
    async checkAll() {
        console.log('📊 Checking usage metrics (localStorage mode)...');
        
        // Estimate from localStorage
        this.usage.database = this.estimateLocalStorageSize();
        this.usage.storage = 0; // No storage in localStorage mode
        this.usage.apiCalls = this.getApiCalls();
        this.usage.mau = this.estimateMAU();
        this.usage.lastChecked = new Date().toISOString();
        
        this.usage.history.push({
            date: this.usage.lastChecked,
            database: this.usage.database,
            storage: this.usage.storage,
            apiCalls: this.usage.apiCalls,
            mau: this.usage.mau
        });
        
        this.saveHistory();
        this.checkThresholds();
        
        return this.usage;
    },
    
    estimateLocalStorageSize() {
        let total = 0;
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            const value = localStorage.getItem(key);
            total += key.length + (value ? value.length : 0);
        }
        return total;
    },
    
    getApiCalls() {
        return parseInt(localStorage.getItem('api_call_count') || '0');
    },
    
    estimateMAU() {
        // Simple estimate from users data
        const users = Storage?.getData('users') || [];
        const thisMonth = new Date().getMonth();
        return users.filter(u => {
            const lastLogin = u.lastLogin ? new Date(u.lastLogin) : null;
            return lastLogin && lastLogin.getMonth() === thisMonth;
        }).length;
    },
    
    trackApiCall() {
        const count = this.getApiCalls() + 1;
        localStorage.setItem('api_call_count', count.toString());
        this.usage.apiCalls = count;
    },
    
    checkThresholds() {
        const warnings = [];
        
        const dbPercent = (this.usage.database / this.limits.database) * 100;
        if (dbPercent > 95) {
            warnings.push({
                type: 'critical',
                message: `🔥 Database near limit: ${this.formatBytes(this.usage.database)} / ${this.formatBytes(this.limits.database)}`
            });
        } else if (dbPercent > 80) {
            warnings.push({
                type: 'warning',
                message: `⚠️ Database at ${dbPercent.toFixed(1)}% of limit`
            });
        }
        
        if (warnings.length > 0) {
            this.showWarnings(warnings);
        }
        
        return warnings;
    },
    
    showWarnings(warnings) {
        console.warn('📊 Usage Warnings:', warnings);
        localStorage.setItem('last_warnings', JSON.stringify(warnings));
    },
    
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },
    
    refreshWidget() {
        this.checkAll().then(() => {
            if (typeof updateDetailedDashboard === 'function') {
                updateDetailedDashboard();
            }
        });
    },
    
    getRecommendations() {
        const recs = [];
        const dbPercent = (this.usage.database / this.limits.database) * 100;
        if (dbPercent > 70) {
            recs.push({
                type: 'database',
                action: 'Run Data Pruner to clean old records'
            });
        }
        return recs;
    }
};

// Initialize
UsageMonitor.init();

// Make available globally
window.UsageMonitor = UsageMonitor;
const TeacherTimetable = {
    load() {
        const user = Auth.getCurrentUser();
        const schoolId = Auth.getCurrentSchoolId();
        
        if (!user || !schoolId) {
            console.warn('Teacher or school not found');
            return;
        }
        
        // First sync from cloud to get latest data
        this.syncAndLoad(user, schoolId);
    },
    
    syncAndLoad(user, schoolId) {
        // Sync from cloud first to get latest timetable
        if (typeof SupabaseSync !== 'undefined' && SupabaseSync.isReady()) {
            SupabaseSync.syncFromCloud().then(() => {
                this.loadTimetableData(user, schoolId);
            }).catch(e => {
                console.warn('Sync failed, loading from local:', e);
                this.loadTimetableData(user, schoolId);
            });
        } else {
            this.loadTimetableData(user, schoolId);
        }
    },
    
    loadTimetableData(user, schoolId) {
        const allTimetable = Storage.getData('timetable') || [];
        const myTimetable = allTimetable.filter(t => 
            t.schoolId === schoolId && t.teacherId === user.id
        );
        
        this.renderGrid(myTimetable);
    },
    
    renderGrid(timetable) {
        const container = document.getElementById('teacherTimetableGrid');
        if (!container) return;
        
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
        const periods = [...new Set(timetable.map(t => t.periodNumber))].sort((a, b) => a - b);
        
        if (timetable.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-calendar-alt"></i>
                    <p>No timetable entries found. Contact your administrator to set up your schedule.</p>
                </div>
            `;
            return;
        }
        
        let html = '<div class="timetable-week-grid">';
        
        html += '<div class="timetable-header-row">';
        html += '<div class="timetable-header-cell"></div>';
        days.forEach(day => {
            html += `<div class="timetable-header-cell">${day}</div>`;
        });
        html += '</div>';
        
        periods.forEach(period => {
            html += `<div class="timetable-row">`;
            html += `<div class="timetable-period-label">Period ${period}</div>`;
            days.forEach(day => {
                const entry = timetable.find(t => t.dayOfWeek === day && t.periodNumber === period);
                if (entry) {
                    const colorClass = this.getSubjectColorClass(entry.subject);
                    html += `
                        <div class="timetable-cell ${colorClass}">
                            <div class="timetable-subject">${entry.subject}</div>
                            <div class="timetable-room">${entry.room || ''}</div>
                            <div class="timetable-class">${entry.class}${entry.section ? ' ' + entry.section : ''}</div>
                        </div>`;
                } else {
                    html += '<div class="timetable-cell empty"></div>';
                }
            });
            html += '</div>';
        });
        
        html += '</div>';
        container.innerHTML = html;
    },
    
    getSubjectColorClass(subject) {
        const colors = ['math', 'english', 'science', 'language', 'arts', 'other'];
        if (!subject) return 'other';
        const lower = subject.toLowerCase();
        if (lower.includes('math') || lower.includes('mathematic')) return 'math';
        if (lower.includes('english') || lower.includes('literature') || lower.includes('language')) return 'english';
        if (lower.includes('science') || lower.includes('biology') || lower.includes('physics') || lower.includes('chemistry')) return 'science';
        if (lower.includes('french') || lower.includes('hausa') || lower.includes('yoruba') || lower.includes('igbo')) return 'language';
        if (lower.includes('art') || lower.includes('music') || lower.includes('civic') || lower.includes('security') || lower.includes('physical')) return 'arts';
        return 'other';
    }
};

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('teacherTimetableGrid')) {
        if (typeof TeacherTimetable !== 'undefined') {
            TeacherTimetable.load();
        }
    }
});

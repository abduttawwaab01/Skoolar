// =====================================================
// ATTENDANCE SCANNER - ID Card QR Code Scanner
// This module enables scanning student ID cards to mark attendance
// =====================================================

const AttendanceScanner = {
    videoStream: null,
    scanInterval: null,
    lastScannedId: null,
    scanCooldown: 3000, // 3 seconds between scans
    
    // Start the camera and begin scanning
    async start() {
        try {
            const video = document.getElementById('scannerVideo');
            const placeholder = document.getElementById('scannerPlaceholder');
            const startBtn = document.getElementById('startScannerBtn');
            const stopBtn = document.getElementById('stopScannerBtn');
            
            if (!video || !placeholder) {
                Toast.error('Scanner elements not found');
                return;
            }
            
            // Request camera access
            this.videoStream = await navigator.mediaDevices.getUserMedia({
                video: { 
                    facingMode: 'environment',
                    width: { ideal: 1280 },
                    height: { ideal: 720 }
                }
            });
            
            video.srcObject = this.videoStream;
            video.style.display = 'block';
            placeholder.style.display = 'none';
            startBtn.style.display = 'none';
            stopBtn.style.display = 'inline-block';
            
            // Start scanning loop
            this.scanInterval = setInterval(() => this.scanQRCode(), 500);
            
            Toast.success('Scanner started. Point camera at student ID card.');
        } catch (error) {
            console.error('Scanner error:', error);
            Toast.error('Could not access camera: ' + error.message);
        }
    },
    
    // Stop the camera and scanning
    stop() {
        if (this.videoStream) {
            this.videoStream.getTracks().forEach(track => track.stop());
            this.videoStream = null;
        }
        
        if (this.scanInterval) {
            clearInterval(this.scanInterval);
            this.scanInterval = null;
        }
        
        const video = document.getElementById('scannerVideo');
        const placeholder = document.getElementById('scannerPlaceholder');
        const startBtn = document.getElementById('startScannerBtn');
        const stopBtn = document.getElementById('stopScannerBtn');
        
        if (video) video.style.display = 'none';
        if (placeholder) placeholder.style.display = 'block';
        if (startBtn) startBtn.style.display = 'inline-block';
        if (stopBtn) stopBtn.style.display = 'none';
        
        // Clear result
        const resultDiv = document.getElementById('scanResult');
        if (resultDiv) {
            resultDiv.style.display = 'none';
        }
    },
    
    // Scan for QR codes in the video feed
    async scanQRCode() {
        const video = document.getElementById('scannerVideo');
        const canvas = document.getElementById('scannerCanvas');
        
        if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA) {
            return;
        }
        
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Try to detect QR code using the canvas
        // For better QR detection, you could integrate a library like jsQR
        // Here we use a simple approach with HTML5 QR Code API if available
        
        if (window.html5_qrcode) {
            // If html5-qrcode library is available, use it
            return;
        }
        
        // Simple manual QR detection using canvas
        // This is a simplified approach - for production, use a proper QR library
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        
        // For now, we'll provide a manual entry fallback
        // In production, integrate jsQR or html5-qrcode library
    },
    
    // Mark attendance by student ID
    async markAttendance(studentId) {
        if (!studentId || studentId === this.lastScannedId) {
            return;
        }
        
        // Apply cooldown to prevent duplicate scans
        if (this.lastScannedId) {
            Toast.info('Please wait before scanning another card');
            return;
        }
        
        this.lastScannedId = studentId;
        
        const schoolId = Auth.getCurrentSchoolId ? Auth.getCurrentSchoolId() : localStorage.getItem('currentSchoolId');
        
        if (!schoolId) {
            this.showResult('error', 'No school selected. Please select a school first.');
            setTimeout(() => this.lastScannedId = null, 3000);
            return;
        }
        
        const today = new Date().toISOString().split('T')[0];
        
        // Find student by ID or studentId field
        const students = Storage.getStudents(schoolId);
        const student = students.find(s => 
            s.id === studentId || 
            s.studentId === studentId ||
            s.id.toLowerCase() === studentId.toLowerCase() ||
            s.studentId?.toLowerCase() === studentId.toLowerCase()
        );
        
        if (!student) {
            this.showResult('error', 'Student not found! Please check the ID.');
            setTimeout(() => this.lastScannedId = null, 3000);
            return;
        }
        
        // Check if already marked present today
        const attendance = Storage.getAttendance(schoolId);
        const alreadyMarked = attendance.find(a => 
            a.studentId === student.id && 
            a.date === today
        );
        
        if (alreadyMarked) {
            this.showResult('warning', `${student.name} is already marked as <strong>${alreadyMarked.status}</strong> for today!`);
            setTimeout(() => this.lastScannedId = null, 3000);
            return;
        }
        
        // Mark as present
        const newAttendance = {
            id: Storage.generateId(),
            studentId: student.id,
            schoolId: schoolId,
            date: today,
            status: 'present',
            markedAt: new Date().toISOString()
        };
        
        Storage.addItem('attendance', newAttendance);
        
        this.showResult('success', `
            <div style="text-align: center;">
                <i class="fas fa-check-circle" style="font-size: 32px; color: #16a34a;"></i>
                <p style="margin-top: 10px; font-size: 16px;">
                    <strong>${student.name}</strong><br>
                    <span style="color: #64748b;">${student.class}</span><br>
                    <span style="color: #16a34a; font-weight: bold;">MARKED AS PRESENT</span>
                </p>
            </div>
        `);
        
        // Sync to Supabase if enabled
        if (typeof isSupabaseEnabled === 'function' && isSupabaseEnabled()) {
            try {
                await this.syncAttendanceToCloud(newAttendance, student);
            } catch (error) {
                console.log('Cloud sync failed, will retry later:', error);
            }
        }
        
        // Update today's attendance list
        this.updateTodayAttendance();
        
        // Reset after cooldown to allow rescanning
        setTimeout(() => {
            this.lastScannedId = null;
        }, this.scanCooldown);
    },
    
    // Mark attendance manually by entering Student ID
    async markManualAttendance() {
        const studentIdInput = document.getElementById('manualStudentId');
        
        if (!studentIdInput) {
            Toast.error('Manual input field not found');
            return;
        }
        
        const studentId = studentIdInput.value.trim();
        
        if (!studentId) {
            Toast.error('Please enter a Student ID');
            return;
        }
        
        await this.markAttendance(studentId);
        studentIdInput.value = '';
    },
    
    // Show scan result
    showResult(type, message) {
        const resultDiv = document.getElementById('scanResult');
        if (!resultDiv) return;
        
        const colors = {
            success: '#d1fae5',
            error: '#fee2e2',
            warning: '#fef3c7'
        };
        const textColors = {
            success: '#065f46',
            error: '#991b1b',
            warning: '#92400e'
        };
        
        resultDiv.style.display = 'block';
        resultDiv.style.backgroundColor = colors[type];
        resultDiv.style.color = textColors[type];
        resultDiv.style.padding = '20px';
        resultDiv.style.borderRadius = '10px';
        resultDiv.style.marginTop = '20px';
        resultDiv.style.textAlign = 'center';
        resultDiv.innerHTML = message;
    },
    
    // Sync attendance to Supabase cloud
    async syncAttendanceToCloud(attendanceRecord, student) {
        const supabase = getSupabase();
        
        if (!supabase) {
            console.log('Supabase not available for sync');
            return;
        }
        
        try {
            const { error } = await supabase
                .from('attendance')
                .upsert({
                    id: attendanceRecord.id,
                    student_id: attendanceRecord.studentId,
                    school_id: attendanceRecord.schoolId,
                    date: attendanceRecord.date,
                    status: attendanceRecord.status,
                    marked_at: attendanceRecord.markedAt,
                    marked_by: attendanceRecord.markedBy
                }, { 
                    onConflict: 'student_id,date',
                    ignoreDuplicates: false 
                });
            
            if (error) {
                console.error('Cloud sync error:', error);
            } else {
                console.log('Attendance synced to cloud successfully');
            }
        } catch (error) {
            console.error('Sync error:', error);
        }
    },
    
    // Update today's attendance list in the UI
    updateTodayAttendance() {
        const container = document.getElementById('todayAttendanceList');
        if (!container) return;
        
        const schoolId = Auth.getCurrentSchoolId ? Auth.getCurrentSchoolId() : localStorage.getItem('currentSchoolId');
        
        if (!schoolId) return;
        
        const today = new Date().toISOString().split('T')[0];
        
        const attendance = Storage.getAttendance(schoolId);
        const todayAttendance = attendance.filter(a => a.date === today);
        
        const students = Storage.getStudents(schoolId);
        
        if (todayAttendance.length === 0) {
            container.innerHTML = '<p class="text-muted">No attendance marked today</p>';
            return;
        }
        
        let html = '<table class="table table-striped mt-2"><thead><tr><th>Time</th><th>Student Name</th><th>Class</th><th>Status</th></tr></thead><tbody>';
        
        // Sort by marked time (most recent first)
        const sorted = todayAttendance.sort((a, b) => {
            return new Date(b.markedAt) - new Date(a.markedAt);
        });
        
        sorted.forEach(record => {
            const student = students.find(s => s.id === record.studentId);
            if (student) {
                const time = record.markedAt ? new Date(record.markedAt).toLocaleTimeString() : '';
                const statusBadge = record.status === 'present' 
                    ? '<span class="badge badge-success">Present</span>'
                    : '<span class="badge badge-danger">' + record.status + '</span>';
                
                html += `
                    <tr>
                        <td>${time}</td>
                        <td>${student.name}</td>
                        <td>${student.class}</td>
                        <td>${statusBadge}</td>
                    </tr>
                `;
            }
        });
        
        html += '</tbody></table>';
        
        container.innerHTML = html;
    },
    
    // Initialize scanner UI
    init() {
        // This is called when the scanner section is shown
        this.updateTodayAttendance();
    }
};

// =====================================================
// QR CODE DETECTION USING html5-qrcode LIBRARY
// Add this for better QR code detection
// =====================================================

const QRDetector = {
    scanner: null,
    
    async startAdvanced() {
        // This requires html5-qrcode library
        // Include <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
        
        if (typeof Html5Qrcode === 'undefined') {
            console.warn('html5-qrcode library not loaded');
            return;
        }
        
        this.scanner = new Html5Qrcode('scannerVideo');
        
        const config = { 
            fps: 10,
            qrbox: { width: 250, height: 250 }
        };
        
        await this.scanner.start(
            { facingMode: 'environment' },
            config,
            (decodedText) => {
                // QR code detected
                AttendanceScanner.markAttendance(decodedText);
            },
            (errorMessage) => {
                // Parse error, ignore
            }
        );
    },
    
    stop() {
        if (this.scanner) {
            this.scanner.stop();
            this.scanner = null;
        }
    }
};

// =====================================================
// EXPORT TO WINDOW
// =====================================================

window.AttendanceScanner = AttendanceScanner;
window.QRDetector = QRDetector;

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Give time for other scripts to load
    setTimeout(() => {
        if (document.getElementById('todayAttendanceList')) {
            AttendanceScanner.updateTodayAttendance();
        }
    }, 1000);
});
